/* PS SEO Console — admin UI (vanilla). Talks to ps-seo/v1 via nonce. */
(function () {
  'use strict';
  var root = function () { return document.querySelector('.psc'); };

  /* ---- theme ---- */
  window.pscToggleTheme = function () {
    var el = root(); if (!el) return;
    var dark = el.getAttribute('data-theme') === 'dark';
    var next = dark ? 'light' : 'dark';
    el.setAttribute('data-theme', next);
    try { localStorage.setItem('psc_theme', next); } catch (e) {}
    var b = document.querySelector('.psc-themebtn'); if (b) b.textContent = next === 'dark' ? '☀️' : '🌙';
  };

  /* ---- REST helper ---- */
  function api(path, method, body) {
    return fetch(PSC.rest + path, {
      method: method || 'GET',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': PSC.nonce },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, data: j }; }); });
  }

  function toast(msg) {
    var t = document.createElement('div');
    t.className = 'psc-toast'; t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 300); }, 1800);
  }

  /* ---- board filter ---- */
  window.pscFilter = function () {
    var q = (document.getElementById('psc-search') || {}).value || '';
    q = q.toLowerCase();
    var p = (document.getElementById('psc-fpri') || {}).value || '';
    var d = (document.getElementById('psc-fdom') || {}).value || '';
    document.querySelectorAll('.psc-taskcard').forEach(function (c) {
      var okq = !q || c.textContent.toLowerCase().indexOf(q) > -1;
      var okp = !p || c.getAttribute('data-pri') === p;
      var okd = !d || c.getAttribute('data-dom') === d;
      c.style.display = (okq && okp && okd) ? '' : 'none';
    });
    document.querySelectorAll('.psc-board .col').forEach(function (col) {
      var n = col.querySelectorAll('.psc-taskcard:not([style*="none"])').length;
      var cnt = col.querySelector('.cnt'); if (cnt) cnt.textContent = n;
    });
  };

  /* ---- copy prompt ---- */
  window.pscCopy = function (btn) {
    var card = btn.closest('.psc-taskcard');
    var pr = card ? card.querySelector('.psc-prompt') : null;
    var txt = pr ? pr.textContent : (card ? card.querySelector('h3').textContent : '');
    if (navigator.clipboard) navigator.clipboard.writeText(txt.trim());
    var old = btn.textContent; btn.classList.add('copied'); btn.textContent = '✓ Copied';
    setTimeout(function () { btn.classList.remove('copied'); btn.textContent = old; }, 1400);
  };

  /* ---- new card ---- */
  window.pscToggleNew = function () {
    var f = document.getElementById('psc-newform'); if (f) f.classList.toggle('show');
  };
  window.pscSubmitNew = function () {
    var g = function (id) { var el = document.getElementById(id); return el ? el.value : ''; };
    var title = g('nc-title');
    if (!title.trim()) { toast('Title required'); return; }
    api('/tasks', 'POST', {
      title: title, priority: g('nc-pri'), domain: g('nc-dom'),
      target_url: g('nc-url'), prompt: g('nc-prompt'), status: 'pending', source: 'manual'
    }).then(function (res) {
      if (res.ok) { toast('Card added'); location.reload(); }
      else { toast('Could not add card'); }
    });
  };

  /* ---- status change / delete ---- */
  window.pscSetStatus = function (id, status) {
    api('/tasks/' + id, 'PUT', { status: status }).then(function (res) {
      if (res.ok) { toast('Moved to ' + status); location.reload(); }
      else { toast('Update failed'); }
    });
  };
  window.pscDelete = function (id) {
    if (!window.confirm('Delete this card?')) return;
    api('/tasks/' + id, 'DELETE').then(function (res) {
      if (res.ok) { toast('Deleted'); location.reload(); }
    });
  };

  /* ---- audit: re-scan + create fix card ---- */
  window.pscRescan = function (btn) {
    if (btn) { btn.disabled = true; btn.textContent = '↻ Scanning…'; }
    api('/scan', 'POST').then(function () { location.reload(); });
  };
  window.pscCreateFixCard = function (btn) {
    var name = btn.getAttribute('data-name') || 'Fix';
    var src = btn.getAttribute('data-source') || 'audit';
    var urls = btn.getAttribute('data-urls') || '';
    var prompt = 'Fix: ' + name + '.' + (urls ? ' Affected: ' + urls : '') + ' Verify each live after the change and update this card.';
    api('/tasks', 'POST', {
      title: name, priority: (btn.getAttribute('data-sev') === 'hi' ? 'P1' : 'P2'),
      domain: 'art', prompt: prompt, source: src, status: 'pending'
    }).then(function (res) {
      if (res.ok) { toast('Fix card added to Board'); }
      else { toast('Could not create card'); }
    });
  };

  window.pscSyncNow = function (btn) {
    if (btn) { btn.disabled = true; btn.textContent = 'Syncing…'; }
    api('/sync', 'POST').then(function () { location.reload(); })
      .catch(function () { if (btn) { btn.disabled = false; btn.textContent = 'Sync now'; } toast('Sync failed'); });
  };

  window.pscTest = function (which, btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Testing…';
    api('/connectors/test', 'POST', { which: which }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      toast((res.data && res.data.ok ? '✓ ' : '✗ ') + (res.data ? res.data.message : 'error'));
    });
  };
  window.pscScanKeys = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Scanning…';
    api('/connectors/scan', 'POST').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var box = document.getElementById('psc-scan-result'); if (!box) return;
      var found = res.data || {};
      var keys = Object.keys(found);
      if (!keys.length) { box.innerHTML = '<div style="color:var(--text3);font-size:13px">No keys found in other plugins.</div>'; return; }
      var html = '';
      keys.forEach(function (t) {
        var warn = t === 'anthropic' ? ' <span style="color:var(--amber)">— rotate before use</span>' : '';
        html += '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px">' +
          '<b style="text-transform:capitalize">' + t + '</b> <span style="color:var(--text3);font-family:var(--mono);font-size:12px">' + (found[t].masked || '') + '</span>' + warn +
          '<button class="psc-mini" style="margin-left:auto" onclick="pscImportKey(\'' + t + '\',this)">Import</button></div>';
      });
      box.innerHTML = html;
    });
  };
  window.pscImportKey = function (type, btn) {
    btn.disabled = true; btn.textContent = 'Importing…';
    api('/connectors/import', 'POST', { type: type }).then(function (res) {
      toast(res.data && res.data.ok ? '✓ ' + res.data.message : '✗ import failed');
      if (res.data && res.data.ok) setTimeout(function () { location.reload(); }, 900);
      else { btn.disabled = false; btn.textContent = 'Import'; }
    });
  };

  window.pscRunPageAudit = function (btn) {
    var url = (document.getElementById('psc-pa-url') || {}).value || '';
    if (!url) { toast('Enter a URL'); return; }
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Auditing…';
    var box = document.getElementById('psc-pa-result');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Fetching + scoring…</div>';
    api('/page-audit?force=1&url=' + encodeURIComponent(url), 'GET').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      if (!res.data || !box) { if (box) box.innerHTML = '<div style="color:var(--red)">Audit failed.</div>'; return; }
      box.innerHTML = pscRenderAudit(res.data);
    });
  };

  window.pscRunCQ = function (btn) {
    var url = (document.getElementById('psc-cq-url') || {}).value || '';
    if (!url) { toast('Enter a URL'); return; }
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Grading…';
    var box = document.getElementById('psc-cq-result');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Reading the page + grading against Google helpful-content signals…</div>';
    api('/content-quality?force=1&url=' + encodeURIComponent(url), 'GET').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      if (!box) return;
      if (d.error) { box.innerHTML = '<div style="color:var(--amber);font-size:13px">' + esc(d.message || 'Could not grade this page.') + '</div>'; return; }
      box.innerHTML = pscRenderCQ(d);
    });
  };

  function pscMdLite(t) {
    var out = esc(t);
    out = out.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
    var lines = out.split('\n'), html = '', inUl = false;
    lines.forEach(function (ln) {
      var m = ln.match(/^\s*[-*•]\s+(.*)$/);
      if (m) { if (!inUl) { html += '<ul style="margin:6px 0 6px 18px">'; inUl = true; } html += '<li style="margin:2px 0">' + m[1] + '</li>'; }
      else { if (inUl) { html += '</ul>'; inUl = false; } if (ln.trim() === '') html += '<div style="height:8px"></div>'; else html += '<div>' + ln + '</div>'; }
    });
    if (inUl) html += '</ul>';
    return html;
  }

  window.pscBrainAsk = function (btn, question) {
    if (!question || !question.trim()) { toast('Type a question'); return; }
    var qbox = document.getElementById('psc-brain-q'); if (qbox) qbox.value = question;
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Thinking…';
    var box = document.getElementById('psc-brain-answer');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Reading your live data + reasoning…</div>';
    api('/brain', 'POST', { question: question }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      if (!box) return;
      if (d.error) { box.innerHTML = '<div style="color:var(--amber);font-size:13px">' + esc(d.message || 'The brain could not answer.') + '</div>'; return; }
      box.innerHTML = '<div class="psc-card" style="background:var(--bg2);font-size:13.5px;line-height:1.6">' + pscMdLite(d.answer || '') +
        '<div style="font-size:11px;color:var(--text3);margin-top:10px;border-top:1px solid var(--border);padding-top:6px">grounded in: ' + esc((d.context_used || []).join(', ')) + ' · ' + esc(d.model || '') + '</div></div>';
    });
  };

  window.pscBrainSaveKB = function (btn) {
    var kb = (document.getElementById('psc-brain-kb') || {}).value || '';
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Saving…';
    api('/brain/knowledge', 'POST', { knowledge: kb }).then(function () {
      btn.disabled = false; btn.textContent = old; toast('Knowledge saved');
    });
  };

  function pscRenderCQ(d) {
    var g = d.graded || {};
    var score = g.quality_score != null ? g.quality_score : '—';
    var risk = (g.helpful_content_risk || 'unknown').toLowerCase();
    var riskColor = risk === 'low' ? 'var(--green)' : (risk === 'medium' ? 'var(--amber)' : 'var(--red)');
    var scoreColor = (typeof score === 'number' && score >= 75) ? 'var(--green)' : ((typeof score === 'number' && score >= 50) ? 'var(--amber)' : 'var(--red)');
    var head = '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
      '<div style="width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff;background:' + scoreColor + '">' + score + '</div>' +
      '<div><div style="font-weight:600">Helpful-content risk: <span style="color:' + riskColor + '">' + esc(risk) + '</span></div>' +
      '<div style="font-size:12px;color:var(--text3)">' + esc(d.word_count || 0) + ' words · graded by ' + esc(d.model || '') + '</div></div></div>';
    var verdict = g.verdict ? '<div style="font-size:13px;margin-bottom:12px">' + esc(g.verdict) + '</div>' : '';

    function block(title, arr, color, render) {
      if (!arr || !arr.length) return '';
      return '<div style="margin-bottom:10px"><div style="font-size:12px;font-weight:700;color:' + color + ';text-transform:uppercase;margin-bottom:4px">' + title + '</div>' +
        arr.map(render).join('') + '</div>';
    }
    var tells = block('AI / templated tells (' + (g.ai_tells || []).length + ')', g.ai_tells, 'var(--red)', function (t) {
      return '<div style="font-size:13px;color:var(--text2)">• “' + esc(t) + '”</div>';
    });
    var issues = block('Issues', g.issues, 'var(--amber)', function (i) {
      return '<div style="font-size:13px;color:var(--text2);margin-bottom:2px">• <b>' + esc((i.type || '').replace(/_/g, ' ')) + '</b> — ' + esc(i.detail) + '</div>';
    });
    var recs = block('Recommendations', g.recommendations, 'var(--accent)', function (r) {
      return '<div style="font-size:13px;color:var(--text)">→ ' + esc(r) + '</div>';
    });
    var strengths = block('Strengths', g.strengths, 'var(--green)', function (s) {
      return '<div style="font-size:13px;color:var(--text3)">✓ ' + esc(s) + '</div>';
    });
    return head + verdict + tells + issues + recs + strengths;
  }

  function pscRenderAudit(d) {
    var color = d.p0_fails > 0 ? 'var(--red)' : (d.score >= 85 ? 'var(--green)' : (d.score >= 65 ? 'var(--amber)' : 'var(--red)'));
    var m = d.meta || {};
    var edit = m.edit_url
      ? '<a href="' + esc(m.edit_url) + '" target="_blank" style="margin-left:auto;font-size:12px;font-weight:600;color:#fff;background:var(--accent);padding:6px 12px;border-radius:8px;text-decoration:none">Edit page →</a>' +
        (m.elementor_url ? '<a href="' + esc(m.elementor_url) + '" target="_blank" style="font-size:12px;color:var(--accent);text-decoration:none;margin-left:8px">Elementor</a>' : '')
      : '';
    var head = '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
      '<div style="width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff;background:' + color + '">' + d.score + '</div>' +
      '<div><div style="font-weight:600">' + esc(d.verdict) + '</div>' +
      '<div style="font-size:12px;color:var(--text3)">' + (d.p0_fails > 0 ? (d.p0_fails + ' P0 blocker(s) — fix first') : 'No P0 blockers') + ' · ' + esc(d.final_url || d.url) + '</div></div>' + edit + '</div>';

    var fails = (d.checks || []).filter(function (c) { return c.status === 'FAIL' || c.status === 'WARN'; });
    var rows = '';
    fails.forEach(function (c) {
      var badge = c.status === 'FAIL' ? 'var(--red)' : 'var(--amber)';
      var det = '';
      if (c.details) {
        if (c.details.skip) det += '<div style="font-size:12px;margin-top:4px">Skips at: <code style="font-family:var(--mono)">' + esc(c.details.skip) + '</code></div>';
        if (c.details.links) det += c.details.links.map(function (l) {
          return '<div style="font-size:12px;margin-top:3px">• “<b>' + esc(l.text) + '</b>” → <a href="' + esc(l.href) + '" target="_blank" style="color:var(--accent)">' + esc(l.href) + '</a></div>';
        }).join('');
        if (c.details.outline) det += '<details style="margin-top:4px"><summary style="font-size:12px;color:var(--accent);cursor:pointer">show full heading outline</summary>' +
          '<div style="font-size:12px;color:var(--text3);font-family:var(--mono);white-space:pre-wrap;margin-top:4px;max-height:220px;overflow:auto">' + c.details.outline.map(esc).join('\n') + '</div></details>';
      }
      rows += '<tr style="border-top:1px solid var(--border)">' +
        '<td style="padding:7px 8px;white-space:nowrap;vertical-align:top"><span style="font-size:11px;font-weight:700;color:#fff;background:' + badge + ';padding:1px 6px;border-radius:5px">' + c.status + '</span> <span style="font-size:11px;color:var(--text3)">' + c.priority + '</span></td>' +
        '<td style="padding:7px 8px;font-size:13px"><b>' + esc(c.section) + '</b> — ' + esc(c.finding) + (c.action ? '<div style="color:var(--text3);font-size:12px;margin-top:2px">→ ' + esc(c.action) + '</div>' : '') + det + '</td></tr>';
    });
    var board = rows
      ? '<table style="width:100%;border-collapse:collapse;margin-bottom:12px"><tbody>' + rows + '</tbody></table>'
      : '<div style="color:var(--green);font-size:13px;margin-bottom:12px">✓ All automated checks pass.</div>';

    var passN = (d.checks || []).filter(function (c) { return c.status === 'PASS'; }).length;
    var manual = '<div style="font-size:12px;color:var(--text3);margin-top:6px"><b style="color:var(--text2)">Manual review (not scored):</b> ' +
      (d.manual || []).map(esc).join(' · ') + '</div>';

    return head + board + '<div style="font-size:12px;color:var(--text3);margin-bottom:4px">' + passN + ' checks passing · ' + fails.length + ' to address</div>' + manual;
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[m]; }); }

  window.pscRefreshConversion = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Recomputing…';
    var m = location.search.match(/[?&]days=(\d+)/);
    var days = m ? m[1] : 28;
    api('/conversion?force=1&days=' + days, 'GET').then(function () { location.reload(); });
  };

  window.pscRefreshCompetitors = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Fetching…';
    api('/competitors?force=1', 'GET').then(function () { location.reload(); });
  };
  window.pscAddCompetitor = function (btn) {
    var el = document.getElementById('psc-comp-input');
    var d = el ? el.value.trim() : '';
    if (!d) { toast('Enter a domain'); return; }
    btn.disabled = true;
    api('/competitors/add', 'POST', { domain: d }).then(function (res) {
      btn.disabled = false;
      if (res.data && res.data.ok) { location.reload(); }
      else { toast('✗ ' + (res.data ? res.data.message : 'failed')); }
    });
  };
  window.pscRemoveCompetitor = function (domain, btn) {
    btn.disabled = true;
    api('/competitors/remove', 'POST', { domain: domain }).then(function () { location.reload(); });
  };

  window.pscTestAlert = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Sending…';
    api('/alerts/test', 'POST').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      toast((res.data && res.data.ok ? '✓ ' : '✗ ') + (res.data ? res.data.message : 'failed'));
    });
  };

  window.pscCheckUpdate = function (btn, install) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = install ? 'Updating…' : 'Checking…';
    var box = document.getElementById('psc-update-result');
    api('/update/check', 'POST', { install: !!install }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      var msg = { no_source: 'Set a manifest URL first.', up_to_date: 'Up to date (v' + (d.current || '?') + ').',
        available: 'Update available: v' + (d.current || '?') + ' → v' + (d.latest || '?') + '. Press “Update now” to install.',
        installed: '✓ Installed v' + (d.latest || '?') + '. Reloading…', error: '✗ ' + (d.message || 'error') }[d.status] || JSON.stringify(d);
      if (box) box.textContent = msg;
      if (d.status === 'installed') setTimeout(function () { location.reload(); }, 1200);
    });
  };

  /* ---- init ---- */
  document.addEventListener('DOMContentLoaded', function () {
    var el = root(); if (!el) return;
    try {
      var saved = localStorage.getItem('psc_theme');
      if (saved === 'dark') { el.setAttribute('data-theme', 'dark'); var b = document.querySelector('.psc-themebtn'); if (b) b.textContent = '☀️'; }
    } catch (e) {}
  });
})();
