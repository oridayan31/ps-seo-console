/* PS SEO Console — admin UI (vanilla). Talks to ps-seo/v1 via nonce. */
(function () {
  'use strict';
  var root = function () { return document.querySelector('.psc'); };

  /* ---- theme ---- */
  window.pscToggleTheme = function () {
    var el = root(); if (!el) return;
    var dark = el.getAttribute('data-theme') === 'dark';
    var next = dark ? 'light' : 'dark';
    el.setAttribute('data-theme', next);
    try { localStorage.setItem('psc_theme', next); } catch (e) {}
    var b = document.querySelector('.psc-themebtn'); if (b) b.textContent = next === 'dark' ? '☀️' : '🌙';
  };

  /* ---- REST helper ---- */
  function api(path, method, body) {
    return fetch(PSC.rest + path, {
      method: method || 'GET',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': PSC.nonce },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, data: j }; }); });
  }

  function toast(msg) {
    var t = document.createElement('div');
    t.className = 'psc-toast'; t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 300); }, 1800);
  }

  /* ---- board filter ---- */
  window.pscFilter = function () {
    var q = (document.getElementById('psc-search') || {}).value || '';
    q = q.toLowerCase();
    var p = (document.getElementById('psc-fpri') || {}).value || '';
    var d = (document.getElementById('psc-fdom') || {}).value || '';
    document.querySelectorAll('.psc-taskcard').forEach(function (c) {
      var okq = !q || c.textContent.toLowerCase().indexOf(q) > -1;
      var okp = !p || c.getAttribute('data-pri') === p;
      var okd = !d || c.getAttribute('data-dom') === d;
      c.style.display = (okq && okp && okd) ? '' : 'none';
    });
    document.querySelectorAll('.psc-board .col').forEach(function (col) {
      var n = col.querySelectorAll('.psc-taskcard:not([style*="none"])').length;
      var cnt = col.querySelector('.cnt'); if (cnt) cnt.textContent = n;
    });
  };

  /* ---- copy prompt ---- */
  window.pscCopy = function (btn) {
    var card = btn.closest('.psc-taskcard');
    var pr = card ? card.querySelector('.psc-prompt') : null;
    var txt = pr ? pr.textContent : (card ? card.querySelector('h3').textContent : '');
    if (navigator.clipboard) navigator.clipboard.writeText(txt.trim());
    var old = btn.textContent; btn.classList.add('copied'); btn.textContent = '✓ Copied';
    setTimeout(function () { btn.classList.remove('copied'); btn.textContent = old; }, 1400);
  };

  /* ---- new card ---- */
  window.pscToggleNew = function () {
    var f = document.getElementById('psc-newform'); if (f) f.classList.toggle('show');
  };
  window.pscSubmitNew = function () {
    var g = function (id) { var el = document.getElementById(id); return el ? el.value : ''; };
    var title = g('nc-title');
    if (!title.trim()) { toast('Title required'); return; }
    api('/tasks', 'POST', {
      title: title, priority: g('nc-pri'), domain: g('nc-dom'),
      target_url: g('nc-url'), prompt: g('nc-prompt'), status: 'pending', source: 'manual'
    }).then(function (res) {
      if (res.ok) { toast('Card added'); location.reload(); }
      else { toast('Could not add card'); }
    });
  };

  /* ---- status change / delete ---- */
  window.pscSetStatus = function (id, status) {
    api('/tasks/' + id, 'PUT', { status: status }).then(function (res) {
      if (res.ok) { toast('Moved to ' + status); location.reload(); }
      else { toast('Update failed'); }
    });
  };
  window.pscDelete = function (id) {
    if (!window.confirm('Delete this card?')) return;
    api('/tasks/' + id, 'DELETE').then(function (res) {
      if (res.ok) { toast('Deleted'); location.reload(); }
    });
  };

  /* ---- audit: re-scan + create fix card ---- */
  window.pscRescan = function (btn) {
    if (btn) { btn.disabled = true; btn.textContent = '↻ Scanning…'; }
    api('/scan', 'POST').then(function () { location.reload(); });
  };
  window.pscCreateFixCard = function (btn) {
    var name = btn.getAttribute('data-name') || 'Fix';
    var src = btn.getAttribute('data-source') || 'audit';
    var urls = btn.getAttribute('data-urls') || '';
    var prompt = 'Fix: ' + name + '.' + (urls ? ' Affected: ' + urls : '') + ' Verify each live after the change and update this card.';
    api('/tasks', 'POST', {
      title: name, priority: (btn.getAttribute('data-sev') === 'hi' ? 'P1' : 'P2'),
      domain: 'art', prompt: prompt, source: src, status: 'pending'
    }).then(function (res) {
      if (res.ok) { toast('Fix card added to Board'); }
      else { toast('Could not create card'); }
    });
  };

  window.pscSyncNow = function (btn) {
    if (btn) { btn.disabled = true; btn.textContent = 'Syncing…'; }
    api('/sync', 'POST').then(function () { location.reload(); })
      .catch(function () { if (btn) { btn.disabled = false; btn.textContent = 'Sync now'; } toast('Sync failed'); });
  };

  window.pscTest = function (which, btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Testing…';
    api('/connectors/test', 'POST', { which: which }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      toast((res.data && res.data.ok ? '✓ ' : '✗ ') + (res.data ? res.data.message : 'error'));
    });
  };
  window.pscScanKeys = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Scanning…';
    api('/connectors/scan', 'POST').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var box = document.getElementById('psc-scan-result'); if (!box) return;
      var found = res.data || {};
      var keys = Object.keys(found);
      if (!keys.length) { box.innerHTML = '<div style="color:var(--text3);font-size:13px">No keys found in other plugins.</div>'; return; }
      var html = '';
      keys.forEach(function (t) {
        var warn = t === 'anthropic' ? ' <span style="color:var(--amber)">— rotate before use</span>' : '';
        html += '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px">' +
          '<b style="text-transform:capitalize">' + t + '</b> <span style="color:var(--text3);font-family:var(--mono);font-size:12px">' + (found[t].masked || '') + '</span>' + warn +
          '<button class="psc-mini" style="margin-left:auto" onclick="pscImportKey(\'' + t + '\',this)">Import</button></div>';
      });
      box.innerHTML = html;
    });
  };
  window.pscImportKey = function (type, btn) {
    btn.disabled = true; btn.textContent = 'Importing…';
    api('/connectors/import', 'POST', { type: type }).then(function (res) {
      toast(res.data && res.data.ok ? '✓ ' + res.data.message : '✗ import failed');
      if (res.data && res.data.ok) setTimeout(function () { location.reload(); }, 900);
      else { btn.disabled = false; btn.textContent = 'Import'; }
    });
  };

  function pscCrawlBar(done, total) {
    var prog = document.getElementById('psc-crawl-progress'); if (!prog) return;
    var pct = total ? Math.round(done / total * 100) : 0;
    prog.innerHTML = '<div style="font-size:12px;color:var(--text3);margin-bottom:4px">' + done + ' / ' + total + ' pages' + (done < total ? ' · runs in the background — you can leave this tab' : ' · done') + '</div>' +
      '<div style="height:8px;background:var(--bg2);border-radius:5px;overflow:hidden"><div style="height:100%;width:' + pct + '%;background:var(--accent);transition:width .2s"></div></div>';
  }
  var pscCrawlIv = null;
  function pscCrawlPoll() {
    if (pscCrawlIv) return;
    pscCrawlIv = setInterval(function () {
      api('/crawl/tick', 'POST', { size: 5 }).then(function (r) {
        var d = r.data || {}; pscCrawlBar(d.done || 0, d.total || 0);
        if ((d.done || 0) > 0) pscCrawlReport();           // add each finished batch to the results live
        if (d.complete) { clearInterval(pscCrawlIv); pscCrawlIv = null; var b = document.getElementById('psc-crawl-btn'); if (b) { b.disabled = false; b.textContent = 'Re-crawl site'; } pscCrawlReport(); }
      });
    }, 1500);
  }
  window.pscCrawlStart = function (btn) {
    btn.id = 'psc-crawl-btn'; btn.disabled = true; btn.textContent = 'Starting…';
    var rep = document.getElementById('psc-crawl-report'); if (rep) rep.innerHTML = '';
    var prog = document.getElementById('psc-crawl-progress'); if (prog) prog.innerHTML = '<div style="font-size:13px;color:var(--text3)">Reading sitemap…</div>';
    api('/crawl/start', 'POST', {}).then(function (res) {
      var total = (res.data || {}).total || 0;
      if (!total) { if (prog) prog.innerHTML = '<div style="color:var(--amber)">No sitemap URLs found.</div>'; btn.disabled = false; btn.textContent = 'Crawl entire site'; return; }
      btn.textContent = 'Crawling…'; pscCrawlBar(0, total); pscCrawlPoll();
    });
  };

  window.pscCrawlFix = function (btn, url, code) {
    var t = btn.textContent; btn.disabled = true; btn.textContent = 'fixing…';
    api('/crawl/fix', 'POST', { url: url, code: code }).then(function (r) {
      var d = r.data || {};
      if (d.ok) { btn.outerHTML = '<span style="font-size:11px;color:var(--green)">✓ ' + esc(d.field) + ': “' + esc(d.value) + '”</span>'; toast('Fixed + logged to Changes'); }
      else { btn.disabled = false; btn.textContent = t; toast(d.message || 'Could not fix'); }
    });
  };

  function pscCrawlReport() {
    api('/crawl/report', 'GET').then(function (r) {
      var d = r.data || {}; var box = document.getElementById('psc-crawl-report');
      if (!box || d.status !== 'ok') return;
      var b = d.bands || {}; var diff = d.diff || {};
      var diffHtml = '';
      if (diff.had_previous) {
        diffHtml = '<div style="background:var(--bg2);border-radius:8px;padding:8px 10px;margin-bottom:10px;font-size:13px">' +
          '<b style="color:var(--green)">' + (diff.fixed_count || 0) + ' improved</b> since last crawl' +
          (diff.regressed_count ? ' · <b style="color:var(--red)">' + diff.regressed_count + ' regressed</b>' : '') +
          (diff.new_count ? ' · ' + diff.new_count + ' new' : '') +
          ((diff.fixed || []).length ? '<div style="margin-top:6px;color:var(--text3);font-size:12px">' + diff.fixed.slice(0, 6).map(function (f) { return '✓ ' + esc(f.url.replace(/^https?:\/\/[^/]+/, '')) + ' (' + f.from + '→' + f.to + (f.resolved && f.resolved.length ? ', fixed: ' + esc(f.resolved.join(', ')) : '') + ')'; }).join('<br>') + '</div>' : '') +
          '</div>';
      }
      var head = '<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:10px">' +
        '<div style="font-size:28px;font-weight:700">' + d.avg_score + '<span style="font-size:13px;color:var(--text3);font-weight:400"> avg</span></div>' +
        '<div style="font-size:13px;color:var(--text2)">' + d.crawled + ' pages · <span style="color:var(--green)">' + (b.good || 0) + ' good</span> · <span style="color:var(--amber)">' + (b.ok || 0) + ' ok</span> · <span style="color:var(--red)">' + (b.poor || 0) + ' poor</span>' +
        (d.noindex && d.noindex.length ? ' · <span style="color:var(--red)">' + d.noindex.length + ' noindex</span>' : '') + (d.running ? ' · <span style="color:var(--accent)">crawling…</span>' : '') + '</div></div>';
      var tplHtml = '';
      if (d.template_issues && d.template_issues.length) {
        tplHtml = '<div style="font-size:12px;color:var(--text3);margin-bottom:4px">Template-level issues <span style="color:var(--text3)">(one fix in the template clears every page of that type)</span>:</div>' +
          d.template_issues.map(function (t) {
            return '<div style="background:var(--bg2);border-left:3px solid var(--amber);border-radius:8px;padding:8px 10px;margin-bottom:6px">' +
              '<div style="font-size:13px"><b>' + esc(t.template) + '</b> — ' + esc(t.code.replace(/_/g, ' ')) + ' on <b>' + t.count + '</b> of ' + t.template_pages + ' pages (' + t.share + '%)</div>' +
              '<div style="font-size:12px;color:var(--text3);margin-top:2px">e.g. ' + esc(t.sample) + '</div>' +
              '<div style="font-size:11.5px;color:var(--text3);margin-top:2px">' + (t.examples || []).map(esc).join(' · ') + ' — fix once in the ' + esc(t.template.toLowerCase()) + ' template (Elementor theme builder), not per page.</div>' +
              '</div>';
          }).join('');
      }
      var rows = (d.worst || []).map(function (w) {
        var col = w.score >= 85 ? 'var(--green)' : (w.score >= 65 ? 'var(--amber)' : 'var(--red)');
        var edit = w.edit_url ? '<a href="' + esc(w.edit_url) + '" target="_blank" style="color:var(--accent);font-size:12px;text-decoration:none;white-space:nowrap">edit →</a>' : '';
        var issuesHtml = (w.issues || []).map(function (it) {
          if (typeof it === 'string') return '<div style="color:var(--text3);margin:1px 0">• ' + esc(it) + '</div>';
          var fix = it.f ? ' <button onclick="pscCrawlFix(this,' + JSON.stringify(w.url).replace(/"/g, '&quot;') + ',' + JSON.stringify(it.c).replace(/"/g, '&quot;') + ')" style="font-size:11px;color:#fff;background:var(--green);border:none;border-radius:5px;padding:1px 8px;cursor:pointer;margin-left:4px">⚡ Fix now</button>' : '';
          return '<div style="color:var(--text3);margin:2px 0">• ' + esc(it.d) + fix + '</div>';
        }).join('');
        var tpl = w.template ? '<span style="font-size:10px;color:var(--text3);background:var(--bg2);border-radius:4px;padding:0 5px;margin-left:5px">' + esc(w.template) + '</span>' : '';
        return '<tr style="border-top:1px solid var(--border)">' +
          '<td style="padding:6px 8px;font-weight:700;color:' + col + ';vertical-align:top">' + w.score + '</td>' +
          '<td style="padding:6px 8px;font-size:12px"><a href="' + esc(w.url) + '" target="_blank" style="color:var(--text2);font-weight:600">' + esc(w.url.replace(/^https?:\/\/[^/]+/, '')) + '</a>' + tpl + issuesHtml + '</td>' +
          '<td style="padding:6px 8px;text-align:right;vertical-align:top">' + edit + '</td></tr>';
      }).join('');
      var pagesHtml = rows ? '<div style="font-size:12px;color:var(--text3);margin-bottom:4px">Page-specific issues:</div><table style="width:100%;border-collapse:collapse">' + rows + '</table>' : '';
      box.innerHTML = diffHtml + head + tplHtml + pagesHtml;
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (!document.getElementById('psc-crawl-report')) return;
    api('/crawl/report', 'GET').then(function (r) {
      var d = r.data || {};
      if (d.status === 'ok') { pscCrawlReport(); if (d.running) pscCrawlPoll(); }
    });
  });

  window.pscRunPageAudit = function (btn) {
    var url = (document.getElementById('psc-pa-url') || {}).value || '';
    if (!url) { toast('Enter a URL'); return; }
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Auditing…';
    var box = document.getElementById('psc-pa-result');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Fetching + scoring…</div>';
    api('/page-audit?force=1&url=' + encodeURIComponent(url), 'GET').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      if (!res.data || !box) { if (box) box.innerHTML = '<div style="color:var(--red)">Audit failed.</div>'; return; }
      box.innerHTML = pscRenderAudit(res.data);
    });
  };

  window.pscRunCQ = function (btn) {
    var url = (document.getElementById('psc-cq-url') || {}).value || '';
    if (!url) { toast('Enter a URL'); return; }
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Grading…';
    var box = document.getElementById('psc-cq-result');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Reading the page + grading against Google helpful-content signals…</div>';
    api('/content-quality?force=1&url=' + encodeURIComponent(url), 'GET').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      if (!box) return;
      if (d.error) { box.innerHTML = '<div style="color:var(--amber);font-size:13px">' + esc(d.message || 'Could not grade this page.') + '</div>'; return; }
      box.innerHTML = pscRenderCQ(d);
    });
  };

  function pscMdLite(t) {
    var out = esc(t);
    out = out.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
    var lines = out.split('\n'), html = '', inUl = false;
    lines.forEach(function (ln) {
      var m = ln.match(/^\s*[-*•]\s+(.*)$/);
      if (m) { if (!inUl) { html += '<ul style="margin:6px 0 6px 18px">'; inUl = true; } html += '<li style="margin:2px 0">' + m[1] + '</li>'; }
      else { if (inUl) { html += '</ul>'; inUl = false; } if (ln.trim() === '') html += '<div style="height:8px"></div>'; else html += '<div>' + ln + '</div>'; }
    });
    if (inUl) html += '</ul>';
    return html;
  }

  window.pscBrainAsk = function (btn, question) {
    if (!question || !question.trim()) { toast('Type a question'); return; }
    var qbox = document.getElementById('psc-brain-q'); if (qbox) qbox.value = question;
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Thinking…';
    var box = document.getElementById('psc-brain-answer');
    if (box) box.innerHTML = '<div style="color:var(--text3);font-size:13px">Reading your live data + reasoning…</div>';
    api('/brain', 'POST', { question: question }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      if (!box) return;
      if (d.error) { box.innerHTML = '<div style="color:var(--amber);font-size:13px">' + esc(d.message || 'The brain could not answer.') + '</div>'; return; }
      box.innerHTML = '<div class="psc-card" style="background:var(--bg2);font-size:13.5px;line-height:1.6">' + pscMdLite(d.answer || '') +
        '<div style="font-size:11px;color:var(--text3);margin-top:10px;border-top:1px solid var(--border);padding-top:6px">grounded in: ' + esc((d.context_used || []).join(', ')) + ' · ' + esc(d.model || '') + '</div></div>';
    });
  };

  window.pscBrainRefresh = function (el) {
    var t = el.textContent; el.textContent = 'thinking…';
    api('/brain/refresh', 'POST', {}).then(function (res) {
      var d = res.data || {}; el.textContent = t;
      var box = document.getElementById('psc-brain-read');
      if (d.ok && box) { box.innerHTML = pscMdLite(d.text || ''); toast('Brain refreshed'); }
      else toast(d.message || 'Refresh failed');
    });
  };

  window.pscBrainSaveKB = function (btn) {
    var kb = (document.getElementById('psc-brain-kb') || {}).value || '';
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Saving…';
    api('/brain/knowledge', 'POST', { knowledge: kb }).then(function () {
      btn.disabled = false; btn.textContent = old; toast('Knowledge saved');
    });
  };

  function pscRenderCQ(d) {
    var g = d.graded || {};
    var score = g.quality_score != null ? g.quality_score : '—';
    var risk = (g.helpful_content_risk || 'unknown').toLowerCase();
    var riskColor = risk === 'low' ? 'var(--green)' : (risk === 'medium' ? 'var(--amber)' : 'var(--red)');
    var scoreColor = (typeof score === 'number' && score >= 75) ? 'var(--green)' : ((typeof score === 'number' && score >= 50) ? 'var(--amber)' : 'var(--red)');
    var head = '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
      '<div style="width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff;background:' + scoreColor + '">' + score + '</div>' +
      '<div><div style="font-weight:600">Helpful-content risk: <span style="color:' + riskColor + '">' + esc(risk) + '</span></div>' +
      '<div style="font-size:12px;color:var(--text3)">' + esc(d.word_count || 0) + ' words · graded by ' + esc(d.model || '') + '</div></div></div>';
    var verdict = g.verdict ? '<div style="font-size:13px;margin-bottom:12px">' + esc(g.verdict) + '</div>' : '';

    function block(title, arr, color, render) {
      if (!arr || !arr.length) return '';
      return '<div style="margin-bottom:10px"><div style="font-size:12px;font-weight:700;color:' + color + ';text-transform:uppercase;margin-bottom:4px">' + title + '</div>' +
        arr.map(render).join('') + '</div>';
    }
    var tells = block('AI / templated tells (' + (g.ai_tells || []).length + ')', g.ai_tells, 'var(--red)', function (t) {
      return '<div style="font-size:13px;color:var(--text2)">• “' + esc(t) + '”</div>';
    });
    var issues = block('Issues', g.issues, 'var(--amber)', function (i) {
      return '<div style="font-size:13px;color:var(--text2);margin-bottom:2px">• <b>' + esc((i.type || '').replace(/_/g, ' ')) + '</b> — ' + esc(i.detail) + '</div>';
    });
    var recs = block('Recommendations', g.recommendations, 'var(--accent)', function (r) {
      return '<div style="font-size:13px;color:var(--text)">→ ' + esc(r) + '</div>';
    });
    var strengths = block('Strengths', g.strengths, 'var(--green)', function (s) {
      return '<div style="font-size:13px;color:var(--text3)">✓ ' + esc(s) + '</div>';
    });
    return head + verdict + tells + issues + recs + strengths;
  }

  function pscRenderAudit(d) {
    var color = d.p0_fails > 0 ? 'var(--red)' : (d.score >= 85 ? 'var(--green)' : (d.score >= 65 ? 'var(--amber)' : 'var(--red)'));
    var m = d.meta || {};
    var edit = m.edit_url
      ? '<a href="' + esc(m.edit_url) + '" target="_blank" style="margin-left:auto;font-size:12px;font-weight:600;color:#fff;background:var(--accent);padding:6px 12px;border-radius:8px;text-decoration:none">Edit page →</a>' +
        (m.elementor_url ? '<a href="' + esc(m.elementor_url) + '" target="_blank" style="font-size:12px;color:var(--accent);text-decoration:none;margin-left:8px">Elementor</a>' : '')
      : '';
    var head = '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
      '<div style="width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff;background:' + color + '">' + d.score + '</div>' +
      '<div><div style="font-weight:600">' + esc(d.verdict) + '</div>' +
      '<div style="font-size:12px;color:var(--text3)">' + (d.p0_fails > 0 ? (d.p0_fails + ' P0 blocker(s) — fix first') : 'No P0 blockers') + ' · ' + esc(d.final_url || d.url) + '</div></div>' + edit + '</div>';

    var fails = (d.checks || []).filter(function (c) { return c.status === 'FAIL' || c.status === 'WARN'; });
    var rows = '';
    fails.forEach(function (c) {
      var badge = c.status === 'FAIL' ? 'var(--red)' : 'var(--amber)';
      var det = '';
      if (c.details) {
        if (c.details.skip) det += '<div style="font-size:12px;margin-top:4px">Skips at: <code style="font-family:var(--mono)">' + esc(c.details.skip) + '</code></div>';
        if (c.details.links) det += c.details.links.map(function (l) {
          return '<div style="font-size:12px;margin-top:3px">• “<b>' + esc(l.text) + '</b>” → <a href="' + esc(l.href) + '" target="_blank" style="color:var(--accent)">' + esc(l.href) + '</a></div>';
        }).join('');
        if (c.details.outline) det += '<details style="margin-top:4px"><summary style="font-size:12px;color:var(--accent);cursor:pointer">show full heading outline</summary>' +
          '<div style="font-size:12px;color:var(--text3);font-family:var(--mono);white-space:pre-wrap;margin-top:4px;max-height:220px;overflow:auto">' + c.details.outline.map(esc).join('\n') + '</div></details>';
      }
      rows += '<tr style="border-top:1px solid var(--border)">' +
        '<td style="padding:7px 8px;white-space:nowrap;vertical-align:top"><span style="font-size:11px;font-weight:700;color:#fff;background:' + badge + ';padding:1px 6px;border-radius:5px">' + c.status + '</span> <span style="font-size:11px;color:var(--text3)">' + c.priority + '</span></td>' +
        '<td style="padding:7px 8px;font-size:13px"><b>' + esc(c.section) + '</b> — ' + esc(c.finding) + (c.action ? '<div style="color:var(--text3);font-size:12px;margin-top:2px">→ ' + esc(c.action) + '</div>' : '') + det + '</td></tr>';
    });
    var board = rows
      ? '<table style="width:100%;border-collapse:collapse;margin-bottom:12px"><tbody>' + rows + '</tbody></table>'
      : '<div style="color:var(--green);font-size:13px;margin-bottom:12px">✓ All automated checks pass.</div>';

    var passN = (d.checks || []).filter(function (c) { return c.status === 'PASS'; }).length;
    var manual = '<div style="font-size:12px;color:var(--text3);margin-top:6px"><b style="color:var(--text2)">Manual review (not scored):</b> ' +
      (d.manual || []).map(esc).join(' · ') + '</div>';

    return head + board + '<div style="font-size:12px;color:var(--text3);margin-bottom:4px">' + passN + ' checks passing · ' + fails.length + ' to address</div>' + manual;
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[m]; }); }

  window.pscRefreshConversion = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Recomputing…';
    var m = location.search.match(/[?&]days=(\d+)/);
    var days = m ? m[1] : 28;
    api('/conversion?force=1&days=' + days, 'GET').then(function () { location.reload(); });
  };

  window.pscRefreshCompetitors = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Fetching…';
    api('/competitors?force=1', 'GET').then(function () { location.reload(); });
  };
  window.pscAddCompetitor = function (btn) {
    var el = document.getElementById('psc-comp-input');
    var d = el ? el.value.trim() : '';
    if (!d) { toast('Enter a domain'); return; }
    btn.disabled = true;
    api('/competitors/add', 'POST', { domain: d }).then(function (res) {
      btn.disabled = false;
      if (res.data && res.data.ok) { location.reload(); }
      else { toast('✗ ' + (res.data ? res.data.message : 'failed')); }
    });
  };
  window.pscRemoveCompetitor = function (domain, btn) {
    btn.disabled = true;
    api('/competitors/remove', 'POST', { domain: domain }).then(function () { location.reload(); });
  };

  window.pscTestAlert = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'Sending…';
    api('/alerts/test', 'POST').then(function (res) {
      btn.disabled = false; btn.textContent = old;
      toast((res.data && res.data.ok ? '✓ ' : '✗ ') + (res.data ? res.data.message : 'failed'));
    });
  };

  window.pscCheckUpdate = function (btn, install) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = install ? 'Updating…' : 'Checking…';
    var box = document.getElementById('psc-update-result');
    api('/update/check', 'POST', { install: !!install }).then(function (res) {
      btn.disabled = false; btn.textContent = old;
      var d = res.data || {};
      var msg = { no_source: 'Set a manifest URL first.', up_to_date: 'Up to date (v' + (d.current || '?') + ').',
        available: 'Update available: v' + (d.current || '?') + ' → v' + (d.latest || '?') + '. Press “Update now” to install.',
        installed: '✓ Installed v' + (d.latest || '?') + '. Reloading…', error: '✗ ' + (d.message || 'error') }[d.status] || JSON.stringify(d);
      if (box) box.textContent = msg;
      if (d.status === 'installed') setTimeout(function () { location.reload(); }, 1200);
    });
  };

  /* ---- init ---- */
  document.addEventListener('DOMContentLoaded', function () {
    var el = root(); if (!el) return;
    try {
      var saved = localStorage.getItem('psc_theme');
      if (saved === 'dark') { el.setAttribute('data-theme', 'dark'); var b = document.querySelector('.psc-themebtn'); if (b) b.textContent = '☀️'; }
    } catch (e) {}
  });
  /* ================= Overview: progress, opportunities, research ================= */
  window.pscToggleAddChange = function () {
    var b = document.getElementById('psc-addchange'); if (b) b.style.display = b.style.display === 'none' ? 'block' : 'none';
  };
  window.pscAddChange = function (btn) {
    var title = (document.getElementById('psc-ch-title') || {}).value || '';
    var url = (document.getElementById('psc-ch-url') || {}).value || '';
    if (!title || !url) { toast('Add a title + URL'); return; }
    var body = { title: title, url: url, kind: (document.getElementById('psc-ch-kind') || {}).value, date: (document.getElementById('psc-ch-date') || {}).value };
    btn.disabled = true;
    api('/changes', 'POST', body).then(function () { btn.disabled = false; pscToggleAddChange(); document.getElementById('psc-ch-title').value = ''; document.getElementById('psc-ch-url').value = ''; toast('Tracking this change'); pscLoadChanges(); });
  };
  window.pscDelChange = function (id) {
    api('/changes/' + id, 'DELETE').then(function () { pscLoadChanges(); });
  };

  function fmtDelta(n, unit, invert) {
    if (n === null || n === undefined) return '';
    var up = invert ? n < 0 : n > 0; var down = invert ? n > 0 : n < 0;
    var col = n === 0 ? 'var(--text3)' : (up ? 'var(--green)' : 'var(--red)');
    var sign = n > 0 ? '+' : '';
    return '<span style="color:' + col + '">' + sign + n + (unit || '') + '</span>';
  }
  var STATUS = { too_early: ['Too early', 'var(--text3)'], developing: ['Developing', 'var(--amber)'], measurable: ['Measurable', 'var(--green)'] };

  function pscLoadChanges() {
    var box = document.getElementById('psc-changes-list'); if (!box) return;
    api('/changes', 'GET').then(function (r) {
      var list = r.data || [];
      if (!list.length) { box.innerHTML = '<div style="font-size:13px;color:var(--text3)">No changes logged yet. Log one above and it\'ll track the effect.</div>'; return; }
      box.innerHTML = list.map(function (c) {
        var st = STATUS[c.status] || ['', 'var(--text3)'];
        var d = c.delta || {}; var b = c.baseline || {}; var l = c.latest || {};
        var impact = c.baseline && c.latest
          ? 'clicks ' + fmtDelta(d.clicks) + ' · impr ' + fmtDelta(d.impr) + ' · CTR ' + fmtDelta(d.ctr, 'pt') + ' · pos ' + fmtDelta(d.pos, '', false) + (d.pos ? ' (' + (d.pos > 0 ? 'up' : 'down') + ')' : '')
          : '<span style="color:var(--text3)">baseline captured — waiting for Search Console data</span>';
        return '<div style="border-top:1px solid var(--border);padding:9px 0">' +
          '<div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:13px">' + esc(c.title) + '</b>' +
          '<span style="font-size:11px;font-weight:700;color:#fff;background:' + st[1] + ';padding:1px 7px;border-radius:5px;white-space:nowrap">' + st[0] + '</span></div>' +
          '<div style="font-size:12px;color:var(--text3);margin:2px 0"><a href="' + esc(c.url) + '" target="_blank" style="color:var(--text3)">' + esc(c.url.replace(/^https?:\/\/[^/]+/, '')) + '</a> · ' + esc(c.date) + ' · day ' + c.elapsed_days + ' of ~' + c.recommended_wait + '</div>' +
          '<div style="font-size:12.5px">' + impact + '</div>' +
          '<div style="margin-top:3px"><a href="#" onclick="pscDelChange(\'' + c.id + '\');return false;" style="font-size:11px;color:var(--text3)">remove</a></div>' +
          '</div>';
      }).join('');
    });
  }

  window.pscQueueAction = function (btn, title, url, action, kind) {
    btn.disabled = true; btn.textContent = 'Adding…';
    api('/tasks', 'POST', { title: title, priority: 'P2', domain: 'art', status: 'pending', source: 'opportunity', target_url: url, prompt: action }).then(function () {
      btn.textContent = '✓ On board'; toast('Added to Board');
    });
  };

  function pscLoadOpps() {
    var pb = document.getElementById('psc-opps-pages'), kb = document.getElementById('psc-opps-keywords');
    if (!pb) return;
    api('/opportunities', 'GET').then(function (r) {
      var d = r.data || {};
      var pages = d.pages || [];
      pb.innerHTML = pages.length ? pages.map(function (p) {
        var edit = p.edit_url ? '<a href="' + esc(p.edit_url) + '" target="_blank" style="color:var(--accent);font-size:12px;text-decoration:none">edit page →</a>' : '';
        var tag = p.type === 'ctr_upside' ? 'CTR upside' : 'striking distance';
        var how = (p.how && p.how.length) ? '<details style="margin-top:5px"><summary style="font-size:12px;color:var(--accent);cursor:pointer">how to do it</summary><ol style="margin:6px 0 4px 18px;padding:0">' + p.how.map(function (s) { return '<li style="font-size:12.5px;color:var(--text2);margin:3px 0">' + esc(s) + '</li>'; }).join('') + '</ol></details>' : '';
        return '<div style="border-top:1px solid var(--border);padding:9px 0">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><a href="' + esc(p.url) + '" target="_blank" style="font-size:13px;font-weight:600;color:var(--text)">' + esc(p.url.replace(/^https?:\/\/[^/]+/, '')) + '</a>' +
          '<span style="font-size:11px;color:var(--text3);white-space:nowrap">pos ' + p.position + ' · ' + p.impressions + ' impr' + (p.ctr != null ? ' · ' + p.ctr + '% CTR' : '') + '</span></div>' +
          '<div style="font-size:11px;color:var(--accent);margin:2px 0">' + tag + '</div>' +
          '<div style="font-size:12.5px;color:var(--text2)">' + esc(p.action) + '</div>' + how +
          '<div style="margin-top:5px;display:flex;gap:12px;align-items:center">' + edit +
          '<button class="psc-btn ghost sm" type="button" onclick="pscQueueAction(this, ' + JSON.stringify('Push: ' + p.url.replace(/^https?:\/\/[^/]+/, '')).replace(/"/g, '&quot;') + ', ' + JSON.stringify(p.url).replace(/"/g, '&quot;') + ', ' + JSON.stringify((p.action + ' — ' + (p.how || []).join(' ')).trim()).replace(/"/g, '&quot;') + ')">+ Board</button></div>' +
          '</div>';
      }).join('') : '<div style="font-size:13px;color:var(--text3)">No page opportunities in range yet.</div>';

      var kw = d.keywords || [];
      if (kb) kb.innerHTML = kw.length ? kw.map(function (q) {
        var how = (q.how && q.how.length) ? '<details style="margin-top:3px"><summary style="font-size:12px;color:var(--accent);cursor:pointer">how to do it</summary><ol style="margin:6px 0 4px 18px;padding:0">' + q.how.map(function (s) { return '<li style="font-size:12.5px;color:var(--text2);margin:3px 0">' + esc(s) + '</li>'; }).join('') + '</ol></details>' : '';
        return '<div style="border-top:1px solid var(--border);padding:8px 0"><div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:13px">' + esc(q.query) + '</b><span style="font-size:11px;color:var(--text3);white-space:nowrap">pos ' + q.position + ' · ' + q.impressions + ' impr</span></div>' +
          '<div style="font-size:12px;color:var(--text3)">' + esc(q.action) + '</div>' + how + '</div>';
      }).join('') : '<div style="font-size:13px;color:var(--text3)">No keyword opportunities in range yet.</div>';
    });
  }

  window.pscProposeResearch = function (btn) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'thinking…';
    api('/brain/research', 'POST', {}).then(function () { btn.disabled = false; btn.textContent = old; pscLoadResearch(); });
  };
  window.pscApproveResearch = function (btn, id) {
    var old = btn.textContent; btn.disabled = true; btn.textContent = 'researching…';
    api('/brain/research/approve', 'POST', { id: id }).then(function (r) { btn.disabled = false; btn.textContent = old; toast('Folded into the brain'); pscLoadResearch(); });
  };
  function pscLoadResearch() {
    var box = document.getElementById('psc-research-list'); if (!box) return;
    api('/brain/research', 'GET').then(function (r) {
      var list = r.data || [];
      if (!list.length) { box.innerHTML = '<div style="font-size:13px;color:var(--text3)">No open research — tap “Ask the brain what it needs”.</div>'; return; }
      box.innerHTML = list.map(function (q) {
        if (q.status === 'done') {
          return '<div style="border-top:1px solid var(--border);padding:9px 0">' +
            '<div style="font-size:13px;font-weight:600;color:var(--green)">✓ ' + esc(q.question) + '</div>' +
            '<div style="font-size:12.5px;color:var(--text2);margin-top:3px">' + pscMdLite(q.finding || '') + '</div></div>';
        }
        return '<div style="border-top:1px solid var(--border);padding:9px 0">' +
          '<div style="font-size:13px;font-weight:600">' + esc(q.question) + (q.web ? ' <span style="font-size:10px;color:#fff;background:var(--accent);padding:1px 6px;border-radius:5px">web</span>' : '') + '</div>' +
          '<div style="font-size:12px;color:var(--text3);margin:2px 0">' + esc(q.why) + '</div>' +
          '<button class="psc-btn sm" type="button" onclick="pscApproveResearch(this, \'' + q.id + '\')">Approve &amp; run</button></div>';
      }).join('');
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (document.getElementById('psc-changes-list')) { pscLoadChanges(); pscLoadOpps(); }
    if (document.getElementById('psc-sh-content')) pscLoadSiteHealth();
    if (document.getElementById('psc-research-list')) pscLoadResearch();
  });
  /* ================= site-wide health boxes ================= */
  function shScore(el, s) { if (el) { el.textContent = (s === null || s === undefined) ? 'tap to expand' : ('score ' + s + '/100'); el.style.color = s >= 80 ? 'var(--green)' : (s >= 55 ? 'var(--amber)' : 'var(--red)'); } }
  function shActions(a) { return (a && a.length) ? '<div style="margin-top:8px">' + a.map(function (x) { return '<div style="font-size:12.5px;margin:3px 0">→ ' + esc(x) + '</div>'; }).join('') + '</div>' : ''; }
  function shList(items, fmt) { return items && items.length ? '<div style="margin-top:6px">' + items.map(fmt).join('') + '</div>' : ''; }
  var shRow = function (t) { return '<div style="font-size:12px;color:var(--text3);margin:2px 0">' + t + '</div>'; };

  function pscLoadSiteHealth() {
    var c = document.getElementById('psc-sh-content'); if (!c) return;
    api('/site-health', 'GET').then(function (r) {
      var d = r.data || {};
      var noCrawl = '<div style="font-size:13px;color:var(--text3)">Run a whole-site crawl first (Audit tab) — these checks read the crawl graph.</div>';

      var ch = d.content || {};
      shScore(document.getElementById('psc-sh-content-score'), ch.score);
      c.innerHTML = ch.status !== 'ok' ? noCrawl :
        '<div style="font-size:13px"><b>' + (ch.ai_count + ch.robotic_count) + '</b> read AI-written · <b>' + ch.stuffed_count + '</b> keyword-stuffed · <b>' + ch.thin_count + '</b> under-length · <b>' + ch.duplicate_groups + '</b> duplicate groups · <b>' + ch.no_h1 + '</b> no H1 · <b>' + ch.missing_meta + '</b> no meta <span style="color:var(--text3)">(of ' + ch.total + ' pages, deep-scanned)</span></div>' +
        shActions(ch.actions) +
        shList(ch.ai, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> <span style="color:var(--amber)">[' + esc(t.template) + ']</span> — ' + esc(t.why)); }) +
        shList(ch.robotic, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + esc(t.why)); }) +
        shList(ch.stuffed, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + esc(t.why)); }) +
        shList(ch.thin, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + t.words + ' words <span style="color:var(--text3)">[' + esc(t.template || '') + ', expect ' + esc(t.expect || '') + ']</span>'); }) +
        shList(ch.duplicates, function (g) { return shRow('≈ ' + g.map(esc).join(' · ')); });

      var lh = d.links || {};
      shScore(document.getElementById('psc-sh-links-score'), lh.score);
      var lbox = document.getElementById('psc-sh-links');
      if (lbox) lbox.innerHTML = lh.status === 'no_links' ? '<div style="font-size:13px;color:var(--amber)">' + esc(lh.note || 'Re-crawl to build the link graph.') + '</div>' : (lh.status !== 'ok' ? noCrawl :
        '<div style="font-size:13px"><b>' + lh.underlinked_count + '</b> under-linked winners · <b>' + lh.orphan_count + '</b> orphans · <b>' + lh.wasted_count + '</b> links to dead pages · <b>' + (lh.dense_count || 0) + '</b> unnatural density · <b>' + (lh.generic_count || 0) + '</b> generic anchors · <b>' + lh.over_count + '</b> over-linked</div>' +
        shActions(lh.actions) +
        shList(lh.underlinked, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + t.clicks + ' clicks, only ' + t.inbound + ' links in'); }) +
        shList(lh.dense, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + esc(t.why)); }) +
        shList(lh.generic, function (t) { return shRow('<a href="' + esc(t.url) + '" target="_blank" style="color:var(--text3)">' + esc(t.url) + '</a> — ' + esc(t.why)); }) +
        shList(lh.wasted, function (t) { return shRow(esc(t.path) + ' — dead, yet ' + t.inbound + ' pages link to it'); }) +
        shList(lh.orphans, function (u) { return shRow('<a href="' + esc(u) + '" target="_blank" style="color:var(--text3)">' + esc(u) + '</a> — no internal links in'); }));

      var co = d.consolidation || {};
      var cbox = document.getElementById('psc-sh-cons');
      var cs = document.getElementById('psc-sh-cons-score');
      if (cs) { cs.textContent = co.status === 'ok' ? (co.cannibalization_count + ' competing · ' + co.thin_tag_count + ' dead tags') : 'tap to expand'; }
      if (cbox) cbox.innerHTML = co.status !== 'ok' ? noCrawl :
        shActions(co.actions) +
        shList(co.cannibalization, function (q) {
          return '<div style="font-size:12.5px;margin:6px 0"><b>“' + esc(q.query) + '”</b> <span style="color:var(--text3)">(' + q.impr + ' impr)</span>' +
            q.pages.map(function (p) { return shRow('&nbsp;&nbsp;' + esc(p.page) + ' — pos ' + p.pos + ', ' + p.clicks + ' clicks'); }).join('') + '</div>';
        }) +
        shList(co.thin_tags, function (u) { return shRow(esc(u) + ' — zero clicks, candidate to noindex'); });
    });
  }

})();
