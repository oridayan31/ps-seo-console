<?php
if (!defined('ABSPATH')) exit;
/** @var array $settings */

$days = isset($_GET['days']) ? max(7, min(90, (int) $_GET['days'])) : 28;
$rep  = PSC_Conversion::report($days);
$f    = $rep['funnel'];
$gw   = $rep['gateways'];
$co   = $rep['checkout'];

$fmt = function ($n) { return number_format((int) $n); };
$pct = function ($v) { return $v === null ? '—' : $v . '%'; };
?>
<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Conversion funnel</span>
        <span style="font-weight:400;font-size:12px">
            <?php foreach ([7, 28, 90] as $d): ?>
                <a href="<?php echo esc_url(PSC_Admin::tab_url('conversion') . '&days=' . $d); ?>" style="color:<?php echo $d === $days ? 'var(--accent)' : 'var(--text3)'; ?>;text-decoration:none;margin-left:8px"><?php echo $d; ?>d</a>
            <?php endforeach; ?>
        </span>
    </div>

    <?php if (($f['status'] ?? '') !== 'ok'): ?>
        <div style="font-size:13px;color:var(--text3)"><?php echo esc_html($f['note'] ?? 'Funnel unavailable.'); ?></div>
    <?php else: ?>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
            <?php
            $steps = [
                ['Sessions', $f['sessions'], null],
                ['Add to cart', $f['add_to_carts'], $f['sessions'] > 0 ? round($f['add_to_carts'] / max(1, $f['sessions']) * 100, 1) : null],
                ['Checkout', $f['checkouts'], $f['atc_to_checkout']],
                ['Purchase', $f['purchases'], $f['checkout_to_purchase']],
            ];
            foreach ($steps as $i => $s):
            ?>
                <div style="flex:1;min-width:120px;background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:12px">
                    <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.03em"><?php echo esc_html($s[0]); ?></div>
                    <div style="font-size:22px;font-weight:700"><?php echo esc_html($fmt($s[1])); ?></div>
                    <?php if ($i > 0 && $s[2] !== null): ?>
                        <div style="font-size:11px;color:var(--text3)"><?php echo esc_html($s[2]); ?>% of previous</div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
            <?php
            $kpis = [
                ['Conversion rate', $pct($f['cr']), 'var(--green)'],
                ['Cart abandonment', $pct($f['cart_abandonment']), 'var(--amber)'],
                ['Checkout abandonment', $pct($f['checkout_abandonment']), 'var(--amber)'],
                ['Revenue (' . $days . 'd)', number_format((float) $f['revenue']), 'var(--text)'],
            ];
            foreach ($kpis as $k):
            ?>
                <div style="flex:1;min-width:120px">
                    <div style="font-size:11px;color:var(--text3)"><?php echo esc_html($k[0]); ?></div>
                    <div style="font-size:18px;font-weight:700;color:<?php echo esc_attr($k[2]); ?>"><?php echo esc_html($k[1]); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($f['cart_abandonment'] !== null && $f['cart_abandonment'] >= 75): ?>
            <div style="margin-top:10px;font-size:12px;color:var(--amber)">⚠ Cart abandonment is high — worth checking shipping-cost surprise, forced account creation, and gateway friction below.</div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="psc-card">
    <div class="psc-sectitle">Payment gateway health · last <?php echo (int) $days; ?> days</div>
    <?php if (($gw['status'] ?? '') === 'no_woo'): ?>
        <div style="font-size:13px;color:var(--text3)">WooCommerce not detected.</div>
    <?php elseif (empty($gw['items'])): ?>
        <div style="font-size:13px;color:var(--text3)">No orders in this window.</div>
    <?php else: ?>
        <table style="width:100%;border-collapse:collapse;font-size:13px">
            <thead><tr style="color:var(--text3);text-align:left;font-size:11px;text-transform:uppercase">
                <th style="padding:6px 8px">Gateway</th><th style="padding:6px 8px">Orders</th>
                <th style="padding:6px 8px">Failed</th><th style="padding:6px 8px">Revenue</th><th style="padding:6px 8px">Health</th>
            </tr></thead>
            <tbody>
            <?php foreach ($gw['items'] as $g):
                $hc = $g['health'] === 'ok' ? 'var(--green)' : ($g['health'] === 'idle' ? 'var(--text3)' : 'var(--red)');
                $hl = $g['health'] === 'ok' ? 'OK' : ($g['health'] === 'idle' ? 'Idle' : 'High failures');
            ?>
                <tr style="border-top:1px solid var(--border)">
                    <td style="padding:7px 8px"><b><?php echo esc_html($g['title']); ?></b><?php echo $g['enabled'] ? '' : ' <span style="font-size:11px;color:var(--text3)">(disabled)</span>'; ?></td>
                    <td style="padding:7px 8px"><?php echo esc_html($fmt($g['orders'])); ?></td>
                    <td style="padding:7px 8px"><?php echo esc_html($g['failed']); ?><?php echo $g['fail_rate'] > 0 ? ' <span style="color:var(--text3);font-size:11px">(' . esc_html($g['fail_rate']) . '%)</span>' : ''; ?></td>
                    <td style="padding:7px 8px"><?php echo esc_html(number_format((float) $g['revenue'])); ?></td>
                    <td style="padding:7px 8px"><span style="color:<?php echo esc_attr($hc); ?>;font-weight:600"><?php echo esc_html($hl); ?></span></td>
                </tr>
                <?php if (!empty($g['flag'])): ?>
                    <tr><td colspan="5" style="padding:0 8px 7px;font-size:12px;color:var(--text3)">↳ <?php echo esc_html($g['flag']); ?></td></tr>
                <?php endif; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="psc-card">
    <div class="psc-sectitle">Checkout configuration
        <?php if (($co['status'] ?? '') === 'ok'): ?>
            <span style="font-weight:400;font-size:12px;color:<?php echo $co['fails'] > 0 ? 'var(--red)' : ($co['warns'] > 0 ? 'var(--amber)' : 'var(--green)'); ?>">· <?php echo esc_html($co['verdict']); ?></span>
        <?php endif; ?>
    </div>
    <?php if (($co['status'] ?? '') === 'no_woo'): ?>
        <div style="font-size:13px;color:var(--text3)">WooCommerce not detected.</div>
    <?php else: ?>
        <?php foreach ($co['checks'] as $c):
            $col = $c['status'] === 'PASS' ? 'var(--green)' : ($c['status'] === 'WARN' ? 'var(--amber)' : 'var(--red)');
        ?>
            <div style="display:flex;gap:10px;padding:7px 0;border-top:1px solid var(--border);font-size:13px">
                <span style="font-size:11px;font-weight:700;color:#fff;background:<?php echo esc_attr($col); ?>;padding:1px 6px;border-radius:5px;height:fit-content"><?php echo esc_html($c['status']); ?></span>
                <div><?php echo esc_html($c['finding']); ?><?php echo $c['action'] ? '<div style="color:var(--text3);font-size:12px;margin-top:2px">→ ' . esc_html($c['action']) . '</div>' : ''; ?></div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    <div style="margin-top:12px"><button class="psc-btn ghost sm" type="button" onclick="pscRefreshConversion(this)">↻ Recompute now</button>
        <span style="font-size:11px;color:var(--text3);margin-left:8px">Updated <?php echo esc_html($rep['generated_at']); ?></span></div>
</div>
