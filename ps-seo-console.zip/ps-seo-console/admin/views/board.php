<?php
if (!defined('ABSPATH')) exit;
/** @var array $progress @var array $signals @var array $settings */

PSC_Admin::kpi_row();

$op = $progress['open_by_pri'];
?>
<div class="psc-progstrip psc-card">
    <div>
        <div class="psc-plab">Program progress <b><?php echo (int) $progress['done']; ?> / <?php echo (int) $progress['total']; ?> done · <?php echo (int) $progress['pct']; ?>%</b></div>
        <div class="psc-bar"><i style="width:<?php echo (int) $progress['pct']; ?>%"></i></div>
        <div class="psc-oc-row">
            <?php if ($op['P1']): ?><span class="psc-oc p1"><?php echo (int)$op['P1']; ?> P1 open</span><?php endif; ?>
            <?php if ($op['P2']): ?><span class="psc-oc p2"><?php echo (int)$op['P2']; ?> P2</span><?php endif; ?>
            <?php if ($op['P3']): ?><span class="psc-oc p3"><?php echo (int)$op['P3']; ?> P3</span><?php endif; ?>
            <?php if ($op['YOU']): ?><span class="psc-oc you"><?php echo (int)$op['YOU']; ?> your call</span><?php endif; ?>
        </div>
    </div>
    <?php
    $strike_n = null;
    if (class_exists('PSC_GSC') && PSC_Google::is_connected()) {
        $strike_n = count(PSC_GSC::striking_distance(200));
    }
    ?>
    <div class="psc-strike"><div class="n"><?php echo $strike_n === null ? '—' : (int) $strike_n; ?></div><div class="t">striking-distance<br><?php echo $strike_n === null ? 'connect Google' : 'pos 5–15'; ?></div></div>
</div>

<div class="psc-toolbar">
    <input type="search" id="psc-search" placeholder="Search cards…" oninput="pscFilter()">
    <select id="psc-fpri" onchange="pscFilter()"><option value="">All priority</option><option>P1</option><option>P2</option><option>P3</option><option>YOU</option></select>
    <select id="psc-fdom" onchange="pscFilter()"><option value="">Both sites</option><option value="art">.art</option><option value="coil">.co.il</option></select>
    <button class="psc-btn" type="button" onclick="pscToggleNew()">+ New card</button>
</div>

<div class="psc-newform" id="psc-newform">
    <div class="grid">
        <input type="text" id="nc-title" placeholder="Card title">
        <select id="nc-pri"><option>P1</option><option>P2</option><option selected>P3</option><option>YOU</option></select>
        <select id="nc-dom"><option value="art">.art</option><option value="coil">.co.il</option></select>
    </div>
    <input type="text" id="nc-url" placeholder="Target URL (optional)" style="margin-bottom:10px">
    <textarea id="nc-prompt" placeholder="Copy-paste prompt (what to ask Claude to do)…"></textarea>
    <button class="psc-btn" type="button" onclick="pscSubmitNew()">Add card</button>
    <button class="psc-btn ghost" type="button" onclick="pscToggleNew()">Cancel</button>
</div>

<?php
$cols = [
    'pending'  => ['Pending', 'pend'],
    'proposed' => ['Proposed', 'prop'],
    'done'     => ['Done', 'done'],
];
$all = PSC_DB::get_tasks();
$by = ['pending' => [], 'proposed' => [], 'done' => []];
foreach ($all as $t) { $by[$t['status']][] = $t; }

$render_card = function ($t) {
    $pri = strtolower($t['priority']);
    $priClass = in_array($pri, ['p1','p2','p3'], true) ? $pri : 'you';
    $dom = $t['domain'] === 'coil' ? 'coil' : 'art';
    $domLabel = $dom === 'coil' ? '.co.il' : '.art';
    $st = $t['status'];
    $statusLabel = $st === 'proposed' ? ($t['priority'] === 'YOU' ? 'Your call' : 'Proposed') : ucfirst($st);
    ?>
    <div class="psc-taskcard <?php echo $st==='done'?'done':''; ?>" data-pri="<?php echo esc_attr($t['priority']); ?>" data-dom="<?php echo esc_attr($dom); ?>">
        <div class="psc-rowtop">
            <span class="psc-pri <?php echo esc_attr($priClass); ?>"><?php echo esc_html($t['priority']); ?></span>
            <span class="psc-chip <?php echo esc_attr($dom); ?>"><?php echo esc_html($domLabel); ?></span>
            <span class="psc-status <?php echo esc_attr($st==='proposed'?'prop':($st==='done'?'done':'pend')); ?>"><?php echo esc_html($statusLabel); ?></span>
        </div>
        <h3><?php echo esc_html($t['title']); ?></h3>
        <div class="psc-meta">
            <?php if (!empty($t['target_url'])): ?><a href="<?php echo esc_url($t['target_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html(wp_parse_url($t['target_url'], PHP_URL_PATH) ?: $t['target_url']); ?></a><?php endif; ?>
            <span>◷ <?php echo esc_html(mysql2date('M j', $t['updated_at'])); ?></span>
            <?php if ($t['source'] !== 'manual'): ?><span><?php echo esc_html(strtoupper($t['source'])); ?></span><?php endif; ?>
        </div>
        <?php if ($st === 'done' && !empty($t['result'])): ?>
            <div class="psc-result">✓ <?php echo esc_html($t['result']); ?></div>
        <?php elseif (!empty($t['prompt'])): ?>
            <div class="psc-prompt"><?php echo esc_html($t['prompt']); ?></div>
        <?php endif; ?>
        <div class="psc-cardactions">
            <?php if (!empty($t['prompt']) && $st !== 'done'): ?><button class="psc-mini" type="button" onclick="pscCopy(this)">⧉ Copy prompt</button><?php endif; ?>
            <?php if ($st === 'pending'): ?>
                <button class="psc-mini" type="button" onclick="pscSetStatus(<?php echo (int)$t['id']; ?>,'proposed')">Propose ▸</button>
                <button class="psc-mini" type="button" onclick="pscSetStatus(<?php echo (int)$t['id']; ?>,'done')">✓ Done</button>
            <?php elseif ($st === 'proposed'): ?>
                <button class="psc-mini" type="button" onclick="pscSetStatus(<?php echo (int)$t['id']; ?>,'done')">✓ Approve &amp; done</button>
                <button class="psc-mini" type="button" onclick="pscSetStatus(<?php echo (int)$t['id']; ?>,'pending')">◂ Back</button>
            <?php else: ?>
                <button class="psc-mini" type="button" onclick="pscSetStatus(<?php echo (int)$t['id']; ?>,'pending')">↺ Reopen</button>
            <?php endif; ?>
            <button class="psc-mini danger" type="button" onclick="pscDelete(<?php echo (int)$t['id']; ?>)">Delete</button>
        </div>
    </div>
    <?php
};
?>
<div class="psc-board">
    <?php foreach ($cols as $status => $meta): ?>
        <div class="col" data-col="<?php echo esc_attr($meta[1]); ?>">
            <div class="psc-colhead"><span class="psc-dot <?php echo esc_attr($meta[1]); ?>"></span> <?php echo esc_html($meta[0]); ?> <span class="cnt"><?php echo count($by[$status]); ?></span></div>
            <?php if (empty($by[$status])): ?>
                <div class="psc-empty">Nothing here.</div>
            <?php else: foreach ($by[$status] as $t) { $render_card($t); } endif; ?>
        </div>
    <?php endforeach; ?>
</div>
