<?php
if (!defined('ABSPATH')) exit;
/** @var array $signals @var array $settings */

$summary = $signals['summary'] ?? ['opportunities' => 0, 'high' => 0];
$groups  = $signals['groups'] ?? [];
$genAt   = $signals['generated_at'] ?? current_time('mysql');
?>
<div class="psc-card psc-pa">
    <div class="psc-sectitle">Page audit — SEO + AEO</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Fetches a URL and runs the full P0–P3 checklist (crawl, index, canonical, robots, AI-bot access, on-page, schema, links, AEO). One P0 failure is the headline regardless of score.</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="text" id="psc-pa-url" value="<?php echo esc_attr(home_url('/')); ?>" style="flex:1;min-width:220px;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
        <button class="psc-btn" type="button" onclick="pscRunPageAudit(this)">Run audit</button>
    </div>
    <div id="psc-pa-result" style="margin-top:14px"></div>
</div>

<div class="psc-card psc-cq">
    <div class="psc-sectitle">Content quality — helpful-content check</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Grades a page's actual text against Google's Helpful Content &amp; spam signals (AI tells, thin/generic copy, keyword stuffing, weak E-E-A-T, templated writing) using your Anthropic key. No tool can read Google's internal flags — this catches the patterns that get sites demoted, before they do.</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="text" id="psc-cq-url" value="<?php echo esc_attr(home_url('/')); ?>" style="flex:1;min-width:220px;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
        <button class="psc-btn" type="button" onclick="pscRunCQ(this)">Grade content</button>
    </div>
    <div id="psc-cq-result" style="margin-top:14px"></div>
</div>

<?php
$gmc_conn = class_exists('PSC_GMC') && PSC_GMC::get_id() && class_exists('PSC_Google') && PSC_Google::is_connected();
$gmc = $gmc_conn ? PSC_GMC::get_status() : null;
$gmc_ok = $gmc && empty($gmc['error']);
$serving = $gmc_ok ? ((int) ($gmc['active'] ?? 0) + (int) ($gmc['limited'] ?? 0)) : null;
?>
<div class="psc-feed psc-card">
    <div class="psc-ftop"><span class="psc-glogo"></span><span class="psc-ftitle">Merchant Center feed health</span><span class="psc-fwhere">printstudio.art</span></div>
    <?php if ($gmc_ok): ?>
    <div class="psc-fstats">
        <div class="psc-fstat"><div class="n" style="color:var(--green)"><?php echo (int) $serving; ?></div><div class="t">Serving</div></div>
        <div class="psc-fstat"><div class="n" style="color:<?php echo ((int) ($gmc['disapproved'] ?? 0)) > 0 ? 'var(--red)' : 'var(--text3)'; ?>"><?php echo (int) ($gmc['disapproved'] ?? 0); ?></div><div class="t">Disapproved</div></div>
        <div class="psc-fstat"><div class="n" style="color:<?php echo ((int) ($gmc['expiring'] ?? 0)) > 0 ? 'var(--amber)' : 'var(--text3)'; ?>"><?php echo (int) ($gmc['expiring'] ?? 0); ?></div><div class="t">Expiring</div></div>
    </div>
    <div style="color:var(--text3);font-size:12.5px">
        <?php echo (int) ($gmc['total'] ?? 0); ?> products<?php if ((int) ($gmc['limited'] ?? 0) > 0): ?> · <b><?php echo (int) $gmc['limited']; ?></b> approved in limited countries only (not all target markets)<?php endif; ?><?php if (!empty($gmc['reasons'])): $tk = array_key_first($gmc['reasons']); ?> · top issue: <?php echo esc_html($tk); ?> (<?php echo (int) $gmc['reasons'][$tk]; ?>)<?php endif; ?><?php if (!empty($gmc['synced_at'])): ?> · synced <?php echo esc_html(human_time_diff(strtotime($gmc['synced_at']), current_time('timestamp'))); ?> ago<?php endif; ?>
    </div>
    <?php elseif ($gmc && !empty($gmc['error'])): ?>
    <div class="psc-fstats">
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Active</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Disapproved</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Expiring</div></div>
    </div>
    <div style="color:var(--red);font-size:12.5px">Merchant Center error: <?php echo esc_html($gmc['error']); ?></div>
    <?php else: ?>
    <div class="psc-fstats">
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Active</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Disapproved</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Expiring</div></div>
    </div>
    <div style="color:var(--text3);font-size:12.5px">🔒 Connect Merchant Center in Settings to see live feed health here.</div>
    <?php endif; ?>
</div>

<div class="psc-scan psc-card">
    <span><b><?php echo (int) $summary['opportunities']; ?></b> opportunities · <b><?php echo (int) $summary['high']; ?></b> high-impact</span>
    <span>· last scan <b><?php echo esc_html(human_time_diff(strtotime($genAt), current_time('timestamp'))); ?> ago</b></span>
    <button class="psc-btn ghost sm" type="button" onclick="pscRescan(this)">↻ Re-scan</button>
</div>

<?php foreach ($groups as $g):
    $sev = in_array($g['severity'], ['hi','med','lo'], true) ? $g['severity'] : 'lo';
    $src = $g['source'];
    $srcClass = in_array($src, ['gmc','gsc','site'], true) ? $src : 'site';
    $srcLabel = $src === 'site' ? 'live now · site' : strtoupper($src);
    $urls = [];
    foreach ($g['items'] as $it) { if (!empty($it['url'])) $urls[] = $it['url']; }
    $urlAttr = implode(', ', array_slice($urls, 0, 8));
?>
<div class="psc-grp psc-card">
    <div class="psc-gh">
        <span class="psc-sev <?php echo esc_attr($sev); ?>"></span>
        <span class="psc-gname"><?php echo esc_html($g['name']); ?></span>
        <span class="psc-cntpill <?php echo esc_attr($sev); ?>"><?php echo (int) $g['count']; ?></span>
        <span class="psc-srctag <?php echo esc_attr($srcClass); ?>"><?php echo esc_html($srcLabel); ?></span>
        <?php if (!empty($g['live']) && $g['count'] > 0): ?>
        <button class="psc-btn <?php echo $sev==='hi'?'':'ghost'; ?> sm" type="button"
            data-name="<?php echo esc_attr($g['name']); ?>"
            data-source="<?php echo esc_attr($src); ?>"
            data-sev="<?php echo esc_attr($sev); ?>"
            data-urls="<?php echo esc_attr($urlAttr); ?>"
            onclick="pscCreateFixCard(this)">Create fix card →</button>
        <?php endif; ?>
    </div>
    <div class="psc-gdesc"><?php echo esc_html($g['desc']); ?></div>
    <?php if (!empty($g['items'])): ?>
    <div class="psc-rows">
        <?php foreach ($g['items'] as $it): ?>
        <div class="psc-r">
            <span class="u"><?php if (!empty($it['url'])): ?><a href="<?php echo esc_url($it['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($it['label']); ?></a><?php else: ?><?php echo esc_html($it['label']); ?><?php endif; ?></span>
            <span class="m"><?php echo esc_html($it['meta']); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ((int)$g['total'] > count($g['items'])): ?>
        <div class="psc-more"><?php echo (int)$g['total'] - count($g['items']); ?> more</div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php endforeach; ?>
