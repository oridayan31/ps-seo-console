<?php
if (!defined('ABSPATH')) exit;
/** @var array $signals @var array $settings */

$summary = $signals['summary'] ?? ['opportunities' => 0, 'high' => 0];
$groups  = $signals['groups'] ?? [];
$genAt   = $signals['generated_at'] ?? current_time('mysql');
?>
<div class="psc-card psc-pa">
    <div class="psc-sectitle">Page audit — SEO + AEO</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Fetches a URL and runs the full P0–P3 checklist (crawl, index, canonical, robots, AI-bot access, on-page, schema, links, AEO). One P0 failure is the headline regardless of score.</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="text" id="psc-pa-url" value="<?php echo esc_attr(home_url('/')); ?>" style="flex:1;min-width:220px;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
        <button class="psc-btn" type="button" onclick="pscRunPageAudit(this)">Run audit</button>
    </div>
    <div id="psc-pa-result" style="margin-top:14px"></div>
</div>

<div class="psc-feed psc-card">
    <div class="psc-ftop"><span class="psc-glogo"></span><span class="psc-ftitle">Merchant Center feed health</span><span class="psc-fwhere">printstudio.art</span></div>
    <div class="psc-fstats">
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Active</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Disapproved</div></div>
        <div class="psc-fstat"><div class="n muted" style="color:var(--text3)">—</div><div class="t">Expiring</div></div>
    </div>
    <div style="color:var(--text3);font-size:12.5px">🔒 Connect Merchant Center in Settings (Phase 2) to see live feed health here.</div>
</div>

<div class="psc-scan psc-card">
    <span><b><?php echo (int) $summary['opportunities']; ?></b> opportunities · <b><?php echo (int) $summary['high']; ?></b> high-impact</span>
    <span>· last scan <b><?php echo esc_html(human_time_diff(strtotime($genAt), current_time('timestamp'))); ?> ago</b></span>
    <button class="psc-btn ghost sm" type="button" onclick="pscRescan(this)">↻ Re-scan</button>
</div>

<?php foreach ($groups as $g):
    $sev = in_array($g['severity'], ['hi','med','lo'], true) ? $g['severity'] : 'lo';
    $src = $g['source'];
    $srcClass = in_array($src, ['gmc','gsc','site'], true) ? $src : 'site';
    $srcLabel = $src === 'site' ? 'live now · site' : strtoupper($src);
    $urls = [];
    foreach ($g['items'] as $it) { if (!empty($it['url'])) $urls[] = $it['url']; }
    $urlAttr = implode(', ', array_slice($urls, 0, 8));
?>
<div class="psc-grp psc-card">
    <div class="psc-gh">
        <span class="psc-sev <?php echo esc_attr($sev); ?>"></span>
        <span class="psc-gname"><?php echo esc_html($g['name']); ?></span>
        <span class="psc-cntpill <?php echo esc_attr($sev); ?>"><?php echo (int) $g['count']; ?></span>
        <span class="psc-srctag <?php echo esc_attr($srcClass); ?>"><?php echo esc_html($srcLabel); ?></span>
        <?php if (!empty($g['live']) && $g['count'] > 0): ?>
        <button class="psc-btn <?php echo $sev==='hi'?'':'ghost'; ?> sm" type="button"
            data-name="<?php echo esc_attr($g['name']); ?>"
            data-source="<?php echo esc_attr($src); ?>"
            data-sev="<?php echo esc_attr($sev); ?>"
            data-urls="<?php echo esc_attr($urlAttr); ?>"
            onclick="pscCreateFixCard(this)">Create fix card →</button>
        <?php endif; ?>
    </div>
    <div class="psc-gdesc"><?php echo esc_html($g['desc']); ?></div>
    <?php if (!empty($g['items'])): ?>
    <div class="psc-rows">
        <?php foreach ($g['items'] as $it): ?>
        <div class="psc-r">
            <span class="u"><?php if (!empty($it['url'])): ?><a href="<?php echo esc_url($it['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($it['label']); ?></a><?php else: ?><?php echo esc_html($it['label']); ?><?php endif; ?></span>
            <span class="m"><?php echo esc_html($it['meta']); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ((int)$g['total'] > count($g['items'])): ?>
        <div class="psc-more"><?php echo (int)$g['total'] - count($g['items']); ?> more</div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php endforeach; ?>
