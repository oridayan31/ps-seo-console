<?php
if (!defined('ABSPATH')) exit;
$has_key = class_exists('PSC_Connectors') && PSC_Connectors::has_anthropic();
?>

<div class="psc-card">
    <div class="psc-sectitle">🧠 Ask the Brain</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:12px">
        It knows this site — the brand facts, the corrected findings (GA4 property, Merchant country coverage, blog content risk), and how we work — and reads your live data (Search Console, GA4, Merchant, audit, conversion, board) every time you ask. Answers are grounded in the current numbers.
    </div>

    <?php if (!$has_key): ?>
    <div class="psc-card" style="border-left:3px solid var(--amber);font-size:13px">
        Add your Anthropic API key in <a href="<?php echo esc_url(PSC_Admin::tab_url('settings')); ?>">Settings → Connectors</a> to switch the brain on.
    </div>
    <?php else: ?>

    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start">
        <textarea id="psc-brain-q" rows="2" placeholder="e.g. What should I fix first this week — and why?" style="flex:1;min-width:240px;border:1px solid var(--border2);border-radius:8px;padding:9px 11px;background:var(--bg2);color:var(--text);font-size:13px;resize:vertical"></textarea>
        <button class="psc-btn" type="button" onclick="pscBrainAsk(this, document.getElementById('psc-brain-q').value)">Ask</button>
    </div>

    <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">
        <?php
        $chips = [
            'What should I fix first this week — and why?',
            'Is my content safe from Google\'s helpful-content system?',
            'Why is my conversion rate low and where\'s the biggest leak?',
            'What\'s my single biggest revenue opportunity right now?',
            'Explain my Merchant Center country-coverage situation.',
        ];
        foreach ($chips as $c): ?>
            <button type="button" class="psc-chip" onclick="pscBrainAsk(this, <?php echo esc_attr(wp_json_encode($c)); ?>)" style="font-size:12px;border:1px solid var(--border2);background:var(--bg2);color:var(--text2);border-radius:14px;padding:5px 11px;cursor:pointer"><?php echo esc_html($c); ?></button>
        <?php endforeach; ?>
    </div>

    <div id="psc-brain-answer" style="margin-top:16px"></div>
    <?php endif; ?>
</div>

<details class="psc-card" style="margin-top:6px">
    <summary style="cursor:pointer;font-weight:600;font-size:13px">What the Brain knows (knowledge base)</summary>
    <div style="font-size:12px;color:var(--text3);margin:8px 0">This is the durable handoff — edit it to teach the brain new facts or correct it. Live metrics are added automatically at ask time; keep this for lasting knowledge.</div>
    <textarea id="psc-brain-kb" rows="18" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:10px;background:var(--bg2);color:var(--text);font-size:12px;font-family:var(--mono);line-height:1.5"><?php echo esc_textarea(PSC_Brain::knowledge()); ?></textarea>
    <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
        <button class="psc-btn ghost sm" type="button" onclick="pscBrainSaveKB(this)">Save knowledge</button>
        <span style="font-size:12px;color:var(--text3)"><?php echo PSC_Brain::is_custom() ? 'Customized' : 'Using built-in default'; ?></span>
    </div>
</details>
