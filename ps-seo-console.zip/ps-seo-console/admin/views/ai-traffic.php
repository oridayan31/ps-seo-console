<?php
if (!defined('ABSPATH')) exit;

$g_conn = class_exists('PSC_Google') && PSC_Google::is_connected();
$force = isset($_GET['refresh']);
$range = isset($_GET['range']) ? (int) $_GET['range'] : 28;
if (!in_array($range, [7, 28, 90, 180, 365], true)) $range = 28;
$r = $g_conn ? PSC_AITraffic::report($force, $range) : ['status' => 'error', 'message' => 'Connect Google (Settings) to pull GA4 data.'];
$ranges = [7 => '7d', 28 => '28d', 90 => '90d', 180 => '6mo', 365 => '12mo'];
?>

<?php if (($r['status'] ?? '') !== 'ok'): ?>
<div class="psc-card"><div class="psc-sectitle">AI Traffic</div>
    <div style="font-size:13px;color:var(--amber)">⚠ <?php echo esc_html($r['message'] ?? 'Could not load'); ?></div>
</div>
<?php else: $t = $r['totals']; ?>

<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>AI engine traffic</span>
        <span style="font-weight:400;font-size:12px;display:flex;gap:8px;align-items:center">
            <?php foreach ($ranges as $d => $lbl): ?>
                <a href="<?php echo esc_url(add_query_arg(['range' => $d, 'refresh' => null])); ?>" style="text-decoration:none;<?php echo $d === $range ? 'color:#fff;background:var(--accent);border-radius:6px;padding:2px 8px;font-weight:700' : 'color:var(--text3)'; ?>"><?php echo esc_html($lbl); ?></a>
            <?php endforeach; ?>
            <a href="<?php echo esc_url(add_query_arg(['refresh' => '1', 'range' => $range])); ?>" style="color:var(--accent);text-decoration:none">↻</a>
        </span>
    </div>
    <div style="display:flex;gap:24px;flex-wrap:wrap;margin-top:4px">
        <div><div style="font-size:24px;font-weight:700"><?php echo (int) $t['sessions']; ?><?php if ($t['delta_pct'] !== null): $up = $t['delta_pct'] >= 0; ?> <span style="font-size:13px;color:<?php echo $up ? 'var(--green)' : 'var(--red)'; ?>"><?php echo ($up ? '+' : '') . (int) $t['delta_pct']; ?>%</span><?php endif; ?></div><div style="font-size:12px;color:var(--text3)">sessions</div></div>
        <div><div style="font-size:24px;font-weight:700"><?php echo (int) $t['users']; ?></div><div style="font-size:12px;color:var(--text3)">users</div></div>
        <div><div style="font-size:24px;font-weight:700"><?php echo (int) $t['views']; ?></div><div style="font-size:12px;color:var(--text3)">page views</div></div>
        <div><div style="font-size:24px;font-weight:700"><?php echo (int) $t['purchases']; ?></div><div style="font-size:12px;color:var(--text3)">purchases</div></div>
        <div><div style="font-size:24px;font-weight:700">$<?php echo number_format((float) $t['revenue'], 0); ?></div><div style="font-size:12px;color:var(--text3)">revenue</div></div>
    </div>

    <?php $daily = $r['daily'] ?? []; if (count($daily) >= 2): $max = 1;
        foreach ($daily as $d) $max = max($max, array_sum($d)); ?>
    <div style="display:flex;align-items:flex-end;gap:2px;height:44px;margin-top:14px">
        <?php foreach ($daily as $date => $d): $v = array_sum($d); ?>
            <div title="<?php echo esc_attr($date . ': ' . $v . ' sessions'); ?>" style="flex:1;min-width:2px;height:<?php echo max(4, (int) round($v / $max * 100)); ?>%;background:var(--accent);opacity:.85;border-radius:2px 2px 0 0"></div>
        <?php endforeach; ?>
    </div>
    <div style="font-size:11px;color:var(--text3);margin-top:2px">daily AI sessions (builds automatically each day)</div>
    <?php elseif ($g_conn): ?>
    <div style="font-size:12px;color:var(--text3);margin-top:10px">Daily trend starts building tonight — the cron snapshots AI sessions every day.</div>
    <?php endif; ?>
</div>

<div class="psc-card">
    <div class="psc-sectitle">By engine</div>
    <?php if (empty($r['engines'])): ?><div style="font-size:13px;color:var(--text3)">No AI-engine sessions in the period yet.</div>
    <?php else: ?>
    <table style="width:100%;border-collapse:collapse;font-size:13px">
        <tr style="color:var(--text3);font-size:11px;text-transform:uppercase;letter-spacing:.4px"><td style="padding:4px 8px">Engine</td><td style="padding:4px 8px;text-align:right">Sessions</td><td style="padding:4px 8px;text-align:right">Δ vs prev</td><td style="padding:4px 8px;text-align:right">Users</td><td style="padding:4px 8px;text-align:right">Views</td><td style="padding:4px 8px;text-align:right">Purch.</td><td style="padding:4px 8px;text-align:right">Revenue</td></tr>
        <?php foreach ($r['engines'] as $e): ?>
        <tr style="border-top:1px solid var(--border)">
            <td style="padding:6px 8px;font-weight:600"><?php echo esc_html($e['engine']); ?><div style="font-size:10.5px;color:var(--text3);font-weight:400"><?php echo esc_html(implode(', ', array_slice($e['sources'], 0, 3))); ?></div></td>
            <td style="padding:6px 8px;text-align:right;font-weight:700"><?php echo (int) $e['sessions']; ?></td>
            <td style="padding:6px 8px;text-align:right;color:<?php echo $e['delta'] > 0 ? 'var(--green)' : ($e['delta'] < 0 ? 'var(--red)' : 'var(--text3)'); ?>"><?php echo ($e['delta'] > 0 ? '+' : '') . (int) $e['delta']; ?></td>
            <td style="padding:6px 8px;text-align:right"><?php echo (int) $e['users']; ?></td>
            <td style="padding:6px 8px;text-align:right"><?php echo (int) $e['views']; ?></td>
            <td style="padding:6px 8px;text-align:right"><?php echo (int) $e['purchases']; ?></td>
            <td style="padding:6px 8px;text-align:right">$<?php echo number_format((float) $e['revenue'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>
</div>

<div class="psc-card">
    <div class="psc-sectitle">Pages AI engines cite <span style="font-weight:400;font-size:12px;color:var(--text3)">· where AI visitors land</span></div>
    <?php if (empty($r['pages'])): ?><div style="font-size:13px;color:var(--text3)">No page-level AI visits recorded yet — they'll appear here as volume grows.</div>
    <?php else: ?>
        <?php foreach ($r['pages'] as $p): ?>
        <div style="border-top:1px solid var(--border);padding:8px 0">
            <div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline">
                <a href="<?php echo esc_url(home_url($p['path'])); ?>" target="_blank" style="font-size:12.5px;font-weight:600;color:var(--text2);word-break:break-all"><?php echo esc_html($p['path']); ?></a>
                <span style="font-size:11px;color:var(--text3);white-space:nowrap"><?php echo (int) $p['views']; ?> views · <?php echo (int) $p['sessions']; ?> sessions</span>
            </div>
            <div style="font-size:11px;color:var(--text3);margin-top:2px">
                <?php if ($p['template']): ?><span style="background:var(--bg2);border-radius:4px;padding:0 5px"><?php echo esc_html($p['template']); ?></span><?php endif; ?>
                <?php foreach ($p['engines'] as $eng): ?><span style="background:color-mix(in srgb,var(--accent) 12%,transparent);color:var(--accent);border-radius:4px;padding:0 6px;margin-left:3px"><?php echo esc_html($eng); ?></span><?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="psc-card" style="border-left:3px solid var(--accent)">
    <div class="psc-sectitle">Analysis</div>
    <?php foreach ($r['insights'] as $i): ?>
        <div style="font-size:13px;margin:5px 0">→ <?php echo esc_html($i); ?></div>
    <?php endforeach; ?>
    <div style="font-size:12px;color:var(--text3);margin-top:8px">Method: GA4 Data API, sessionSource contains any AI engine (chatgpt, perplexity, gemini, copilot, claude, deepseek, grok, meta.ai, …) — the same filter as the manual GA4 report, pulled automatically and snapshotted daily.</div>
</div>
<?php endif; ?>
