<?php
if (!defined('ABSPATH')) exit;
/** @var array $settings */

$oauth_conn = class_exists('PSC_OAuth') && PSC_OAuth::is_connected();
$g_conn = class_exists('PSC_Google') && PSC_Google::is_connected();
$meta   = $g_conn ? PSC_Google::meta() : [];
$omerge = class_exists('PSC_OAuth') ? PSC_OAuth::meta() : [];
$bridge = class_exists('PS_Claude_Bridge');
$rules  = PSC_Watchers::rules();
$sa_placeholder = 'ps-console@your-project.iam.gserviceaccount.com';
$oauth_msg = isset($_GET['psc_oauth']) ? sanitize_key((string) $_GET['psc_oauth']) : '';
?>

<?php if ($oauth_msg): ?>
<div class="psc-card" style="border-left:3px solid <?php echo $oauth_msg === 'connected' ? 'var(--green)' : 'var(--red)'; ?>;font-size:13px">
    <?php
    $msgs = ['connected' => '✓ Signed in with Google.', 'disconnected' => 'Disconnected.', 'denied' => 'Sign-in was cancelled.',
             'badstate' => 'Security check failed — please try again.', 'nocode' => 'No code returned — try again.',
             'error' => 'Sign-in error: ' . esc_html($omerge['last_error'] ?? 'unknown')];
    echo isset($msgs[$oauth_msg]) ? $msgs[$oauth_msg] : esc_html($oauth_msg);
    ?>
</div>
<?php endif; ?>

<?php if (!$g_conn): ?>
<!-- PRIMARY: Sign in with Google (OAuth) -->
<div class="psc-card">
    <div class="psc-sectitle">Connect Google <span class="psc-pill off" style="margin-left:6px">Not connected</span></div>
    <div class="psc-grant" style="margin-bottom:14px">
        Sign in with the Google account that already owns your Search Console, GA4, and Merchant Center — nothing to add anywhere. One-time setup:
        <ul>
            <li>Create an OAuth client (Web application) in <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">Google Cloud → Credentials</a>, and enable the Search Console, Analytics Data + Admin, and Content APIs.</li>
            <li>On the OAuth consent screen, set publishing status to <b>In production</b> (so sign-in doesn't expire), and add the scopes for those APIs.</li>
            <li>Add this exact <b>redirect URI</b> to the client, paste the client ID + secret below, then click Connect.</li>
        </ul>
    </div>
    <form method="post" action="">
        <?php wp_nonce_field('psc_oauth', 'psc_oauth_nonce'); ?>
        <div class="psc-setrow">
            <div class="k">Redirect URI<small>copy this into your OAuth client's "Authorized redirect URIs"</small></div>
            <div><code style="font-family:var(--mono);font-size:12px;word-break:break-all"><?php echo esc_html(PSC_OAuth::redirect_uri()); ?></code></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Client ID</div>
            <div><input type="text" name="oauth_client_id" value="<?php echo esc_attr(PSC_OAuth::client_id()); ?>" placeholder="xxxx.apps.googleusercontent.com" style="width:100%;max-width:460px;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)"></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Client secret</div>
            <div><input type="password" name="oauth_client_secret" placeholder="<?php echo PSC_OAuth::client_secret() !== '' ? '•••• (set — leave blank to keep)' : 'GOCSPX-…'; ?>" style="max-width:360px;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)"></div>
        </div>
        <div class="psc-setrow"><div class="k">&nbsp;</div><div>
            <button class="psc-btn" type="submit">Save credentials</button>
            <?php if (PSC_OAuth::has_client()): ?>
                <a class="psc-btn" href="<?php echo esc_url(PSC_OAuth::auth_url()); ?>" style="margin-left:8px;text-decoration:none;background:#fff;color:#3c4043;border:1px solid var(--border2)">Connect with Google</a>
            <?php endif; ?>
        </div></div>
    </form>
</div>

<!-- ADVANCED: service account -->
<details style="margin:0 0 6px">
    <summary style="cursor:pointer;font-size:12px;color:var(--text3);padding:4px 2px">Advanced: connect with a service account instead</summary>
    <div class="psc-card">
        <div style="font-size:13px;color:var(--text2);margin-bottom:10px">A robot account — sturdier for automation, but you add its email as a user on each product. Paste its JSON key.</div>
        <form method="post" action="">
            <?php wp_nonce_field('psc_connect', 'psc_connect_nonce'); ?>
            <textarea name="sa_json" rows="5" style="width:100%;max-width:640px;font-family:var(--mono);font-size:12px;border:1px solid var(--border2);border-radius:var(--r);padding:10px;background:var(--bg2);color:var(--text)" placeholder='{ "type": "service_account", "client_email": "...", "private_key": "-----BEGIN PRIVATE KEY-----\n..." }'></textarea>
            <div style="margin-top:10px"><button class="psc-btn ghost sm" type="submit">Connect service account</button></div>
        </form>
    </div>
</details>
<?php else: ?>
<!-- CONNECTED -->
<div class="psc-card">
    <div class="psc-sectitle">Google connection <span class="psc-pill on" style="margin-left:6px">Connected</span></div>
    <?php if ($oauth_conn): ?>
    <div class="psc-setrow">
        <div class="k">Signed in with Google<small>your account · Search Console, GA4, Merchant</small></div>
        <div>
            <span class="sa"><?php echo esc_html($omerge['email'] ?: 'connected'); ?></span>
            <div style="font-size:12px;color:var(--text3);margin-top:6px">
                <?php if (!empty($omerge['connected_at'])): ?>Connected <?php echo esc_html(mysql2date('M j, Y', $omerge['connected_at'])); ?><?php endif; ?>
                <?php if (!empty($omerge['last_error'])): ?> · <span style="color:var(--red)">last error: <?php echo esc_html($omerge['last_error']); ?></span><?php endif; ?>
            </div>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:10px">
                <input type="hidden" name="action" value="psc_oauth_disconnect">
                <?php wp_nonce_field('psc_oauth_disconnect'); ?>
                <button class="psc-btn ghost sm" type="submit">Disconnect</button>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="psc-setrow">
        <div class="k">Service account<small>One key, three surfaces</small></div>
        <div>
            <span class="sa"><?php echo esc_html($meta['token_email'] ?? $sa_placeholder); ?></span>
            <div style="font-size:12px;color:var(--text3);margin-top:6px">
                <?php if (!empty($meta['authorized_at'])): ?>Authorized <?php echo esc_html(mysql2date('M j, Y', $meta['authorized_at'])); ?><?php endif; ?>
                <?php if (!empty($meta['last_error'])): ?> · <span style="color:var(--red)">last error: <?php echo esc_html($meta['last_error']); ?></span><?php endif; ?>
            </div>
            <form method="post" action="" style="margin-top:10px">
                <?php wp_nonce_field('psc_disconnect', 'psc_disconnect_nonce'); ?>
                <button class="psc-btn ghost sm" type="submit">Disconnect</button>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php $cs = PSC_Connectors::status(); ?>
<form method="post" action="">
    <?php wp_nonce_field('psc_autoupdate', 'psc_autoupdate_nonce'); ?>
    <div class="psc-card" style="border-left:3px solid <?php echo PSC_Updater::has_source() ? 'var(--green)' : 'var(--text3)'; ?>">
        <div class="psc-sectitle">Automatic updates <span style="font-weight:400;font-size:12px;color:var(--text3)">· hands-off</span></div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Point this at a manifest URL (e.g. a GitHub repo). The Console checks it daily and, if a newer verified version exists, installs it itself — no upload, no password. Manifest is JSON: <code style="font-family:var(--mono);font-size:12px">{"slug","version","zip_url","sha256"}</code>.</div>
        <div class="psc-setrow">
            <div class="k">Manifest URL</div>
            <div><input type="text" name="update_source" value="<?php echo esc_attr(PSC_Updater::source_url()); ?>" placeholder="https://raw.githubusercontent.com/you/repo/main/manifest.json" style="width:100%;max-width:420px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)"></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Source token<small>only for a private repo · sent as Bearer</small></div>
            <div><input type="password" name="update_source_token" placeholder="<?php echo PSC_Updater::source_token() !== '' ? '•••• (set — leave blank to keep)' : 'optional'; ?>" style="max-width:340px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)"></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Auto-install<small>off = notify only; on = install on the daily check</small></div>
            <div><label style="font-size:13px"><input type="checkbox" name="update_auto" value="1" <?php checked(PSC_Updater::auto_on()); ?>> Install updates automatically</label></div>
        </div>
        <div class="psc-setrow">
            <div class="k">&nbsp;</div>
            <div><button class="psc-btn" type="submit">Save</button>
                <button class="psc-btn ghost sm" type="button" onclick="pscCheckUpdate(this,false)" style="margin-left:8px">Check now</button>
                <button class="psc-btn ghost sm" type="button" onclick="pscCheckUpdate(this,true)" style="margin-left:6px">Update now</button>
            </div>
        </div>
        <div id="psc-update-result" style="font-size:12px;color:var(--text3);margin-top:4px"></div>
    </div>
</form>

<form method="post" action="">
    <?php wp_nonce_field('psc_alerts', 'psc_alerts_nonce'); ?>
    <div class="psc-card">
        <div class="psc-sectitle">Email alerts</div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Emails you when a <b>critical, actionable</b> problem appears — a live page gone noindex, a site-wide crawl block, a failing payment gateway, or a sharp search-traffic drop. Each issue is sent once (with a short note when it clears), so it won't spam you.</div>
        <div class="psc-setrow">
            <div class="k">Alerts</div>
            <div><label style="font-size:13px"><input type="checkbox" name="alerts_enabled" value="1" <?php checked(PSC_Alerts::is_enabled()); ?>> Enabled</label></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Send to</div>
            <div><input type="email" name="alerts_to" value="<?php echo esc_attr(get_option('psc_alerts_to', '')); ?>" placeholder="<?php echo esc_attr(get_option('admin_email')); ?> (default)" style="max-width:320px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px"></div>
        </div>
        <div class="psc-setrow">
            <div class="k">What to send<small>Critical = index blocks, gateway failures, traffic cliff</small></div>
            <div>
                <select name="alerts_tier" style="border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px">
                    <option value="critical" <?php selected(PSC_Alerts::tier(), 'critical'); ?>>Critical only</option>
                    <option value="all" <?php selected(PSC_Alerts::tier(), 'all'); ?>>Critical + warnings (idle gateway, disapprovals)</option>
                </select>
            </div>
        </div>
        <div class="psc-setrow">
            <div class="k">&nbsp;</div>
            <div><button class="psc-btn" type="submit">Save alerts</button>
                <button class="psc-btn ghost sm" type="button" onclick="pscTestAlert(this)" style="margin-left:8px">Send test email</button></div>
        </div>
    </div>
</form>

<form method="post" action="">
    <?php wp_nonce_field('psc_update', 'psc_update_nonce'); ?>
    <div class="psc-card" style="border-left:3px solid <?php echo PSC_Updater::has_token() ? 'var(--green)' : 'var(--amber)'; ?>">
        <div class="psc-sectitle">Remote updates</div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Lets a new plugin version be installed via API instead of a manual upload. Gated by this token <em>and</em> WordPress auth — one secret alone can't trigger it. Only the Console and the bridge can be updated this way.</div>
        <div style="font-size:12px;color:var(--amber);margin-bottom:10px">⚠ Before enabling: rotate your WordPress application password (it was flagged as leaked). A remote code-install endpoint is only as safe as the credentials in front of it.</div>
        <div class="psc-setrow">
            <div class="k">Update token<small>16+ chars · stored hashed · or define PSC_UPDATE_TOKEN in wp-config</small></div>
            <div>
                <?php if (PSC_Updater::has_token()): ?><span class="psc-pill on">✓ Configured</span><?php else: ?><span class="psc-pill off">Not set</span><?php endif; ?>
                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
                    <input type="password" name="psc_update_token" placeholder="set / rotate token" style="max-width:340px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
                    <button class="psc-btn" type="submit">Save token</button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php $cs2 = null; // (connectors status already loaded above) ?>
<form method="post" action="">
    <?php wp_nonce_field('psc_connectors', 'psc_connectors_nonce'); ?>
    <div class="psc-card">
        <div class="psc-sectitle">Data connectors</div>

        <div class="psc-setrow">
            <div class="k">DataForSEO<small>Keyword volume, difficulty, SERP competitors</small></div>
            <div>
                <?php if ($cs['dataforseo']['configured']): ?><span class="psc-pill on">✓ <?php echo esc_html($cs['dataforseo']['masked']); ?></span><?php else: ?><span class="psc-pill off">Not set</span><?php endif; ?>
                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
                    <input type="text" name="dfs_login" placeholder="login / email" style="max-width:220px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px">
                    <input type="password" name="dfs_password" placeholder="password" style="max-width:220px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px">
                    <button class="psc-btn ghost sm" type="button" onclick="pscTest('dataforseo',this)">Test</button>
                </div>
            </div>
        </div>

        <div class="psc-setrow">
            <div class="k">PageSpeed Insights<small>Core Web Vitals per page</small></div>
            <div>
                <?php if ($cs['pagespeed']['configured']): ?><span class="psc-pill on">✓ <?php echo esc_html($cs['pagespeed']['masked']); ?></span><?php else: ?><span class="psc-pill off">Not set</span><?php endif; ?>
                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
                    <input type="text" name="psi_key" placeholder="API key (AIza…)" style="max-width:340px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
                    <button class="psc-btn ghost sm" type="button" onclick="pscTest('pagespeed',this)">Test</button>
                </div>
            </div>
        </div>

        <div class="psc-setrow">
            <div class="k">Anthropic<small>Powers the AI SEO section</small></div>
            <div>
                <?php if ($cs['anthropic']['configured']): ?><span class="psc-pill on">✓ <?php echo esc_html($cs['anthropic']['masked']); ?></span><?php else: ?><span class="psc-pill off">Not set</span><?php endif; ?>
                <div style="color:var(--amber);font-size:12px;margin-top:6px">⚠ If reusing the SAI key, rotate it first — it was flagged as leaked.</div>
                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
                    <input type="password" name="ant_key" placeholder="sk-ant-…" style="max-width:340px;border:1px solid var(--border2);border-radius:8px;padding:7px 9px;background:var(--bg2);color:var(--text);font-size:13px;font-family:var(--mono)">
                    <button class="psc-btn ghost sm" type="button" onclick="pscTest('anthropic',this)">Test</button>
                </div>
            </div>
        </div>

        <div class="psc-setrow"><div class="k">&nbsp;</div><div><button class="psc-btn" type="submit">Save connectors</button></div></div>
    </div>
</form>

<div class="psc-card">
    <div class="psc-sectitle">Import from other plugins (SAI)</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:10px">Scans your site for API keys already saved by other plugins and imports them here. Raw keys are copied internally and never shown in full.</div>
    <button class="psc-btn ghost sm" type="button" onclick="pscScanKeys(this)">↻ Scan for keys</button>
    <div id="psc-scan-result" style="margin-top:12px"></div>
</div>

<form method="post" action="">
    <?php wp_nonce_field('psc_save_settings', 'psc_settings_nonce'); ?>

    <?php if ($g_conn):
        $sites = PSC_GSC::list_sites();
        $props = PSC_GA4::discover_properties();
        $cur_site = PSC_GSC::get_site();
        $cur_prop = PSC_GA4::get_property();
    ?>
    <div class="psc-card">
        <div class="psc-sectitle">Properties</div>
        <div class="psc-setrow">
            <div class="k">Search Console<small>Verified property</small></div>
            <div>
            <?php if (is_wp_error($sites)): ?>
                <input type="text" name="gsc_site" value="<?php echo esc_attr($cur_site); ?>">
                <div style="font-size:12px;color:var(--red);margin-top:5px">Could not list sites: <?php echo esc_html($sites->get_error_message()); ?></div>
            <?php else: ?>
                <select name="gsc_site" style="min-width:280px;border:1px solid var(--border2);border-radius:var(--r);padding:8px;background:var(--bg2);color:var(--text)">
                    <?php foreach ($sites as $s): ?><option value="<?php echo esc_attr($s); ?>" <?php selected($cur_site, $s); ?>><?php echo esc_html($s); ?></option><?php endforeach; ?>
                </select>
            <?php endif; ?>
            </div>
        </div>
        <div class="psc-setrow">
            <div class="k">GA4 property<small>For organic revenue</small></div>
            <div>
            <?php if (is_wp_error($props)): ?>
                <input type="text" name="ga4_property" value="<?php echo esc_attr($cur_prop); ?>" placeholder="properties/123456789">
            <?php else: ?>
                <select name="ga4_property" style="min-width:280px;border:1px solid var(--border2);border-radius:var(--r);padding:8px;background:var(--bg2);color:var(--text)">
                    <option value="">— select —</option>
                    <?php foreach ($props as $p): ?><option value="<?php echo esc_attr($p['id']); ?>" <?php selected($cur_prop, $p['id']); ?>><?php echo esc_html($p['name']); ?></option><?php endforeach; ?>
                </select>
            <?php endif; ?>
            </div>
        </div>
        <div class="psc-setrow">
            <div class="k">Merchant Center ID<small>Numeric account ID</small></div>
            <div><input type="text" name="merchant_id" value="<?php echo esc_attr(PSC_GMC::get_id()); ?>" placeholder="e.g. 5123456789"></div>
        </div>
    </div>
    <?php endif; ?>

    <div class="psc-card">
        <div class="psc-sectitle">Scheduler — auto follow-ups</div>
        <?php foreach ($rules as $key => $rule): ?>
        <div class="psc-srule">
            <div class="grow"><b><?php echo esc_html($rule['label']); ?></b><div class="sub">Snapshot baseline, review after N days</div></div>
            <input class="daybox" type="number" min="1" name="rules[<?php echo esc_attr($key); ?>][days]" value="<?php echo (int) $rule['days']; ?>">
            <span style="color:var(--text3);font-size:12px">days</span>
            <label class="psc-switch"><input type="checkbox" name="rules[<?php echo esc_attr($key); ?>][on]" value="1" <?php checked($rule['on']); ?>><span class="track"></span></label>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="psc-card">
        <div class="psc-setrow">
            <div class="k">Claude bridge<small>REST read/write</small></div>
            <div><span class="psc-pill on">/ps-seo/v1 active</span> <span style="color:var(--text2);font-size:12.5px;margin-left:8px">Reads metrics, writes cards + watchers live · <?php echo $bridge ? 'ps-claude-bridge detected' : 'bridge not detected'; ?></span></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Daily scan<small>Google pull + audit + due watchers</small></div>
            <div><input type="text" name="scan_time" value="<?php echo esc_attr($settings['scan_time']); ?>" style="max-width:170px" placeholder="06:30">
                &nbsp; <button class="psc-btn ghost sm" type="button" onclick="pscSyncNow(this)">Sync now</button></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Keyword history<small>Dated rows for trends</small></div>
            <div><?php
                $last = get_option('psc_gsc_last_sync', '');
                echo $last ? '<span class="psc-pill on">Storing daily · last sync ' . esc_html(human_time_diff(strtotime($last), current_time('timestamp'))) . ' ago</span>'
                           : '<span class="psc-pill off">No sync yet</span>';
            ?></div>
        </div>
        <div class="psc-setrow">
            <div class="k">Storefront impact<small>Footprint</small></div>
            <div><span class="psc-pill on">Admin-only · 0 bytes on shop</span></div>
        </div>
        <div class="psc-setrow">
            <div class="k">&nbsp;</div><div><button class="psc-btn" type="submit">Save settings</button></div>
        </div>
    </div>
</form>
