<?php
if (!defined('ABSPATH')) exit;
/** @var array $signals */

$health   = $signals['health'] ?? PSC_Audit::health_score();
$g_conn   = class_exists('PSC_Google') && PSC_Google::is_connected();
$attention = array_slice(PSC_DB::get_tasks(['status' => 'pending']), 0, 8);
$done      = array_slice(PSC_DB::get_tasks(['status' => 'done']), 0, 6);
$insights  = class_exists('PSC_Insights') ? PSC_Insights::generate() : [];
$sev_color = ['critical' => 'var(--red)', 'warning' => 'var(--amber)', 'opportunity' => 'var(--green)', 'info' => 'var(--text3)'];
$sev_label = ['critical' => 'Critical', 'warning' => 'Warning', 'opportunity' => 'Opportunity', 'info' => 'Info'];
$actions_url = PSC_Admin::tab_url('board');

// changes + aggregate effect, indexed by URL so "Recently done" can show impact
$changes = class_exists('PSC_Changes') ? PSC_Changes::report() : [];
$changes_by_url = [];
$agg = ['clicks' => 0, 'impr' => 0, 'pos' => 0, 'n' => 0];
foreach ($changes as $c) {
    $changes_by_url[$c['url']] = $c;
    if (is_array($c['delta'])) { $agg['clicks'] += $c['delta']['clicks']; $agg['impr'] += $c['delta']['impr']; $agg['pos'] += $c['delta']['pos']; $agg['n']++; }
}
$dl = function ($n, $unit = '', $up_good = true) {
    if ($n === null) return '<span style="color:var(--text3)">—</span>';
    $n = round($n, ($unit === 'pos' ? 1 : 0));
    $good = $up_good ? $n > 0 : $n < 0;
    $col = $n == 0 ? 'var(--text3)' : ($good ? 'var(--green)' : 'var(--red)');
    return '<span style="color:' . $col . ';font-weight:600">' . ($n > 0 ? '+' : '') . $n . '</span>';
};
?>

<!-- 1) Health -->
<div class="psc-health psc-card">
    <div class="psc-ring" style="--v:<?php echo (int) $health; ?>"><div class="inner"><span class="hv"><?php echo (int) $health; ?></span><span class="hl">Health</span></div></div>
    <div>
        <div class="psc-sectitle" style="margin-bottom:6px">SEO health score</div>
        <div style="color:var(--text2);font-size:13px">Composite of on-page coverage (meta, alt), indexability, and open P1 actions, folded together with live Search Console CTR and Merchant feed health. Lower it drops, the more is bleeding traffic or revenue.</div>
    </div>
</div>

<!-- 2) Overall action effect -->
<?php if ($agg['n']): ?>
<div class="psc-card">
    <div class="psc-sectitle">Overall action effect <span style="font-weight:400;font-size:12px;color:var(--text3)">· across <?php echo $agg['n']; ?> tracked change<?php echo $agg['n'] > 1 ? 's' : ''; ?></span></div>
    <div style="display:flex;gap:22px;flex-wrap:wrap;margin-top:4px">
        <div><div style="font-size:22px"><?php echo $dl($agg['clicks']); ?></div><div style="font-size:12px;color:var(--text3)">clicks</div></div>
        <div><div style="font-size:22px"><?php echo $dl($agg['impr']); ?></div><div style="font-size:12px;color:var(--text3)">impressions</div></div>
        <div><div style="font-size:22px"><?php echo $dl($agg['pos'], 'pos'); ?></div><div style="font-size:12px;color:var(--text3)">avg position</div></div>
    </div>
    <div style="font-size:12px;color:var(--text3);margin-top:6px">Net change on the pages you've acted on, vs their baseline before the change. Give each change its waiting period below before judging.</div>
</div>
<?php endif; ?>

<!-- 3) Needs attention (linked to Actions) + Recently done (with impact) -->
<div class="psc-twocol">
    <div class="psc-card">
        <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between"><span>Needs attention</span><a href="<?php echo esc_url($actions_url); ?>" style="font-weight:400;font-size:12px;color:var(--accent);text-decoration:none">open in Actions →</a></div>
        <?php if (empty($attention)): ?><div class="psc-empty">Nothing pending. 🎉</div><?php endif; ?>
        <?php foreach ($attention as $t):
            $sev = $t['priority'] === 'P1' ? 'hi' : ($t['priority'] === 'P2' ? 'med' : 'lo'); ?>
            <a href="<?php echo esc_url($actions_url); ?>" style="text-decoration:none;color:inherit"><div class="psc-li"><span class="psc-sev <?php echo esc_attr($sev); ?>"></span> <?php echo esc_html($t['title']); ?> <span class="g"><?php echo esc_html($t['priority']); ?></span></div></a>
        <?php endforeach; ?>
    </div>
    <div class="psc-card">
        <div class="psc-sectitle">Recently done <span style="font-weight:400;font-size:12px;color:var(--text3)">· with result tracking</span></div>
        <?php if (empty($done)): ?><div class="psc-empty">Nothing completed yet.</div><?php endif; ?>
        <?php foreach ($done as $t):
            $url = $t['target_url'] ?? '';
            $chg = ($url && isset($changes_by_url[$url])) ? $changes_by_url[$url] : null;
            ?>
            <div class="psc-li" style="display:block">
                <div><span class="tick">✓</span> <?php echo esc_html($t['title']); ?> <span class="g"><?php echo esc_html(mysql2date('M j', $t['done_at'] ?: $t['updated_at'])); ?></span></div>
                <?php if ($chg): ?>
                    <div style="font-size:12px;color:var(--text3);margin:2px 0 0 20px">
                        <?php if ($chg['status'] === 'measurable' && is_array($chg['delta'])): ?>
                            result: clicks <?php echo $dl($chg['delta']['clicks']); ?> · CTR <?php echo $dl($chg['delta']['ctr'], 'pt'); ?> · pos <?php echo $dl($chg['delta']['pos'], 'pos'); ?>
                        <?php else: ?>
                            measuring impact — day <?php echo (int) $chg['elapsed_days']; ?> of ~<?php echo (int) $chg['recommended_wait']; ?>
                        <?php endif; ?>
                    </div>
                <?php elseif ($url): ?>
                    <div style="font-size:12px;color:var(--text3);margin:2px 0 0 20px">impact tracking will start on next sync</div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($g_conn): ?>
<!-- 4) Changes & impact tracker -->
<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Changes &amp; impact</span>
        <button class="psc-btn ghost sm" type="button" onclick="pscToggleAddChange()">+ Log a change</button>
    </div>
    <div style="font-size:12.5px;color:var(--text3);margin-bottom:8px">Log what you changed and where — the tracker watches that page's clicks, CTR, and position and reports the effect once enough time has passed for that kind of change.</div>
    <div id="psc-addchange" style="display:none;background:var(--bg2);border-radius:8px;padding:10px;margin-bottom:10px">
        <input id="psc-ch-title" placeholder="What did you change? e.g. Added 12 internal links to push this page" style="width:100%;box-sizing:border-box;margin-bottom:6px;border:1px solid var(--border2);border-radius:6px;padding:7px 9px;background:var(--bg);color:var(--text);font-size:13px">
        <input id="psc-ch-url" placeholder="Target page URL" style="width:100%;box-sizing:border-box;margin-bottom:6px;border:1px solid var(--border2);border-radius:6px;padding:7px 9px;background:var(--bg);color:var(--text);font-size:13px;font-family:var(--mono)">
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
            <select id="psc-ch-kind" style="border:1px solid var(--border2);border-radius:6px;padding:7px;background:var(--bg);color:var(--text);font-size:13px">
                <option value="internal_links">Internal links</option><option value="new_collection">New collection page</option><option value="new_page">New page</option><option value="content">Content rewrite</option><option value="meta">Title / meta</option><option value="redirect">Redirect</option><option value="schema">Schema</option><option value="noindex_fix">Noindex fix</option><option value="other">Other</option>
            </select>
            <input id="psc-ch-date" type="date" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" style="border:1px solid var(--border2);border-radius:6px;padding:7px;background:var(--bg);color:var(--text);font-size:13px">
            <button class="psc-btn sm" type="button" onclick="pscAddChange(this)">Track it</button>
        </div>
    </div>
    <div id="psc-changes-list"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</div>

<!-- 5) Opportunities — pages (collapsed) -->
<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px"><span>Opportunities — pages to push</span><span style="font-weight:400;font-size:12px;color:var(--text3)">tap to expand</span></summary>
    <div style="font-size:12.5px;color:var(--text3);margin:8px 0">Pages that already rank but can move with a focused action — with the exact suggestion, an edit link, and one-tap add-to-board.</div>
    <div id="psc-opps-pages"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</details>

<!-- 6) Opportunities — keywords (collapsed) -->
<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px"><span>Opportunities — keywords</span><span style="font-weight:400;font-size:12px;color:var(--text3)">tap to expand</span></summary>
    <div style="font-size:12.5px;color:var(--text3);margin:8px 0">Search terms with real demand sitting on page 2 — a page targeting these can capture the traffic.</div>
    <div id="psc-opps-keywords"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</details>
<?php endif; ?>

<!-- Site-wide SEO health checks -->
<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Site deep scan</span>
        <button class="psc-btn sm" type="button" id="psc-ov-scan-btn" onclick="pscOvScanStart(this)">Scan all pages</button>
    </div>
    <div style="font-size:12.5px;color:var(--text3)">Crawls every page on the site in small background batches (won't strain the server) and feeds the three health checks below. Safe to leave the page — it keeps running server-side.</div>
    <div id="psc-ov-scan-wrap" style="display:none;margin-top:10px">
        <div style="background:var(--bg2);border-radius:99px;height:10px;overflow:hidden"><div id="psc-ov-scan-fill" style="height:100%;width:0%;background:var(--accent);border-radius:99px;transition:width .4s"></div></div>
        <div id="psc-ov-scan-txt" style="font-size:12px;color:var(--text3);margin-top:5px"></div>
    </div>
    <div id="psc-ov-scan-last" style="font-size:12px;color:var(--text3);margin-top:6px"></div>
</div>

<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px"><span>Content health <span style="font-weight:400;font-size:12px;color:var(--text3)">· depth &amp; uniqueness</span></span><span id="psc-sh-content-score" style="font-weight:400;font-size:12px;color:var(--text3)">tap to expand</span></summary>
    <div style="font-size:12.5px;color:var(--text3);margin:8px 0">Deep scan of every page (runs in background batches during the site crawl): AI-sounding phrasing, keyword stuffing, robotic rhythm, length vs page-type, duplicates, H1s and metas — per Google's helpful-content guidance.</div>
    <div id="psc-sh-content"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</details>

<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px"><span>Internal linking health</span><span id="psc-sh-links-score" style="font-weight:400;font-size:12px;color:var(--text3)">tap to expand</span></summary>
    <div style="font-size:12.5px;color:var(--text3);margin:8px 0">The whole-site link graph: orphan pages, under-linked ranking pages, links wasted on dead/tag pages, and over-linking — products, categories, tags, collections, and pages.</div>
    <div id="psc-sh-links"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</details>

<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px"><span>Consolidation &amp; cannibalization</span><span id="psc-sh-cons-score" style="font-weight:400;font-size:12px;color:var(--text3)">tap to expand</span></summary>
    <div style="font-size:12.5px;color:var(--text3);margin:8px 0">Where pages compete or duplicate: one query ranking several pages (merge/canonical), zero-click tag pages (noindex), and duplicate content (consolidate).</div>
    <div id="psc-sh-cons"><div style="font-size:13px;color:var(--text3)">Loading…</div></div>
</details>

<!-- 7) Insights (collapsed) -->
<?php
$crit = count(array_filter($insights, function ($i) { return $i['severity'] === 'critical'; }));
$warn = count(array_filter($insights, function ($i) { return $i['severity'] === 'warning'; }));
$opp  = count(array_filter($insights, function ($i) { return $i['severity'] === 'opportunity'; }));
?>
<details class="psc-card">
    <summary style="cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:14px">
        <span>Insights &amp; recommendations</span>
        <span style="font-weight:400;font-size:12px">
            <?php if ($crit): ?><span style="color:var(--red)"><?php echo $crit; ?> critical</span> · <?php endif; ?>
            <?php if ($warn): ?><span style="color:var(--amber)"><?php echo $warn; ?> warning</span> · <?php endif; ?>
            <span style="color:var(--green)"><?php echo $opp; ?> opportunity</span>
        </span>
    </summary>
    <?php if (empty($insights)): ?>
        <div style="font-size:13px;color:var(--green);margin-top:8px">✓ Nothing urgent.</div>
    <?php else: foreach ($insights as $it): $col = $sev_color[$it['severity']] ?? 'var(--text3)'; ?>
        <div style="padding:10px 0;border-top:1px solid var(--border)">
            <div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap">
                <span style="font-size:10px;font-weight:700;color:#fff;background:<?php echo esc_attr($col); ?>;padding:1px 7px;border-radius:5px;text-transform:uppercase"><?php echo esc_html($sev_label[$it['severity']] ?? $it['severity']); ?></span>
                <b style="font-size:14px"><?php echo esc_html($it['title']); ?></b>
                <a href="<?php echo esc_url(PSC_Admin::tab_url($it['tab'])); ?>" style="margin-left:auto;font-size:12px;color:var(--accent);text-decoration:none"><?php echo esc_html(ucfirst($it['tab'])); ?> →</a>
            </div>
            <div style="font-size:13px;color:var(--text2);margin-top:4px"><?php echo esc_html($it['finding']); ?></div>
            <div style="font-size:13px;color:var(--text);margin-top:3px">→ <?php echo esc_html($it['action']); ?></div>
        </div>
    <?php endforeach; endif; ?>
</details>
