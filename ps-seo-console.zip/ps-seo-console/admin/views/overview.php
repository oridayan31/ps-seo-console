<?php
if (!defined('ABSPATH')) exit;
/** @var array $progress @var array $signals @var array $settings */

$health = $signals['health'] ?? PSC_Audit::health_score();
$bridge = class_exists('PS_Claude_Bridge');
$g_conn = class_exists('PSC_Google') && PSC_Google::is_connected();
$ga4_on = $g_conn && (bool) PSC_GA4::get_property();
$gmc_on = $g_conn && (bool) PSC_GMC::get_id();
$conn = function ($on) { return $on ? ['on', 'Connected'] : ['off', 'Not connected']; };
$c_gsc = $conn($g_conn); $c_ga4 = $conn($ga4_on); $c_gmc = $conn($gmc_on); $c_br = $conn($bridge);

$attention = PSC_DB::get_tasks(['status' => 'pending']);
$attention = array_slice($attention, 0, 5);
$done = array_slice(PSC_DB::get_tasks(['status' => 'done']), 0, 5);

$gs_active = class_exists('PSC_GoogleStatus') ? PSC_GoogleStatus::active() : [];
$gs_recent = class_exists('PSC_GoogleStatus') ? PSC_GoogleStatus::recent(2) : [];
$insights  = class_exists('PSC_Insights') ? PSC_Insights::generate() : [];
$sev_color = ['critical' => 'var(--red)', 'warning' => 'var(--amber)', 'opportunity' => 'var(--green)', 'info' => 'var(--text3)'];
$sev_label = ['critical' => 'Critical', 'warning' => 'Warning', 'opportunity' => 'Opportunity', 'info' => 'Info'];
?>
<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Insights &amp; recommendations</span>
        <span style="font-weight:400;font-size:12px;color:var(--text3)"><?php echo count($insights); ?> from your live data</span>
    </div>
    <?php if (empty($insights)): ?>
        <div style="font-size:13px;color:var(--green)">✓ Nothing urgent — connect Google + sync if this looks empty.</div>
    <?php else: ?>
        <?php foreach ($insights as $it):
            $col = $sev_color[$it['severity']] ?? 'var(--text3)';
        ?>
            <div style="padding:10px 0;border-top:1px solid var(--border)">
                <div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap">
                    <span style="font-size:10px;font-weight:700;color:#fff;background:<?php echo esc_attr($col); ?>;padding:1px 7px;border-radius:5px;text-transform:uppercase"><?php echo esc_html($sev_label[$it['severity']] ?? $it['severity']); ?></span>
                    <b style="font-size:14px"><?php echo esc_html($it['title']); ?></b>
                    <a href="<?php echo esc_url(PSC_Admin::tab_url($it['tab'])); ?>" style="margin-left:auto;font-size:12px;color:var(--accent);text-decoration:none"><?php echo esc_html(ucfirst($it['tab'])); ?> →</a>
                </div>
                <div style="font-size:13px;color:var(--text2);margin-top:4px"><?php echo esc_html($it['finding']); ?></div>
                <div style="font-size:13px;color:var(--text);margin-top:3px">→ <?php echo esc_html($it['action']); ?></div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="psc-card" style="border-left:3px solid <?php echo $gs_active ? 'var(--amber)' : 'var(--green)'; ?>">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Google Search status</span>
        <a href="https://status.search.google.com/" target="_blank" rel="noopener" style="font-weight:400;font-size:12px;color:var(--text3);text-decoration:none">dashboard ↗</a>
    </div>
    <?php if ($gs_active): ?>
        <?php foreach ($gs_active as $i): ?>
            <div style="font-size:13px;margin-bottom:4px">
                <span style="color:var(--amber);font-weight:600">● <?php echo esc_html($i['service']); ?></span> —
                <a href="<?php echo esc_url($i['url']); ?>" target="_blank" rel="noopener" style="color:var(--text);text-decoration:none"><?php echo esc_html($i['title']); ?></a>
                <span style="color:var(--text3);font-size:12px">(<?php echo esc_html($i['ongoing'] ? 'ongoing' : 'rolling out'); ?>)</span>
            </div>
        <?php endforeach; ?>
        <div style="font-size:12px;color:var(--text3);margin-top:6px">A ranking/traffic move right now may be Google-side. Check before blaming a change.</div>
    <?php else: ?>
        <div style="font-size:13px;color:var(--green)">✓ No active Google Search incidents.</div>
        <?php if ($gs_recent): ?>
            <div style="font-size:12px;color:var(--text3);margin-top:6px">Recent:
                <?php echo esc_html(implode(' · ', array_map(function ($i) {
                    return $i['title'] . ' (' . $i['service'] . ', ' . mb_substr((string) $i['begin'], 0, 10) . ')';
                }, $gs_recent))); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="psc-ovgrid">
    <div class="psc-conn psc-card"><span class="ic" style="background:color-mix(in srgb,var(--accent) 12%,transparent);color:var(--accent)">◈</span><div><div class="nm">Search Console</div><div class="st <?php echo esc_attr($c_gsc[0]); ?>"><?php echo esc_html($c_gsc[1]); ?></div></div></div>
    <div class="psc-conn psc-card"><span class="ic" style="background:color-mix(in srgb,var(--amber) 14%,transparent);color:var(--amber)">▲</span><div><div class="nm">Analytics (GA4)</div><div class="st <?php echo esc_attr($c_ga4[0]); ?>"><?php echo esc_html($c_ga4[1]); ?></div></div></div>
    <div class="psc-conn psc-card"><span class="ic" style="background:color-mix(in srgb,#ea4335 12%,transparent);color:#ea4335">◆</span><div><div class="nm">Merchant Center</div><div class="st <?php echo esc_attr($c_gmc[0]); ?>"><?php echo esc_html($c_gmc[1]); ?></div></div></div>
    <div class="psc-conn psc-card"><span class="ic" style="background:color-mix(in srgb,var(--green) 14%,transparent);color:var(--green)">⚡</span><div><div class="nm">Site bridge</div><div class="st <?php echo esc_attr($c_br[0]); ?>"><?php echo $bridge ? 'Connected' : 'Not detected'; ?></div></div></div>
</div>

<?php $due_soon = class_exists('PSC_Watchers') ? PSC_Watchers::upcoming(4) : []; ?>
<?php if (!empty($due_soon)): ?>
<div class="psc-card" style="border-left:3px solid var(--accent);border-radius:0 var(--r) var(--r) 0">
    <div class="psc-sectitle">Scheduled follow-ups</div>
    <?php foreach ($due_soon as $w): ?>
        <div class="psc-li"><span class="psc-sev med"></span> <?php echo esc_html($w['subject_label']); ?> <span class="g">due <?php echo esc_html(mysql2date('M j', $w['due_at'])); ?></span></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="psc-health psc-card">
    <div class="psc-ring" style="--v:<?php echo (int) $health; ?>"><div class="inner"><span class="hv"><?php echo (int) $health; ?></span><span class="hl">Health</span></div></div>
    <div>
        <div class="psc-sectitle" style="margin-bottom:6px">SEO health score</div>
        <div style="color:var(--text2);font-size:13px">Composite of meta coverage, product alt text, and open P1s — all computed locally. Connect Google to fold in CTR and feed data; the score sharpens in Phase 2.</div>
    </div>
</div>

<div class="psc-twocol">
    <div class="psc-card">
        <div class="psc-sectitle">Needs attention</div>
        <?php if (empty($attention)): ?><div class="psc-empty">Nothing pending. 🎉</div><?php endif; ?>
        <?php foreach ($attention as $t):
            $sev = $t['priority'] === 'P1' ? 'hi' : ($t['priority'] === 'P2' ? 'med' : 'lo'); ?>
            <div class="psc-li"><span class="psc-sev <?php echo esc_attr($sev); ?>"></span> <?php echo esc_html($t['title']); ?> <span class="g"><?php echo esc_html($t['priority']); ?></span></div>
        <?php endforeach; ?>
    </div>
    <div class="psc-card">
        <div class="psc-sectitle">Recently done</div>
        <?php if (empty($done)): ?><div class="psc-empty">Nothing completed yet.</div><?php endif; ?>
        <?php foreach ($done as $t): ?>
            <div class="psc-li"><span class="tick">✓</span> <?php echo esc_html($t['title']); ?> <span class="g"><?php echo esc_html(mysql2date('M j', $t['done_at'] ?: $t['updated_at'])); ?></span></div>
        <?php endforeach; ?>
    </div>
</div>
