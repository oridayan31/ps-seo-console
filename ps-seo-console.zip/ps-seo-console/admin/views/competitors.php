<?php
if (!defined('ABSPATH')) exit;
/** @var array $settings */

$rep  = PSC_Competitors::report(false);
$st   = $rep['status'] ?? 'idle';
$rows = $rep['rows'] ?? [];
$fmt  = function ($n) { return $n === null ? '—' : number_format((int) $n); };
?>
<div class="psc-card">
    <div class="psc-sectitle" style="display:flex;align-items:center;justify-content:space-between">
        <span>Competitor authority &amp; backlink gap</span>
        <button class="psc-btn ghost sm" type="button" onclick="pscRefreshCompetitors(this)">↻ Fetch live data</button>
    </div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:12px">Referring domains + authority vs your competitor set. Uses DataForSEO Backlinks (metered), so it pulls only when you press fetch, then caches for 24h.</div>

    <?php if ($st === 'needs_dataforseo'): ?>
        <div style="font-size:13px;color:var(--amber);margin-bottom:12px">⚠ No DataForSEO account connected. This needs a DataForSEO account (paid API) — there are no credentials stored anywhere on this site to import. If you have one: enter the login + password under Settings → <b>Data connectors</b> (with the Backlinks API enabled on that account). If not, this section simply stays empty — everything else in the Console works without it.</div>
    <?php elseif ($st === 'error'): ?>
        <div style="font-size:13px;color:var(--red);margin-bottom:12px">✗ <?php echo esc_html($rep['note'] ?? 'Fetch failed.'); ?></div>
    <?php elseif ($st === 'idle'): ?>
        <div style="font-size:13px;color:var(--text3);margin-bottom:12px">Press <b>Fetch live data</b> to pull current referring domains for your site and the competitors below.</div>
    <?php endif; ?>

    <?php if ($st === 'ok'): ?>
        <?php $behind = ($rep['gap'] !== null && $rep['gap'] > 1); ?>
        <div style="display:inline-block;background:<?php echo $behind ? 'color-mix(in srgb,var(--amber) 16%,transparent)' : 'color-mix(in srgb,var(--green) 16%,transparent)'; ?>;color:<?php echo $behind ? 'var(--amber)' : 'var(--green)'; ?>;font-weight:600;font-size:12px;padding:4px 10px;border-radius:20px;margin-bottom:12px">
            <?php echo $behind ? 'Behind competitor median' : 'At or above competitor median'; ?>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
            <div style="flex:1;min-width:150px;background:color-mix(in srgb,var(--accent) 8%,transparent);border:1px solid var(--border);border-radius:10px;padding:12px">
                <div style="font-size:12px;color:var(--accent)">Your referring domains</div>
                <div style="font-size:24px;font-weight:700"><?php echo esc_html($fmt($rep['you_rd'])); ?></div>
            </div>
            <div style="flex:1;min-width:150px;background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:12px">
                <div style="font-size:12px;color:var(--text3)">Competitor median domains</div>
                <div style="font-size:24px;font-weight:700"><?php echo esc_html($fmt($rep['median'])); ?></div>
            </div>
            <div style="flex:1;min-width:150px;background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:12px">
                <div style="font-size:12px;color:var(--text3)">Current gap</div>
                <div style="font-size:24px;font-weight:700"><?php echo $rep['gap'] !== null ? esc_html($rep['gap']) . 'x' : '—'; ?></div>
            </div>
        </div>
    <?php endif; ?>

    <table style="width:100%;border-collapse:collapse;font-size:13px">
        <thead><tr style="color:var(--text3);text-align:left;font-size:11px;text-transform:uppercase">
            <th style="padding:6px 8px;width:28px">#</th><th style="padding:6px 8px">Domain</th>
            <th style="padding:6px 8px;text-align:right">Referring domains</th>
            <th style="padding:6px 8px;text-align:right">Authority</th><th style="padding:6px 8px;width:34px"></th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r):
            $you = !empty($r['you']);
        ?>
            <tr style="border-top:1px solid var(--border);<?php echo $you ? 'background:color-mix(in srgb,var(--accent) 8%,transparent)' : ''; ?>">
                <td style="padding:9px 8px;color:var(--text3)"><?php echo (int) $i + 1; ?></td>
                <td style="padding:9px 8px;font-weight:<?php echo $you ? '700' : '500'; ?>">
                    <?php echo esc_html($r['domain']); ?>
                    <?php if ($you): ?><span style="background:var(--accent);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:5px;margin-left:6px">YOU</span><?php endif; ?>
                </td>
                <td style="padding:9px 8px;text-align:right;font-weight:<?php echo $you ? '700' : '400'; ?>"><?php echo esc_html($fmt($r['referring_domains'])); ?></td>
                <td style="padding:9px 8px;text-align:right"><?php echo $r['authority'] === null ? '—' : esc_html($r['authority']); ?></td>
                <td style="padding:9px 8px;text-align:right">
                    <?php if (!$you): ?><button class="psc-mini" title="Remove" onclick="pscRemoveCompetitor('<?php echo esc_js($r['domain']); ?>',this)">🗑</button><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="font-size:11px;color:var(--text3);margin-top:8px">Authority ≈ DataForSEO domain rank normalized to 0–100 (comparable to DR/DA, not identical). <?php echo !empty($rep['generated_at']) ? 'Updated ' . esc_html($rep['generated_at']) : ''; ?></div>
</div>

<div class="psc-card">
    <div class="psc-sectitle">Add a competitor</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <input type="text" id="psc-comp-input" placeholder="competitor.com (root domain only)" style="flex:1;min-width:220px;border:1px solid var(--border2);border-radius:8px;padding:9px 11px;background:var(--bg2);color:var(--text);font-size:13px">
        <button class="psc-btn" type="button" onclick="pscAddCompetitor(this)">Add competitor</button>
    </div>
    <div style="font-size:12px;color:var(--text3);margin-top:8px">Root domains only (e.g. competitor.com). Subdomains like blog.competitor.com aren't allowed.</div>
</div>
