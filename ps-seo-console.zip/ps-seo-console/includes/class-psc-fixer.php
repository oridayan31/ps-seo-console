<?php
if (!defined('ABSPATH')) exit;

/**
 * Fix workflow: preview → approve → push live.
 *  1. preview(url, code): builds a detailed prompt for Claude, generates the fix, stores it as a proposal,
 *     and returns it for on-screen review (old vs new).
 *  2. apply(id): writes the approved fix to the live site (Yoast meta / canonical / post content),
 *     purges cache, and logs it to the Changes→impact tracker.
 * Content fixes on Elementor-built pages are returned as 'manual' (preview + copy) — we never blind-write
 * into Elementor JSON. Classic/Gutenberg post content is safe to push.
 */
class PSC_Fixer {

    const OPT = 'psc_fix_proposals';

    /** How bad each issue is for SEO (0-100) + why — shown as the impact score per row. */
    public static function impact($code) {
        $map = [
            'noindex'        => [95, 'Critical', 'Page is invisible to Google — direct traffic loss'],
            'ai_content'     => [80, 'High', 'Reads machine-generated — scaled-content/helpful-content policy risk for the whole site'],
            'stuffing'       => [75, 'High', 'Keyword stuffing is a spam signal and hurts the page and site quality assessment'],
            'robotic'        => [70, 'High', 'Uniform machine rhythm undermines content quality assessment'],
            'duplicate'      => [70, 'High', 'Near-identical pages split ranking signals and waste crawl budget'],
            'no_h1'          => [65, 'High', 'Google can\'t identify the page topic cleanly; hurts relevance matching'],
            'underlinked'    => [70, 'High', 'A page that already ranks is starved of internal equity — cheapest win available'],
            'orphan'         => [60, 'Medium', 'No internal path in — weak crawl discovery and zero link equity'],
            'wasted_links'   => [55, 'Medium', 'Equity flows to dead/noindex targets instead of ranking pages'],
            'dense_links'    => [65, 'High', 'Unnatural link density looks manipulative and dilutes every link on the page'],
            'meta_missing'   => [55, 'Medium', 'Google writes its own snippet — you lose the pitch, CTR suffers'],
            'thin'           => [50, 'Medium', 'Under useful length for its template — can\'t satisfy the query'],
            'generic_anchor' => [35, 'Low', '"Click here" anchors tell Google nothing about the target'],
            'over_linked'    => [30, 'Low', '150+ links dilute equity and readability'],
        ];
        return $map[$code] ?? [40, 'Medium', ''];
    }

    private static function proposals() { $p = get_option(self::OPT, []); return is_array($p) ? $p : []; }
    private static function save($p) { update_option(self::OPT, array_slice($p, -40, null, true), false); }

    private static function pid_for($url) {
        $pid = function_exists('url_to_postid') ? url_to_postid($url) : 0;
        if (!$pid && trim((string) wp_parse_url($url, PHP_URL_PATH), '/') === '') $pid = (int) get_option('page_on_front');
        return $pid;
    }

    private static function page_text($url, $chars = 4000) {
        $r = wp_remote_get($url, ['timeout' => 10, 'headers' => ['User-Agent' => 'PSC-Fixer/1.0']]);
        $html = is_wp_error($r) ? '' : wp_remote_retrieve_body($r);
        $t = ['title' => '', 'h1' => '', 'text' => ''];
        if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $t['title'] = trim(wp_strip_all_tags($m[1]));
        if (preg_match('#<h1[^>]*>(.*?)</h1>#is', $html, $m)) $t['h1'] = trim(wp_strip_all_tags($m[1]));
        $body = preg_replace('#<(script|style|noscript|nav|header|footer)\b[^>]*>.*?</\1>#is', ' ', $html);
        $t['text'] = mb_substr(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($body))), 0, $chars);
        return $t;
    }

    private static function store($data) {
        $p = self::proposals();
        $id = substr(md5(uniqid('', true)), 0, 10);
        $data['id'] = $id; $data['created'] = current_time('mysql');
        $p[$id] = $data;
        self::save($p);
        return $data;
    }

    /** Build the fix with Claude and return it for preview. */
    public static function preview($url, $code, $extra = []) {
        if (!class_exists('PSC_Connectors') || !PSC_Connectors::has_anthropic()) return ['ok' => false, 'message' => 'Add your Anthropic key in Settings first.'];
        $pid = self::pid_for($url);
        $brand = 'Premium wall-art print shop (Print Studio): museum-grade 310gsm archival giclée paper and canvas, free shipping over $69, curated collections.';

        switch ($code) {
            case 'meta_missing':
                $pg = self::page_text($url, 1500);
                $new = trim(PSC_Brain::complete(
                    "You write compelling SEO meta descriptions. Return ONLY the description text, 150-160 characters, active voice, one concrete benefit + soft call to action. {$brand}",
                    "Page H1: {$pg['h1']}\nTitle: {$pg['title']}\nPage text: {$pg['text']}", 1200), " \"'\n");
                if ($new === '') return ['ok' => false, 'message' => 'Generation failed: ' . (PSC_Brain::$last_error ?: 'empty response')];
                return ['ok' => true] + self::store(['url' => $url, 'pid' => $pid, 'code' => $code, 'mode' => $pid ? 'auto' : 'manual',
                    'field' => 'Meta description (Yoast)', 'old' => '(none)', 'new' => $new]);

            case 'no_h1':
                $pg = self::page_text($url, 2000);
                $new = trim(PSC_Brain::complete(
                    "You write clear, descriptive page H1 headings. Return ONLY the H1 text (max 65 chars), naming the page's real topic, no quotes. {$brand}",
                    "Page title: {$pg['title']}\nPage text: {$pg['text']}\n\nWrite the H1 this page should have.", 1000), " \"'\n");
                if ($new === '') return ['ok' => false, 'message' => 'Generation failed: ' . (PSC_Brain::$last_error ?: 'empty response')];
                // H1 lives inside the page layout (usually Elementor) — propose it, human pastes it in the heading widget.
                return ['ok' => true] + self::store(['url' => $url, 'pid' => $pid, 'code' => $code, 'mode' => 'manual',
                    'field' => 'H1 heading', 'old' => '(missing)', 'new' => $new,
                    'note' => 'Paste into the page\'s top heading widget and set its tag to H1.',
                    'edit_url' => $pid ? admin_url('post.php?post=' . $pid . '&action=edit') : '']);

            case 'duplicate':
                $primary = esc_url_raw($extra['primary'] ?? '');
                if (!$pid || !$primary) return ['ok' => false, 'message' => 'Need the page and its primary version.'];
                return ['ok' => true] + self::store(['url' => $url, 'pid' => $pid, 'code' => $code, 'mode' => 'auto',
                    'field' => 'Canonical URL (Yoast)', 'old' => '(self)', 'new' => $primary,
                    'note' => 'Points Google at the primary version; this page stays live for users.']);

            case 'stuffing': case 'ai_content': case 'robotic': case 'thin': case 'dense_links': case 'generic_anchor':
                if (!$pid) return ['ok' => false, 'message' => 'Could not resolve this URL to an editable post.'];
                $post = get_post($pid);
                $is_elementor = get_post_meta($pid, '_elementor_edit_mode', true) === 'builder';
                $content = $post ? $post->post_content : '';
                if ($is_elementor || str_word_count(wp_strip_all_tags($content)) < 50) {
                    // Don't blind-write Elementor JSON — generate the fixed copy for manual paste.
                    $pg = self::page_text($url, 5000);
                    $src = $pg['text']; $manual = true;
                } else { $src = $content; $manual = false; }
                $goal = [
                    'stuffing'       => 'Remove the keyword stuffing: cut repetition of the dominant keyword to natural frequency.',
                    'ai_content'     => 'Rewrite in a first-hand curator voice: remove stock AI phrasing, add concrete specifics (materials: 310gsm archival giclée; sizing; real room pairings; curation reasoning).',
                    'robotic'        => 'Vary sentence length and rhythm; make it read human. Add specific, concrete detail.',
                    'thin'           => 'Expand with genuinely useful depth for a shopper: sizing guidance, materials, styling/pairing advice. No padding.',
                    'dense_links'    => 'Reduce internal links to only the few most relevant contextual ones (max ~6), integrated naturally in sentences.',
                    'generic_anchor' => 'Replace generic anchors ("click here", "read more") with descriptive anchor text; keep the same link targets.',
                ][$code];
                $new = trim(PSC_Brain::complete(
                    "You are the shop's content editor fixing one page. {$brand}\nRULES: keep the same HTML structure and heading levels; keep facts accurate; no invented claims; no stock AI filler; descriptive anchors only; concise, human, first-hand tone. Return ONLY the revised HTML/content, nothing else.",
                    "TASK: {$goal}\n\nCURRENT CONTENT:\n{$src}", 6000));
                if ($new === '') return ['ok' => false, 'message' => 'Generation failed: ' . (PSC_Brain::$last_error ?: 'empty response')];
                return ['ok' => true] + self::store(['url' => $url, 'pid' => $pid, 'code' => $code, 'mode' => $manual ? 'manual' : 'auto',
                    'field' => 'Page content', 'old' => mb_substr(wp_strip_all_tags($src), 0, 600) . '…', 'new' => $new,
                    'note' => $manual ? 'This page is built in Elementor — copy the fixed copy into the editor (we never overwrite Elementor layouts automatically).' : '',
                    'edit_url' => admin_url('post.php?post=' . $pid . '&action=edit')]);
        }
        return ['ok' => false, 'message' => 'No automated fix for this issue type — use the edit link.'];
    }

    /** Apply an approved proposal to the live site + log it. */
    public static function apply($id) {
        $p = self::proposals();
        if (empty($p[$id])) return ['ok' => false, 'message' => 'Proposal expired — generate it again.'];
        $f = $p[$id];
        if (($f['mode'] ?? '') !== 'auto' || empty($f['pid'])) return ['ok' => false, 'message' => 'This fix is manual — use the edit link and paste the preview.'];
        switch ($f['code']) {
            case 'meta_missing': update_post_meta($f['pid'], '_yoast_wpseo_metadesc', $f['new']); $kind = 'meta'; break;
            case 'duplicate':    update_post_meta($f['pid'], '_yoast_wpseo_canonical', $f['new']); $kind = 'schema'; break;
            default:
                $ok = wp_update_post(['ID' => $f['pid'], 'post_content' => $f['new']], true);
                if (is_wp_error($ok)) return ['ok' => false, 'message' => $ok->get_error_message()];
                $kind = 'content';
        }
        wp_update_post(['ID' => $f['pid']]); // touch post so Yoast rebuilds its indexable from the new meta
        if (function_exists('wp_cache_flush')) wp_cache_flush();
        do_action('litespeed_purge_url', $f['url']);
        // Kinsta full-page cache purge (best effort)
        global $kinsta_cache;
        if (!empty($kinsta_cache->kinsta_cache_purge) && method_exists($kinsta_cache->kinsta_cache_purge, 'purge_complete_caches')) {
            $kinsta_cache->kinsta_cache_purge->purge_complete_caches();
        }
        if (class_exists('PSC_Changes')) PSC_Changes::add([
            'title' => 'Fix: ' . $f['field'] . ' — ' . wp_parse_url($f['url'], PHP_URL_PATH),
            'url' => $f['url'], 'kind' => $kind, 'note' => 'Approved via fix workflow',
        ]);
        unset($p[$id]); self::save($p);
        return ['ok' => true, 'message' => 'Pushed live + logged to Changes tracker.'];
    }
}
