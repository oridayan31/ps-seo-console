<?php
if (!defined('ABSPATH')) exit;

/**
 * The "brain". Two parts:
 *  1) A knowledge base — the durable handoff: what this site is, its brand facts,
 *     the corrected understandings, and the SEO principles we operate by. Editable
 *     (stored in an option) so it grows over time; falls back to the seeded default.
 *  2) An analyst — gathers a live snapshot of every signal the Console computes and
 *     reasons over it (via the site's Anthropic key), grounded in the knowledge base.
 * Ask it anything about the site, or let it produce a prioritized strategic read.
 */
class PSC_Brain {

    const MODEL  = 'claude-sonnet-5';
    const OPT_KB = 'psc_brain_kb';

    /* ---------- knowledge base (the handoff) ---------- */

    public static function knowledge() {
        $k = trim((string) get_option(self::OPT_KB, ''));
        return $k !== '' ? $k : self::default_kb();
    }
    public static function save_knowledge($t) { update_option(self::OPT_KB, (string) $t); }
    public static function is_custom() { return trim((string) get_option(self::OPT_KB, '')) !== ''; }

    public static function default_kb() {
        return <<<KB
# PS SEO Console — site brain / handoff

## Who this is
printstudio.art — a global (USD) wall-art print shop on WooCommerce + Elementor Pro + Yoast + Kinsta, ~720 products, print-on-demand via Gelato & Prodigi (APIs) with Printseekers (manual). Sister site printstudio.co.il serves the Israeli market (Hebrew, RTL, ILS) — a separate instance. The owner runs the business primarily from mobile and wants concise, direct English, prioritized by revenue/traffic impact.

## Fixed brand facts (weave into content, never contradict)
310gsm archival Giclée paper; ~75-year archival life; free shipping over \$69; canvas and paper formats; target markets US, EU, UK, CA, AU. Positioning is premium/curated, not cheap-and-mass.

## Connected data (ground truth)
- Search Console site: https://printstudio.art/
- GA4 property: "Print Studio Global" = properties/449386684. This is the CORRECT one. properties/434277032 ("printstudio") is a DIFFERENT site — never use it.
- Merchant Center account: 5358567846.

## Corrected understandings (hard-won — do not regress)
- Merchant Center is HEALTHY, not blocked. Products are approved and serving (mostly in IL). A destination-level "disapproved" flag with a non-empty approvedCountries list means the product IS serving, not dead. Only "approved in zero countries" = truly disapproved. The real open question is country COVERAGE: most products look approved in IL only, which may under-serve the global target markets.
- The AI-drafted blog posts are the content weak spot: they grade HIGH risk on Google's Helpful Content signals (keyword-stuffed, templated listicle structure, generic filler, weak E-E-A-T, sometimes cut off mid-sentence). This is where scaled-content demotion risk lives.
- Always cross-check dramatic findings against the real Google UI before alarming the owner. Never invent numbers — use the live snapshot provided.

## Operating principles (SEO/AEO)
- Collections outperform tags: convert high-demand tags into collection pages, 301 overlapping tags in, noindex the rest.
- Use canonicals (not 301s) to consolidate duplicate content when the target already ranks well; only 301/redirect pages below ~position 15.
- Striking-distance pages (positions 5–15) are the best traffic ROI — small pushes (content + internal links + tighter titles/meta) move them to page 1.
- Low sitewide CTR at average position ~12 means page-2 visibility — fix with ranking pushes + click-worthy titles/meta, not just more content.
- Content must show first-hand experience / a curator voice and real product specifics (pricing, sizing, curation) — not generic art-history filler. E-E-A-T matters.
- Internal links need descriptive anchors naming the destination (never "read more"/"click here").
- Headings must be sequential (no H2→H4/H6 skips).

## How to advise
Be concise and mobile-friendly. Lead with the single highest-impact action and why. Prioritize by revenue first (Shopping/checkout/conversion), then traffic (rankings/CTR), then hygiene. Be honest about uncertainty; distinguish "measured" from "worth verifying". Reference the live numbers you're given. Offer a concrete next step.
KB;
    }

    /* ---------- live snapshot ---------- */

    public static function context() {
        $ctx = ['as_of' => current_time('mysql')];

        if (class_exists('PSC_Audit')) {
            $s = PSC_Audit::get_signals();
            $ctx['health_score'] = $s['health'] ?? null;
            $sig = [];
            foreach (($s['groups'] ?? []) as $g) $sig[$g['key'] ?? '?'] = (int) ($g['count'] ?? 0);
            $ctx['audit_signals'] = $sig;
        }
        if (class_exists('PSC_GSC')) {
            $k = PSC_GSC::kpis();
            if (is_array($k)) $ctx['search_console_28d'] = [
                'clicks' => $k['clicks']['value'] ?? null, 'impressions' => $k['impressions']['value'] ?? null,
                'ctr_pct' => $k['ctr']['value'] ?? null, 'avg_position' => $k['position']['value'] ?? null,
            ];
        }
        if (class_exists('PSC_Insights')) {
            $ctx['insights'] = array_map(function ($i) {
                return ['severity' => $i['severity'], 'title' => $i['title'], 'finding' => $i['finding']];
            }, PSC_Insights::generate());
        }
        if (class_exists('PSC_Conversion')) {
            $c = PSC_Conversion::report(28);
            $f = $c['funnel'] ?? [];
            if (($f['status'] ?? '') === 'ok') $ctx['ga4_funnel_28d'] = [
                'sessions' => $f['sessions'] ?? null, 'add_to_carts' => $f['add_to_carts'] ?? null,
                'checkouts' => $f['checkouts'] ?? null, 'purchases' => $f['purchases'] ?? null,
                'revenue' => $f['revenue'] ?? null, 'cart_abandonment_pct' => $f['cart_abandonment'] ?? null,
                'checkout_abandonment_pct' => $f['checkout_abandonment'] ?? null,
            ];
            $gw = $c['gateways'] ?? [];
            if (($gw['status'] ?? '') === 'ok') {
                $active = [];
                foreach (($gw['items'] ?? []) as $it) if ((int) ($it['orders'] ?? 0) > 0) $active[] = $it['title'] . ':' . $it['orders'];
                $ctx['woocommerce_28d'] = ['orders' => $gw['window_orders'] ?? null, 'by_gateway' => $active];
            }
        }
        if (class_exists('PSC_GMC') && PSC_GMC::get_id()) {
            $g = PSC_GMC::get_status();
            if (empty($g['error'])) $ctx['merchant_center'] = [
                'serving' => (int) ($g['active'] ?? 0) + (int) ($g['limited'] ?? 0),
                'disapproved' => $g['disapproved'] ?? 0, 'limited_country_coverage' => $g['limited'] ?? 0,
                'total' => $g['total'] ?? 0,
            ];
        }
        if (class_exists('PSC_DB')) {
            $open = [];
            foreach (PSC_DB::get_tasks(['status' => 'pending']) as $t) $open[] = '[' . $t['priority'] . '] ' . $t['title'];
            $ctx['open_tasks'] = array_slice($open, 0, 20);
        }
        return $ctx;
    }

    /* ---------- ask ---------- */

    public static function ask($question) {
        if (!class_exists('PSC_Connectors') || !PSC_Connectors::has_anthropic()) {
            return ['error' => 'no_key', 'message' => 'Add your Anthropic API key in Settings → Connectors to enable the brain.'];
        }
        $question = trim((string) $question);
        if ($question === '') $question = 'Give me a prioritized strategic read of the site right now: the single most important thing to do next and why, then the next few, each tied to the live numbers.';

        $ctx = self::context();
        $system = "You are the analytical brain of the PS SEO Console, embedded in the owner's WordPress plugin. You know this specific site deeply (see KNOWLEDGE BASE) and you reason over a LIVE DATA snapshot the plugin computed. Answer as a sharp, senior SEO/e-commerce strategist who knows this business. Be concise and mobile-friendly, lead with the highest-impact action, tie every claim to the live numbers, separate measured facts from things worth verifying, never invent figures, and end with one concrete next step. Plain text with short paragraphs or tight bullets — no fluff.\n\nKNOWLEDGE BASE:\n" . self::knowledge();
        $user = "LIVE DATA SNAPSHOT (JSON):\n" . wp_json_encode($ctx, JSON_PRETTY_PRINT) . "\n\nQUESTION:\n" . $question;

        $resp = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'timeout' => 90,
            'headers' => ['x-api-key' => PSC_Connectors::anthropic(), 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json'],
            'body'    => wp_json_encode(['model' => self::MODEL, 'max_tokens' => 1600, 'system' => $system, 'messages' => [['role' => 'user', 'content' => $user]]]),
        ]);
        if (is_wp_error($resp)) return ['error' => 'api', 'message' => $resp->get_error_message()];
        $rc = (int) wp_remote_retrieve_response_code($resp);
        $rb = json_decode(wp_remote_retrieve_body($resp), true);
        if ($rc >= 400) return ['error' => 'api', 'message' => $rb['error']['message'] ?? "Anthropic API HTTP {$rc}"];

        $text = '';
        foreach (($rb['content'] ?? []) as $blk) if (($blk['type'] ?? '') === 'text') $text .= $blk['text'];
        return ['answer' => trim($text), 'model' => self::MODEL, 'context_used' => array_keys($ctx)];
    }
}
