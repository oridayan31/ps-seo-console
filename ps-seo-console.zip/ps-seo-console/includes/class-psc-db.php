<?php
if (!defined('ABSPATH')) exit;

/**
 * Data layer: tasks table + CRUD + program metrics.
 * Tasks are the live board (replaces action-board.html + xlsx).
 */
class PSC_DB {

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . PSC_TASKS_TABLE;
    }

    public static function create_table() {
        global $wpdb;
        $table   = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title TEXT NOT NULL,
            priority VARCHAR(8) NOT NULL DEFAULT 'P3',
            status VARCHAR(16) NOT NULL DEFAULT 'pending',
            domain VARCHAR(16) NOT NULL DEFAULT 'art',
            target_url TEXT NULL,
            prompt LONGTEXT NULL,
            result TEXT NULL,
            source VARCHAR(32) NOT NULL DEFAULT 'manual',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            done_at DATETIME NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY priority (priority),
            KEY domain (domain)
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option('psc_db_version', PSC_VERSION);
    }

    public static function maybe_upgrade() {
        if (get_option('psc_db_version') !== PSC_VERSION) {
            self::create_table();
            if (class_exists('PSC_GSC'))      PSC_GSC::ensure_tables();
            if (class_exists('PSC_GA4'))      PSC_GA4::ensure_table();
            if (class_exists('PSC_Watchers')) PSC_Watchers::ensure_table();
        }
    }

    /* ---------------- CRUD ---------------- */

    public static function get_tasks($args = []) {
        global $wpdb;
        $table = self::table();
        $where = ['1=1'];
        $params = [];
        foreach (['status', 'priority', 'domain', 'source'] as $col) {
            if (!empty($args[$col])) {
                $where[] = "{$col} = %s";
                $params[] = sanitize_text_field($args[$col]);
            }
        }
        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where)
             . " ORDER BY FIELD(priority,'P1','P2','P3','YOU'), updated_at DESC";
        if ($params) {
            $sql = $wpdb->prepare($sql, $params);
        }
        $rows = $wpdb->get_results($sql, ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function get_task($id) {
        global $wpdb;
        $table = self::table();
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", (int) $id),
            ARRAY_A
        );
    }

    public static function create_task($data) {
        global $wpdb;
        $now = current_time('mysql');
        $row = [
            'title'      => self::clean_text($data['title'] ?? 'Untitled'),
            'priority'   => self::enum($data['priority'] ?? 'P3', ['P1', 'P2', 'P3', 'YOU'], 'P3'),
            'status'     => self::enum($data['status'] ?? 'pending', ['pending', 'proposed', 'done'], 'pending'),
            'domain'     => self::enum($data['domain'] ?? 'art', ['art', 'coil'], 'art'),
            'target_url' => isset($data['target_url']) ? esc_url_raw($data['target_url']) : null,
            'prompt'     => isset($data['prompt']) ? self::clean_multiline($data['prompt']) : null,
            'result'     => isset($data['result']) ? self::clean_text($data['result']) : null,
            'source'     => self::enum($data['source'] ?? 'manual', ['manual', 'audit', 'gsc', 'gmc', 'ga4'], 'manual'),
            'created_at' => $now,
            'updated_at' => $now,
            'done_at'    => (($data['status'] ?? '') === 'done') ? $now : null,
        ];
        $wpdb->insert(self::table(), $row);
        return $wpdb->insert_id ? self::get_task($wpdb->insert_id) : null;
    }

    public static function update_task($id, $data) {
        global $wpdb;
        $id = (int) $id;
        $existing = self::get_task($id);
        if (!$existing) return null;
        $upd = ['updated_at' => current_time('mysql')];
        if (isset($data['title']))      $upd['title']      = self::clean_text($data['title']);
        if (isset($data['priority']))   $upd['priority']   = self::enum($data['priority'], ['P1','P2','P3','YOU'], $existing['priority']);
        if (isset($data['domain']))     $upd['domain']     = self::enum($data['domain'], ['art','coil'], $existing['domain']);
        if (isset($data['target_url'])) $upd['target_url'] = esc_url_raw($data['target_url']);
        if (isset($data['prompt']))     $upd['prompt']     = self::clean_multiline($data['prompt']);
        if (isset($data['result']))     $upd['result']     = self::clean_text($data['result']);
        if (isset($data['source']))     $upd['source']     = self::enum($data['source'], ['manual','audit','gsc','gmc','ga4'], $existing['source']);
        if (isset($data['status'])) {
            $status = self::enum($data['status'], ['pending','proposed','done'], $existing['status']);
            $upd['status'] = $status;
            if ($status === 'done' && empty($existing['done_at'])) {
                $upd['done_at'] = current_time('mysql');
            } elseif ($status !== 'done') {
                $upd['done_at'] = null;
            }
        }
        $wpdb->update(self::table(), $upd, ['id' => $id]);
        return self::get_task($id);
    }

    public static function delete_task($id) {
        global $wpdb;
        return (bool) $wpdb->delete(self::table(), ['id' => (int) $id]);
    }

    /* ---------------- Metrics ---------------- */

    public static function progress() {
        global $wpdb;
        $table = self::table();
        $counts = ['pending' => 0, 'proposed' => 0, 'done' => 0];
        $rows = $wpdb->get_results("SELECT status, COUNT(*) c FROM {$table} GROUP BY status", ARRAY_A);
        foreach ((array) $rows as $r) {
            if (isset($counts[$r['status']])) $counts[$r['status']] = (int) $r['c'];
        }
        $total = array_sum($counts);
        $open_by_pri = ['P1' => 0, 'P2' => 0, 'P3' => 0, 'YOU' => 0];
        $prows = $wpdb->get_results(
            "SELECT priority, COUNT(*) c FROM {$table} WHERE status != 'done' GROUP BY priority",
            ARRAY_A
        );
        foreach ((array) $prows as $r) {
            if (isset($open_by_pri[$r['priority']])) $open_by_pri[$r['priority']] = (int) $r['c'];
        }
        return [
            'counts'      => $counts,
            'total'       => $total,
            'done'        => $counts['done'],
            'pct'         => $total ? (int) round($counts['done'] / $total * 100) : 0,
            'open_by_pri' => $open_by_pri,
        ];
    }

    /* ---------------- Sanitizers ---------------- */

    private static function clean_text($v) {
        return sanitize_text_field(is_scalar($v) ? (string) $v : '');
    }
    private static function clean_multiline($v) {
        return sanitize_textarea_field(is_scalar($v) ? (string) $v : '');
    }
    private static function enum($v, $allowed, $default) {
        $v = is_scalar($v) ? (string) $v : '';
        return in_array($v, $allowed, true) ? $v : $default;
    }

    /* ---------------- Seed ---------------- */

    public static function seed_if_empty() {
        global $wpdb;
        $table = self::table();
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        if ($count > 0) return;
        $seed = [
            ['title'=>'Rotate leaked credentials','priority'=>'P1','domain'=>'art','status'=>'pending','source'=>'manual',
             'prompt'=>"Rotate: Anthropic API key, Admin1 WP application password, SAI plugin key. Regenerate each, update stored refs, confirm old keys revoked."],
            ['title'=>'Fix B&W Line Art CTR — high impressions, 0 clicks','priority'=>'P1','domain'=>'art','status'=>'pending','source'=>'gsc',
             'target_url'=>home_url('/black-and-white-line-art/'),
             'prompt'=>"META-FIX candidate: position ~5, high impressions, 0 clicks. Rewrite meta title + description for click appeal, verify live, resubmit URL in GSC."],
            ['title'=>'Merchant Center setup (Track 2)','priority'=>'P2','domain'=>'art','status'=>'pending','source'=>'manual',
             'prompt'=>"Set up Google Merchant Center for printstudio.art: identifier_exists=false for custom artwork, careful shipping config, feed via Product Feed Manager."],
            ['title'=>'Art-finder FAB — Hebrew label update','priority'=>'P2','domain'=>'coil','status'=>'pending','source'=>'manual',
             'prompt'=>"Discover label = גלריה, WhatsApp stays on .co.il. Edit all three mobar PHP blocks incl. the variable-label variant. Match .art v2.9.14 consolidation."],
            ['title'=>'Bundle feature build (canvas)','priority'=>'P2','domain'=>'art','status'=>'proposed','source'=>'manual',
             'prompt'=>"Mix-and-match + curated fixed canvas sets. Needs PPCW v1.20.7 (mode A size-slug fix). Re-paste this card to approve build."],
            ['title'=>'Sitewide 20% discount — always-on?','priority'=>'YOU','domain'=>'art','status'=>'proposed','source'=>'manual',
             'prompt'=>"Unresolved from pricing session: is an always-on sitewide discount hurting margin/positioning? Decide keep / scheduled-only / drop."],
            ['title'=>'Product title cleanup — full catalog','priority'=>'P1','domain'=>'art','status'=>'done','source'=>'manual',
             'result'=>'684 products, 4 batches — CTR titles live & verified'],
            ['title'=>'Canvas repricing — 5 lines','priority'=>'P2','domain'=>'art','status'=>'done','source'=>'manual',
             'result'=>'708 products, 2,444 variation writes — ≥40% margin floor'],
            ['title'=>'Merchant listing schema deployed','priority'=>'P2','domain'=>'art','status'=>'done','source'=>'manual',
             'result'=>'v2.1 — one Offer at live from-price, 11/11 checks pass'],
        ];
        foreach ($seed as $s) {
            self::create_task($s);
        }
    }
}
