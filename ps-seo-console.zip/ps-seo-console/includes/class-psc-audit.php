<?php
if (!defined('ABSPATH')) exit;

/**
 * Local audit engine (Phase 1 — no Google required).
 * Produces "signal groups" from data already inside WordPress:
 * missing meta, product alt text, thin product content.
 * GSC / GMC groups are placeholders here and light up in Phase 2.
 * Results are cached (transient) and refreshed on the daily cron or "Scan now".
 */
class PSC_Audit {

    const CACHE_KEY = 'psc_audit_cache';
    const CAP = 200; // hard cap per scanner — keep it light

    public static function get_signals($force = false) {
        if (!$force) {
            $cached = get_transient(self::CACHE_KEY);
            if (is_array($cached)) return $cached;
        }
        return self::run_and_cache();
    }

    public static function run_and_cache() {
        $groups = [];
        $groups[] = self::scan_noindex();
        $groups[] = self::scan_technical();
        $groups[] = self::scan_missing_meta_desc();
        $groups[] = self::scan_product_alt_text();
        $groups[] = self::scan_thin_products();

        $connected = class_exists('PSC_Google') && PSC_Google::is_connected();

        // Merchant Center disapprovals
        if ($connected && class_exists('PSC_GMC') && PSC_GMC::get_id()) {
            $groups[] = self::scan_gmc();
        } else {
            $groups[] = self::placeholder('gmc_disapproved', 'Products disapproved in Merchant Center', 'gmc', 'hi',
                'Connect Merchant Center in Settings to surface disapprovals grouped by reason.');
        }

        // GSC CTR gaps
        if ($connected && class_exists('PSC_GSC')) {
            $groups[] = self::scan_gsc_ctr();
            $groups[] = self::scan_gsc_striking();
        } else {
            $groups[] = self::placeholder('gsc_ctr', 'High impressions, low CTR — META-FIX', 'gsc', 'hi',
                'Connect Search Console in Settings to find page-1 pages nobody clicks.');
            $groups[] = self::placeholder('gsc_striking', 'Striking distance — position 5–15', 'gsc', 'med',
                'Connect Search Console in Settings to find pages one push from page 1.');
        }

        $payload = [
            'generated_at' => current_time('mysql'),
            'groups'       => $groups,
            'summary'      => self::summarize($groups),
            'health'       => self::health_score($groups),
        ];
        set_transient(self::CACHE_KEY, $payload, DAY_IN_SECONDS);
        return $payload;
    }

    /* ---------------- Scanners ---------------- */

    private static function scan_missing_meta_desc() {
        global $wpdb;
        $types = self::post_types_in(['page', 'post', 'product']);
        if (empty($types)) return self::group('missing_meta_desc', 'Missing or short meta description', 'site', 'med', 'Read straight from Yoast — no Google needed.', [], true);
        $ph = implode(',', array_fill(0, count($types), '%s'));
        $sql = $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type
               FROM {$wpdb->posts} p
               LEFT JOIN {$wpdb->postmeta} m
                 ON m.post_id = p.ID AND m.meta_key = '_yoast_wpseo_metadesc'
              WHERE p.post_status = 'publish'
                AND p.post_type IN ($ph)
                AND (m.meta_value IS NULL OR CHAR_LENGTH(TRIM(m.meta_value)) < 50)
              ORDER BY p.post_type, p.post_title
              LIMIT %d",
            array_merge($types, [self::CAP])
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        $items = [];
        foreach ((array) $rows as $r) {
            $items[] = [
                'label' => $r['post_title'] !== '' ? $r['post_title'] : '(no title)',
                'url'   => get_permalink((int) $r['ID']),
                'meta'  => $r['post_type'],
            ];
        }
        return self::group('missing_meta_desc', 'Missing or short meta description', 'site', 'med',
            'Pages, posts and products with a Yoast meta description under 50 characters (or none).', $items, true);
    }

    private static function scan_product_alt_text() {
        if (!function_exists('wc_get_products')) {
            return self::group('product_alt_text', 'Product images missing alt text', 'site', 'lo',
                'WooCommerce not detected.', [], true);
        }
        global $wpdb;
        // Featured images (thumbnails) whose _wp_attachment_image_alt is empty, for published products.
        $sql = $wpdb->prepare(
            "SELECT p.ID, p.post_title, tm.meta_value AS thumb_id
               FROM {$wpdb->posts} p
               JOIN {$wpdb->postmeta} tm ON tm.post_id = p.ID AND tm.meta_key = '_thumbnail_id'
               LEFT JOIN {$wpdb->postmeta} am ON am.post_id = tm.meta_value AND am.meta_key = '_wp_attachment_image_alt'
              WHERE p.post_status = 'publish' AND p.post_type = 'product'
                AND (am.meta_value IS NULL OR TRIM(am.meta_value) = '')
              ORDER BY p.post_title
              LIMIT %d",
            self::CAP
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        $items = [];
        foreach ((array) $rows as $r) {
            $items[] = [
                'label' => $r['post_title'] !== '' ? $r['post_title'] : '(no title)',
                'url'   => get_permalink((int) $r['ID']),
                'meta'  => 'no alt',
            ];
        }
        return self::group('product_alt_text', 'Product images missing alt text', 'site', 'lo',
            'Featured images with an empty alt attribute. Bulk-fixable from product titles + subjects.', $items, true);
    }

    private static function scan_thin_products() {
        if (!function_exists('wc_get_products')) {
            return self::group('thin_products', 'Thin product descriptions', 'site', 'lo', 'WooCommerce not detected.', [], true);
        }
        global $wpdb;
        // Products whose long description (post_content) is under ~120 chars of visible text.
        $sql = $wpdb->prepare(
            "SELECT ID, post_title, post_content
               FROM {$wpdb->posts}
              WHERE post_status='publish' AND post_type='product'
              ORDER BY post_title
              LIMIT %d",
            500
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        $items = [];
        foreach ((array) $rows as $r) {
            $text = trim(wp_strip_all_tags((string) $r['post_content']));
            if (mb_strlen($text) < 120) {
                $items[] = [
                    'label' => $r['post_title'] !== '' ? $r['post_title'] : '(no title)',
                    'url'   => get_permalink((int) $r['ID']),
                    'meta'  => mb_strlen($text) . ' chars',
                ];
            }
            if (count($items) >= self::CAP) break;
        }
        return self::group('thin_products', 'Thin product descriptions', 'site', 'lo',
            'Products with under 120 characters of description text.', $items, true);
    }

    private static function scan_noindex() {
        global $wpdb;
        $types = self::post_types_in(['page', 'post', 'product']);
        if (empty($types)) return self::group('noindex', 'Published pages set to noindex', 'site', 'hi', 'Yoast not detected.', [], true);
        $ph = implode(',', array_fill(0, count($types), '%s'));
        $sql = $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type
               FROM {$wpdb->posts} p
               JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_yoast_wpseo_meta-robots-noindex'
              WHERE p.post_status = 'publish' AND p.post_type IN ($ph) AND m.meta_value = '1'
              ORDER BY p.post_type, p.post_title LIMIT %d",
            array_merge($types, [self::CAP])
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        $items = [];
        foreach ((array) $rows as $r) {
            $items[] = ['label' => $r['post_title'] !== '' ? $r['post_title'] : '(no title)', 'url' => get_permalink((int) $r['ID']), 'meta' => 'noindex · ' . $r['post_type']];
        }
        return self::group('noindex', 'Published pages set to noindex', 'site', 'hi',
            'Live but told not to index — invisible in search. Confirm each is intentional (thank-you pages fine; collections/products are not).', $items, true);
    }

    private static function scan_technical() {
        $items = []; $sev = 'lo';
        if (strpos(home_url(), 'https://') !== 0) {
            $items[] = ['label' => 'Site is not served over HTTPS', 'url' => home_url('/'), 'meta' => 'https']; $sev = 'hi';
        }
        $rt = wp_remote_get(home_url('/robots.txt'), ['timeout' => 10]);
        if (!is_wp_error($rt)) {
            $body = (string) wp_remote_retrieve_body($rt);
            if (preg_match('/^\s*Disallow:\s*\/\s*$/mi', $body)) {
                $items[] = ['label' => 'robots.txt disallows the entire site (Disallow: /)', 'url' => home_url('/robots.txt'), 'meta' => 'blocking']; $sev = 'hi';
            }
        } else {
            $items[] = ['label' => 'robots.txt not reachable', 'url' => home_url('/robots.txt'), 'meta' => 'missing'];
            if ($sev !== 'hi') $sev = 'med';
        }
        $sm = wp_remote_head(home_url('/sitemap_index.xml'), ['timeout' => 10]);
        $code = is_wp_error($sm) ? 0 : (int) wp_remote_retrieve_response_code($sm);
        if ($code !== 200) {
            $items[] = ['label' => 'XML sitemap not found at /sitemap_index.xml', 'url' => home_url('/sitemap_index.xml'), 'meta' => 'HTTP ' . $code];
            if ($sev !== 'hi') $sev = 'med';
        }
        return self::group('technical', 'Technical / indexability', 'site', $sev,
            'Site-level crawl + index checks: HTTPS, robots.txt, and the XML sitemap.', $items, true);
    }

    private static function scan_gmc() {
        $s = PSC_GMC::get_status();
        $items = [];
        foreach (($s['reasons'] ?? []) as $code => $n) {
            $items[] = ['label' => $n . ' products — ' . str_replace('_', ' ', $code), 'url' => '', 'meta' => (string) $code];
        }
        return [
            'key' => 'gmc_disapproved', 'name' => 'Products disapproved in Merchant Center',
            'source' => 'gmc', 'severity' => 'hi',
            'desc' => 'Grouped by reason. Fixing feed data restores free-listing + Shopping eligibility.',
            'count' => (int) ($s['disapproved'] ?? 0), 'items' => array_slice($items, 0, 6),
            'total' => (int) ($s['disapproved'] ?? 0), 'live' => true,
        ];
    }

    private static function scan_gsc_ctr() {
        $rows = PSC_GSC::ctr_gap_pages(20);
        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'label' => str_replace(home_url(), '', $r['page']),
                'url'   => $r['page'],
                'meta'  => number_format((int) $r['impr']) . ' impr · 0% CTR · pos ' . round((float) $r['pos'], 1),
            ];
        }
        return self::group('gsc_ctr', 'High impressions, low CTR — META-FIX', 'gsc', 'hi',
            'Ranking on page 1 but nobody clicks. Rewriting the meta title/description is the fastest win.', $items, true);
    }

    private static function scan_gsc_striking() {
        $rows = PSC_GSC::striking_distance(50);
        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'label' => str_replace(home_url(), '', $r['page']),
                'url'   => $r['page'],
                'meta'  => 'pos ' . round((float) $r['pos'], 1) . ' · ' . number_format((int) $r['impr']) . ' impr',
            ];
        }
        return self::group('gsc_striking', 'Striking distance — position 5–15', 'gsc', 'med',
            'One push (internal links + content) moves these onto page 1.', $items, true);
    }

    /* ---------------- Helpers ---------------- */

    private static function post_types_in($wanted) {
        $out = [];
        foreach ($wanted as $t) {
            if (post_type_exists($t)) $out[] = $t;
        }
        return $out;
    }

    private static function group($key, $name, $source, $severity, $desc, $items, $live) {
        return [
            'key'      => $key,
            'name'     => $name,
            'source'   => $source,      // site | gsc | gmc | ga4
            'severity' => $severity,    // hi | med | lo
            'desc'     => $desc,
            'count'    => count($items),
            'items'    => array_slice($items, 0, 6),
            'total'    => count($items),
            'live'     => (bool) $live,
        ];
    }

    private static function placeholder($key, $name, $source, $severity, $desc) {
        return [
            'key' => $key, 'name' => $name, 'source' => $source, 'severity' => $severity,
            'desc' => $desc, 'count' => 0, 'items' => [], 'total' => 0, 'live' => false,
        ];
    }

    private static function summarize($groups) {
        $opps = 0; $high = 0;
        foreach ($groups as $g) {
            if (!$g['live']) continue;
            $opps += (int) $g['count'];
            if ($g['severity'] === 'hi' && $g['count'] > 0) $high += (int) $g['count'];
        }
        return ['opportunities' => $opps, 'high' => $high];
    }

    /**
     * Phase-1 health score (0–100). Transparent penalties from local coverage + open P1s.
     * Sharpens once GSC/GMC data lands in Phase 2.
     */
    public static function health_score($groups = null) {
        if ($groups === null) {
            $cached = get_transient(self::CACHE_KEY);
            $groups = is_array($cached) && isset($cached['groups']) ? $cached['groups'] : [];
        }
        $score = 100.0;

        // meta description coverage
        $missing_meta = self::group_count($groups, 'missing_meta_desc');
        $total_content = max(1, self::published_count(['page', 'post', 'product']));
        $score -= min(30, ($missing_meta / $total_content) * 30);

        // alt text coverage
        $missing_alt = self::group_count($groups, 'product_alt_text');
        $total_products = max(1, self::published_count(['product']));
        $score -= min(15, ($missing_alt / $total_products) * 15);

        // open P1s
        $prog = PSC_DB::progress();
        $score -= min(24, ($prog['open_by_pri']['P1'] ?? 0) * 6);

        // indexability penalties (noindexed live pages + site-level technical blockers)
        $noindex = self::group_count($groups, 'noindex');
        $score -= min(20, $noindex * 4);
        foreach ((array) $groups as $g) {
            if (($g['key'] ?? '') === 'technical' && ($g['severity'] ?? '') === 'hi' && (int) ($g['count'] ?? 0) > 0) {
                $score -= 10;
            }
        }

        return max(0, (int) round($score));
    }

    private static function group_count($groups, $key) {
        foreach ((array) $groups as $g) {
            if (($g['key'] ?? '') === $key) return (int) ($g['count'] ?? 0);
        }
        return 0;
    }

    private static function published_count($types) {
        global $wpdb;
        $types = self::post_types_in($types);
        if (empty($types)) return 0;
        $ph = implode(',', array_fill(0, count($types), '%s'));
        $sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($ph)",
            $types
        );
        return (int) $wpdb->get_var($sql);
    }
}
