<?php
if (!defined('ABSPATH')) exit;

/**
 * AI-engine traffic tracker (GA4 Data API).
 * Reproduces the manual GA4 method — "session source contains chatgpt → pages & screens" —
 * programmatically, for every major AI engine, and snapshots daily via cron for trends.
 */
class PSC_AITraffic {

    const CACHE = 'psc_ai_traffic';
    const OPT_DAILY = 'psc_ai_daily';

    /** Engine label => sessionSource substrings (case-insensitive CONTAINS). */
    public static function engines() {
        return [
            'ChatGPT'    => ['chatgpt', 'openai', 'searchgpt', 'oai.com'],
            'Perplexity' => ['perplexity', 'pplx'],
            'Gemini'     => ['gemini', 'bard.google', 'aistudio.google'],
            'Copilot'    => ['copilot', 'bingchat', 'bing.com/chat'],
            'Claude'     => ['claude', 'anthropic'],
            'DeepSeek'   => ['deepseek'],
            'Grok'       => ['grok', 'x.ai'],
            'Meta AI'    => ['meta.ai'],
            'Other AI'   => ['you.com', 'poe.com', 'phind', 'mistral', 'kagi', 'kimi', 'qwen', 'chatglm', 'doubao', 'huggingface', 'felo', 'liner.com', 'iask', 'komo.ai', 'andisearch'],
        ];
    }

    private static function all_patterns() {
        $p = [];
        foreach (self::engines() as $pats) $p = array_merge($p, $pats);
        return $p;
    }

    private static function classify($source) {
        $s = strtolower((string) $source);
        foreach (self::engines() as $label => $pats) {
            foreach ($pats as $pat) if (strpos($s, $pat) !== false) return $label;
        }
        return 'Other AI';
    }

    /** GA4 dimensionFilter: sessionSource CONTAINS any AI pattern. */
    private static function ai_filter() {
        $ex = [];
        foreach (self::all_patterns() as $pat) {
            $ex[] = ['filter' => ['fieldName' => 'sessionSource',
                'stringFilter' => ['matchType' => 'CONTAINS', 'value' => $pat, 'caseSensitive' => false]]];
        }
        return ['orGroup' => ['expressions' => $ex]];
    }

    private static function run($payload) {
        if (!PSC_Google::is_connected()) return new WP_Error('not_connected', 'Google not connected');
        $prop = PSC_GA4::get_property();
        if (!$prop) return new WP_Error('no_property', 'No GA4 property selected');
        return PSC_Google::post('https://analyticsdata.googleapis.com/v1beta/' . $prop . ':runReport', $payload);
    }

    private static function engine_rows($start, $end) {
        $r = self::run([
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionSource']],
            'metrics'    => [['name' => 'sessions'], ['name' => 'totalUsers'], ['name' => 'screenPageViews'],
                             ['name' => 'ecommercePurchases'], ['name' => 'purchaseRevenue']],
            'dimensionFilter' => self::ai_filter(),
            'limit' => 200,
        ]);
        if (is_wp_error($r)) return $r;
        $out = [];
        foreach (($r['rows'] ?? []) as $row) {
            $src = $row['dimensionValues'][0]['value'] ?? '';
            $eng = self::classify($src);
            $m = $row['metricValues'];
            if (!isset($out[$eng])) $out[$eng] = ['engine' => $eng, 'sessions' => 0, 'users' => 0, 'views' => 0, 'purchases' => 0, 'revenue' => 0.0, 'sources' => []];
            $out[$eng]['sessions'] += (int) ($m[0]['value'] ?? 0);
            $out[$eng]['users']    += (int) ($m[1]['value'] ?? 0);
            $out[$eng]['views']    += (int) ($m[2]['value'] ?? 0);
            $out[$eng]['purchases']+= (int) ($m[3]['value'] ?? 0);
            $out[$eng]['revenue']  += (float) ($m[4]['value'] ?? 0);
            $out[$eng]['sources'][] = $src;
        }
        return $out;
    }

    public static function report($force = false) {
        if (!$force) { $c = get_transient(self::CACHE); if (is_array($c)) return $c; }
        $cur = self::engine_rows(gmdate('Y-m-d', strtotime('-28 day')), 'today');
        if (is_wp_error($cur)) return ['status' => 'error', 'message' => $cur->get_error_message()];
        $prev = self::engine_rows(gmdate('Y-m-d', strtotime('-56 day')), gmdate('Y-m-d', strtotime('-29 day')));
        if (is_wp_error($prev)) $prev = [];

        $engines = [];
        $tot = ['sessions' => 0, 'users' => 0, 'views' => 0, 'purchases' => 0, 'revenue' => 0.0];
        $tot_prev = 0;
        foreach ($cur as $eng => $row) {
            $p = $prev[$eng]['sessions'] ?? 0;
            $row['prev_sessions'] = (int) $p;
            $row['delta'] = (int) $row['sessions'] - (int) $p;
            $row['sources'] = array_values(array_unique($row['sources']));
            $engines[] = $row;
            foreach (['sessions', 'users', 'views', 'purchases'] as $k) $tot[$k] += $row[$k];
            $tot['revenue'] += $row['revenue'];
            $tot_prev += (int) $p;
        }
        foreach ($prev as $eng => $row) { // engines that vanished this period
            if (!isset($cur[$eng])) $tot_prev += (int) $row['sessions'];
        }
        usort($engines, function ($a, $b) { return $b['sessions'] <=> $a['sessions']; });

        // pages cited by AI engines (your GA4 method, automated)
        $pg = self::run([
            'dateRanges' => [['startDate' => gmdate('Y-m-d', strtotime('-28 day')), 'endDate' => 'today']],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'sessionSource']],
            'metrics'    => [['name' => 'screenPageViews'], ['name' => 'sessions']],
            'dimensionFilter' => self::ai_filter(),
            'limit' => 250,
        ]);
        $pages = [];
        if (!is_wp_error($pg)) {
            $slugmap = class_exists('PSC_Crawl') ? PSC_Crawl::slugmap() : [];
            foreach (($pg['rows'] ?? []) as $row) {
                $path = $row['dimensionValues'][0]['value'] ?? '';
                $eng = self::classify($row['dimensionValues'][1]['value'] ?? '');
                if (!isset($pages[$path])) {
                    $pages[$path] = ['path' => $path, 'views' => 0, 'sessions' => 0, 'engines' => [],
                        'template' => class_exists('PSC_Crawl') ? PSC_Crawl::template_of(home_url($path), $slugmap) : ''];
                }
                $pages[$path]['views']    += (int) ($row['metricValues'][0]['value'] ?? 0);
                $pages[$path]['sessions'] += (int) ($row['metricValues'][1]['value'] ?? 0);
                if (!in_array($eng, $pages[$path]['engines'], true)) $pages[$path]['engines'][] = $eng;
            }
            $pages = array_values($pages);
            usort($pages, function ($a, $b) { return $b['views'] <=> $a['views']; });
        }

        // computed analysis
        $insights = [];
        $delta_pct = $tot_prev > 0 ? round(($tot['sessions'] - $tot_prev) / $tot_prev * 100) : null;
        $insights[] = 'AI engines sent ' . $tot['sessions'] . ' sessions in 28 days'
            . ($delta_pct !== null ? ' (' . ($delta_pct >= 0 ? '+' : '') . $delta_pct . '% vs previous 28)' : ' (no prior-period baseline yet)') . '.';
        if ($engines) $insights[] = $engines[0]['engine'] . ' leads with ' . $engines[0]['sessions'] . ' sessions.';
        if ($tot['purchases'] > 0) $insights[] = 'AI traffic converted: ' . $tot['purchases'] . ' purchase(s), $' . number_format($tot['revenue'], 2) . ' revenue.';
        if ($pages) {
            $tplc = [];
            foreach ($pages as $p) { $t = $p['template'] ?: 'Other'; $tplc[$t] = ($tplc[$t] ?? 0) + $p['views']; }
            arsort($tplc);
            $topt = array_key_first($tplc);
            $share = round($tplc[$topt] / max(1, array_sum($tplc)) * 100);
            $insights[] = 'AI engines mostly cite your ' . strtolower($topt) . ' pages (' . $share . '% of AI views) — the pages they can quote. Keep those answer-first and factual (materials, sizes, shipping) to earn more citations.';
            $insights[] = 'Most-cited: ' . $pages[0]['path'] . ' (' . $pages[0]['views'] . ' AI views via ' . implode(', ', $pages[0]['engines']) . ').';
        } else {
            $insights[] = 'No page-level AI visits recorded yet — as volume grows, the cited pages appear here automatically.';
        }

        $out = ['status' => 'ok', 'generated' => current_time('mysql'), 'days' => 28,
                'totals' => $tot + ['prev_sessions' => $tot_prev, 'delta_pct' => $delta_pct],
                'engines' => $engines, 'pages' => array_slice($pages, 0, 40),
                'insights' => $insights, 'daily' => self::daily()];
        set_transient(self::CACHE, $out, 6 * HOUR_IN_SECONDS);
        return $out;
    }

    /** Daily cron: store yesterday's per-engine sessions for the trend. */
    public static function snapshot() {
        $y = gmdate('Y-m-d', strtotime('-1 day'));
        $rows = self::engine_rows($y, $y);
        if (is_wp_error($rows)) return;
        $daily = self::daily();
        $day = [];
        foreach ($rows as $eng => $r) $day[$eng] = (int) $r['sessions'];
        $daily[$y] = $day;
        ksort($daily);
        update_option(self::OPT_DAILY, array_slice($daily, -90, null, true), false);
    }

    public static function daily() { $d = get_option(self::OPT_DAILY, []); return is_array($d) ? $d : []; }
}
