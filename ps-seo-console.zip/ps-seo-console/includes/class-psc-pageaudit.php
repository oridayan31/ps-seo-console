<?php
if (!defined('ABSPATH')) exit;

/**
 * Per-URL SEO + AEO auditor. PHP port of the seo-aeo-auditor skill:
 * fetches a page (+ its robots.txt), runs every check verifiable from HTML/headers,
 * scores with the P0-P3 weighted model, and lists the manual-review items the
 * score deliberately does NOT claim. One P0 failure is the headline regardless of %.
 */
class PSC_PageAudit {

    const WEIGHTS = ['P0' => 5, 'P1' => 4, 'P2' => 2, 'P3' => 1];
    const UA = 'Mozilla/5.0 (compatible; PS-SEO-Console-Auditor/1.0) Safari/537.36';
    const AI_BOTS = ['Googlebot', 'OAI-SearchBot', 'GPTBot', 'ChatGPT-User', 'PerplexityBot', 'ClaudeBot', 'Bingbot'];
    const GENERIC_ANCHORS = ['click here','here','read more','learn more','more','this','link','click','read','details','info'];

    public static function audit($url) {
        $url = esc_url_raw($url);
        $checks = [];
        $meta = [];
        $manual = self::manual_items();

        list($resp, $chain, $final, $err) = self::fetch_chain($url);
        if (!$resp) {
            $checks[] = self::chk('fetch', 'P0', 'Crawling', 'FAIL', 'Could not fetch the URL: ' . $err, 'Confirm the server is up and the URL is correct.');
            return self::finalize($url, $url, $checks, $manual, $meta);
        }
        $code = (int) wp_remote_retrieve_response_code($resp);
        $html = (string) wp_remote_retrieve_body($resp);
        $parsed = wp_parse_url($final);
        $path = isset($parsed['path']) ? $parsed['path'] : '/';
        $scheme = isset($parsed['scheme']) ? $parsed['scheme'] : 'http';
        $host = isset($parsed['host']) ? $parsed['host'] : '';
        $base = $scheme . '://' . $host;

        // ---- Crawling & indexation (P0) ----
        $checks[] = ($code === 200)
            ? self::chk('http200', 'P0', 'Crawling', 'PASS', "Final response is 200 OK.")
            : self::chk('http200', 'P0', 'Crawling', 'FAIL', "Final response is {$code}.", 'Important pages must return 200.');

        $hops = count($chain);
        if ($hops === 0)      $checks[] = self::chk('redirects', 'P0', 'Crawling', 'PASS', 'No redirects before the final URL.');
        elseif ($hops === 1)  $checks[] = self::chk('redirects', 'P1', 'Crawling', 'WARN', '1 redirect before final.', 'One hop is fine; point internal links at the final URL.');
        else                  $checks[] = self::chk('redirects', 'P0', 'Crawling', 'FAIL', "Redirect chain of {$hops} hops.", 'Collapse to a single 301 and update internal links to the destination.');

        $checks[] = ($scheme === 'https')
            ? self::chk('https', 'P0', 'Crawling', 'PASS', 'Served over HTTPS.')
            : self::chk('https', 'P0', 'Crawling', 'FAIL', 'Final URL is not HTTPS.', 'Force HTTP→HTTPS and canonicalize to the https host.');

        // Parse HTML
        $dom = self::dom($html);
        $xp = $dom ? new DOMXPath($dom) : null;

        // noindex: meta robots + X-Robots-Tag
        $mr = $xp ? self::attr($xp, "//meta[translate(@name,'ROBOTS','robots')='robots']", 'content') : '';
        $xrobots = strtolower((string) wp_remote_retrieve_header($resp, 'x-robots-tag'));
        $reasons = [];
        if (strpos(strtolower($mr), 'noindex') !== false) $reasons[] = 'meta robots';
        if (strpos($xrobots, 'noindex') !== false) $reasons[] = 'X-Robots-Tag header';
        $checks[] = $reasons
            ? self::chk('noindex', 'P0', 'Crawling', 'FAIL', 'Page carries noindex via ' . implode(', ', $reasons) . '.', 'If this page should rank, remove the noindex.')
            : self::chk('noindex', 'P0', 'Crawling', 'PASS', 'No accidental noindex detected.');

        // canonical
        $canon = $xp ? self::attr($xp, "//link[translate(@rel,'CANONICAL','canonical')='canonical']", 'href') : '';
        if (!$canon) {
            $checks[] = self::chk('canonical', 'P0', 'Crawling', 'WARN', 'No canonical link element found.', 'Add a self-referencing canonical to the preferred URL.');
        } else {
            $canon_abs = self::abs($canon, $final);
            $same = rtrim(self::strip_frag($canon_abs), '/') === rtrim(self::strip_frag($final), '/');
            $checks[] = $same
                ? self::chk('canonical', 'P0', 'Crawling', 'PASS', 'Self-referencing canonical matches the final URL.')
                : self::chk('canonical', 'P0', 'Crawling', 'WARN', 'Canonical points elsewhere: ' . $canon_abs, 'Confirm intentional; otherwise self-canonicalize.');
        }
        $meta['canonical'] = $canon;

        // robots.txt + sitemap + AI bots
        $robots = self::parse_robots($base);
        if ($robots['reachable']) {
            $checks[] = self::chk('robots_reachable', 'P0', 'Crawling', 'PASS', 'robots.txt reachable (200).');
            $checks[] = self::path_blocked($robots, 'Googlebot', $path)
                ? self::chk('robots_block', 'P0', 'Crawling', 'FAIL', "robots.txt disallows this path for Googlebot ({$path}).", 'Unblock the path if it should be indexed.')
                : self::chk('robots_block', 'P0', 'Crawling', 'PASS', 'Path is not disallowed for Googlebot.');
            $checks[] = $robots['sitemaps']
                ? self::chk('sitemap_ref', 'P1', 'Crawling', 'PASS', count($robots['sitemaps']) . ' sitemap(s) referenced in robots.txt.')
                : self::chk('sitemap_ref', 'P1', 'Crawling', 'WARN', 'No Sitemap: directive in robots.txt.', 'Reference the XML sitemap from robots.txt.');
            $oai_blocked = self::path_blocked($robots, 'OAI-SearchBot', $path);
            $checks[] = $oai_blocked
                ? self::chk('oai_searchbot', 'P1', 'AEO', 'WARN', "OAI-SearchBot is disallowed — can't surface in ChatGPT Search.", 'Allow OAI-SearchBot (separate from GPTBot).')
                : self::chk('oai_searchbot', 'P1', 'AEO', 'PASS', 'OAI-SearchBot is not blocked.');
            $ai = [];
            foreach (self::AI_BOTS as $b) $ai[$b] = self::path_blocked($robots, $b, $path) ? 'blocked' : 'allowed';
            $meta['ai_bots'] = $ai;
        } else {
            $checks[] = self::chk('robots_reachable', 'P1', 'Crawling', 'WARN', 'robots.txt not returning 200.', 'A missing robots.txt is fine, but a 5xx can stall crawling.');
        }

        // ---- On-page ----
        $title = $xp ? trim(self::node_text($xp, '//title')) : '';
        $meta['title'] = $title;
        if ($title === '') {
            $checks[] = self::chk('title', 'P1', 'On-page', 'FAIL', 'No <title> / empty title.', 'Add a unique, benefit-led title.');
        } else {
            $n = mb_strlen($title);
            $checks[] = ($n >= 15 && $n <= 65)
                ? self::chk('title', 'P1', 'On-page', 'PASS', "Title present ({$n} chars).")
                : self::chk('title', 'P1', 'On-page', 'WARN', "Title is {$n} chars (target ~50-60).", 'Tighten/expand so the differentiator survives truncation.');
        }

        $desc = $xp ? self::attr($xp, "//meta[translate(@name,'DESCRIPTION','description')='description']", 'content') : '';
        $meta['meta_description'] = $desc;
        if ($desc === '') {
            $checks[] = self::chk('meta_desc', 'P1', 'On-page', 'WARN', 'No meta description.', 'Add a unique summary with a reason to click.');
        } else {
            $n = mb_strlen($desc);
            $ok = ($n >= 70 && $n <= 165);
            $checks[] = self::chk('meta_desc', 'P1', 'On-page', $ok ? 'PASS' : 'WARN', "Meta description present ({$n} chars; target ~140-160).", $ok ? '' : 'Rewrite toward a single clear, clickable summary.');
        }

        $h1s = $xp ? $xp->query('//h1') : null;
        $h1n = $h1s ? $h1s->length : 0;
        if ($h1n === 1)      $checks[] = self::chk('h1', 'P1', 'On-page', 'PASS', 'Exactly one H1.');
        elseif ($h1n === 0)  $checks[] = self::chk('h1', 'P1', 'On-page', 'FAIL', 'No H1 on the page.', 'Add one clear H1 for the main topic.');
        else                 $checks[] = self::chk('h1', 'P1', 'On-page', 'WARN', "{$h1n} H1 elements found.", 'Prefer a single H1; demote the rest to H2.');

        // heading order
        if ($xp) {
            $hs = [];
            foreach ($xp->query('//*[self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6]') as $h) {
                $hs[] = ['level' => (int) substr($h->nodeName, 1), 'text' => self::trunc($h->textContent)];
            }
            if ($hs) {
                $skip_at = -1;
                for ($i = 1; $i < count($hs); $i++) { if ($hs[$i]['level'] - $hs[$i-1]['level'] > 1) { $skip_at = $i; break; } }
                if ($skip_at >= 0) {
                    $a = $hs[$skip_at - 1]; $b = $hs[$skip_at];
                    $checks[] = self::chk('heading_order', 'P2', 'On-page', 'WARN',
                        "Heading hierarchy skips levels (H{$a['level']}→H{$b['level']}).", 'Keep headings sequential.',
                        ['skip'    => "H{$a['level']} \"{$a['text']}\"  →  H{$b['level']} \"{$b['text']}\"",
                         'outline' => array_map(function ($x) { return "H{$x['level']} · {$x['text']}"; }, array_slice($hs, 0, 40))]);
                } else {
                    $checks[] = self::chk('heading_order', 'P2', 'On-page', 'PASS', 'Heading hierarchy is sequential.');
                }
            }
        }

        // viewport + lang
        $viewport = $xp ? $xp->query("//meta[translate(@name,'VIEWPORT','viewport')='viewport']") : null;
        $checks[] = ($viewport && $viewport->length)
            ? self::chk('viewport', 'P1', 'Mobile', 'PASS', 'Responsive viewport meta present.')
            : self::chk('viewport', 'P1', 'Mobile', 'FAIL', 'No viewport meta tag.', "Add <meta name=viewport content='width=device-width, initial-scale=1'>.");
        $lang = $xp ? self::attr($xp, '//html', 'lang') : '';
        $checks[] = $lang
            ? self::chk('lang', 'P2', 'Mobile', 'PASS', "html lang set to '{$lang}'.")
            : self::chk('lang', 'P2', 'Mobile', 'WARN', 'No lang attribute on <html>.', 'Set the document language.');

        // word count
        $words = self::word_count($html);
        $meta['word_count'] = $words;
        $checks[] = ($words >= 250)
            ? self::chk('content_len', 'P2', 'Content', 'PASS', "~{$words} words of server-rendered text.")
            : self::chk('content_len', 'P2', 'Content', 'WARN', "Only ~{$words} words in server HTML.", 'Confirm text is in rendered HTML, not JS-injected.');

        // JSON-LD schema
        list($types, $ld_errors) = $xp ? self::schema($xp) : [[], 0];
        $meta['schema_types'] = $types;
        if ($ld_errors) {
            $checks[] = self::chk('schema_valid', 'P1', 'Schema', 'FAIL', "{$ld_errors} JSON-LD block(s) failed to parse.", 'Fix malformed JSON-LD; invalid blocks are ignored.');
        } elseif ($types) {
            $checks[] = self::chk('schema_present', 'P1', 'Schema', 'PASS', 'JSON-LD found: ' . implode(', ', $types) . '.');
        } else {
            $checks[] = self::chk('schema_present', 'P1', 'Schema', 'WARN', 'No JSON-LD structured data found.', 'Add accurate Product/Article/BreadcrumbList markup that matches visible content.');
        }

        // images / alt
        if ($xp) {
            $imgs = $xp->query('//img');
            $total = $imgs ? $imgs->length : 0;
            $missing = 0;
            foreach ($imgs as $img) { if (!$img->hasAttribute('alt')) $missing++; }
            if ($total) {
                $pct = (int) round(100 * ($total - $missing) / $total);
                $checks[] = self::chk('img_alt', 'P2', 'Images', $pct >= 90 ? 'PASS' : 'WARN', "{$total} images; {$pct}% have alt ({$missing} missing).", $pct >= 90 ? '' : "Add descriptive alt; empty alt='' for decorative.");
            }
        }

        // internal links + generic anchors
        if ($xp) {
            $internal = 0; $generic = 0; $generic_list = [];
            foreach ($xp->query('//a[@href]') as $a) {
                $href = trim($a->getAttribute('href'));
                if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'tel:') === 0) continue;
                $t = wp_parse_url(self::abs($href, $final));
                if (isset($t['host']) && $t['host'] === $host) {
                    $internal++;
                    $text = trim(preg_replace('/\s+/', ' ', $a->textContent));
                    if (in_array(strtolower($text), self::GENERIC_ANCHORS, true)) {
                        $generic++;
                        $generic_list[] = ['text' => $text !== '' ? $text : '(no text)', 'href' => self::abs($href, $final)];
                    }
                }
            }
            $meta['internal_links'] = $internal;
            $checks[] = ($internal >= 3)
                ? self::chk('internal_links', 'P1', 'Linking', 'PASS', "{$internal} internal links.")
                : self::chk('internal_links', 'P1', 'Linking', 'WARN', "Only {$internal} internal links found.", 'Aim for ~3-5 contextual internal links beyond nav.');
            if ($generic) {
                $checks[] = self::chk('generic_anchors', 'P2', 'Linking', 'WARN', "{$generic} internal links use generic anchor text.", 'Use descriptive anchors naming the destination.',
                    ['links' => array_slice($generic_list, 0, 20)]);
            }
        }

        // Open Graph
        if ($xp) {
            $ogt = self::attr($xp, "//meta[@property='og:title']", 'content');
            $ogi = self::attr($xp, "//meta[@property='og:image']", 'content');
            $checks[] = ($ogt && $ogi)
                ? self::chk('open_graph', 'P3', 'Social', 'PASS', 'Open Graph title + image present.')
                : self::chk('open_graph', 'P3', 'Social', 'WARN', 'Incomplete Open Graph tags.', 'Add og:title, og:description, and a large og:image.');
        }

        // hreflang (conditional)
        if ($xp) {
            $hl = $xp->query("//link[translate(@rel,'ALTERNATE','alternate')='alternate'][@hreflang]");
            if ($hl && $hl->length) {
                $codes = [];
                foreach ($hl as $l) $codes[] = strtolower($l->getAttribute('hreflang'));
                $xdef = in_array('x-default', $codes, true);
                $checks[] = self::chk('hreflang', 'P1', 'International', $xdef ? 'PASS' : 'WARN', $hl->length . ' hreflang tags.', $xdef ? '' : 'Add x-default and confirm every hreflang is reciprocal + 200.');
            }
        }

        // AEO: question-style headings
        if ($xp) {
            $q = 0;
            foreach ($xp->query('//h2|//h3') as $h) {
                $t = trim($h->textContent);
                if ($t === '') continue;
                if (substr($t, -1) === '?' || preg_match('/^(what|how|why|when|where|who|which|is|are|can|do|does)\b/i', $t)) $q++;
            }
            $checks[] = ($q > 0)
                ? self::chk('aeo_questions', 'P2', 'AEO', 'PASS', "{$q} question-style headings (good for answer extraction).")
                : self::chk('aeo_questions', 'P2', 'AEO', 'WARN', 'No question-style headings found.', 'Frame key sections as user questions with a self-contained answer right after.');
        }

        // bot-wall guard
        $meta['likely_bot_wall'] = (in_array($code, [202, 403, 429], true) || ($words < 40 && $title === '' && $h1n === 0));

        return self::finalize($url, $final, $checks, $manual, $meta);
    }

    /* ---------------- scoring + finalize ---------------- */

    private static function finalize($url, $final, $checks, $manual, $meta) {
        $earned = 0.0; $applicable = 0.0; $p0_fails = 0;
        foreach ($checks as $c) {
            if ($c['status'] === 'NA') continue;
            $w = self::WEIGHTS[$c['priority']] ?? 0;
            $applicable += $w;
            if ($c['status'] === 'PASS') $earned += $w;
            elseif ($c['status'] === 'WARN') $earned += $w / 2;
            if ($c['status'] === 'FAIL' && $c['priority'] === 'P0') $p0_fails++;
        }
        $score = $applicable > 0 ? (int) round($earned / $applicable * 100) : 0;
        // action board: FAIL then WARN, P0→P3
        $order = ['P0' => 0, 'P1' => 1, 'P2' => 2, 'P3' => 3];
        usort($checks, function ($a, $b) use ($order) {
            $sa = $a['status'] === 'FAIL' ? 0 : ($a['status'] === 'WARN' ? 1 : 2);
            $sb = $b['status'] === 'FAIL' ? 0 : ($b['status'] === 'WARN' ? 1 : 2);
            if ($sa !== $sb) return $sa - $sb;
            return ($order[$a['priority']] ?? 9) - ($order[$b['priority']] ?? 9);
        });
        $verdict = $p0_fails > 0 ? 'Failing — P0 blocker' : ($score >= 85 ? 'Healthy' : ($score >= 65 ? 'Needs work' : 'Poor'));
        $meta = array_merge($meta, self::edit_links($final));
        return [
            'url' => $url, 'final_url' => $final, 'score' => $score, 'p0_fails' => $p0_fails,
            'verdict' => $verdict, 'checks' => $checks, 'manual' => $manual, 'meta' => $meta,
            'audited_at' => current_time('mysql'),
        ];
    }

    private static function manual_items() {
        return [
            'Content helpfulness, originality & first-hand experience',
            'Search-intent match & keyword cannibalization',
            'E-E-A-T depth (author, sources, trust signals)',
            'Whether schema matches the visible content',
            'Orphan status & earned links/mentions',
            'AEO answer self-containment',
        ];
    }

    /* ---------------- helpers ---------------- */

    private static function chk($id, $pri, $section, $status, $finding, $action = '', $details = null) {
        $c = compact('id') + ['priority' => $pri, 'section' => $section, 'status' => $status, 'finding' => $finding, 'action' => $action];
        if ($details !== null) $c['details'] = $details;
        return $c;
    }

    private static function trunc($s, $n = 60) {
        $s = trim(preg_replace('/\s+/', ' ', (string) $s));
        return mb_strlen($s) > $n ? mb_substr($s, 0, $n - 1) . '…' : $s;
    }

    private static function edit_links($url) {
        $pid = function_exists('url_to_postid') ? url_to_postid($url) : 0;
        if (!$pid) {
            $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
            if ($path === '') $pid = (int) get_option('page_on_front');
        }
        if (!$pid) return [];
        $out = ['post_id' => $pid, 'edit_url' => admin_url('post.php?post=' . $pid . '&action=edit')];
        if (defined('ELEMENTOR_VERSION')) $out['elementor_url'] = admin_url('post.php?post=' . $pid . '&action=elementor');
        return $out;
    }

    private static function fetch_chain($url) {
        $chain = []; $cur = $url; $guard = 0; $resp = null; $final = $url;
        while ($guard < 6) {
            $r = wp_remote_get($cur, ['redirection' => 0, 'timeout' => 25, 'headers' => ['User-Agent' => self::UA]]);
            if (is_wp_error($r)) return [null, $chain, $cur, $r->get_error_message()];
            $code = (int) wp_remote_retrieve_response_code($r);
            if ($code >= 300 && $code < 400) {
                $loc = wp_remote_retrieve_header($r, 'location');
                if (!$loc) { $resp = $r; $final = $cur; break; }
                $chain[] = ['code' => $code, 'url' => $cur];
                $cur = self::abs($loc, $cur); $guard++; continue;
            }
            $resp = $r; $final = $cur; break;
        }
        return [$resp, $chain, $final, ''];
    }

    private static function dom($html) {
        if ($html === '') return null;
        $prev = libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        return $dom;
    }

    private static function attr($xp, $query, $attr) {
        $n = $xp->query($query);
        if ($n && $n->length) {
            $el = $n->item(0);
            if ($el instanceof DOMElement) return trim($el->getAttribute($attr));
        }
        return '';
    }
    private static function node_text($xp, $query) {
        $n = $xp->query($query);
        return ($n && $n->length) ? $n->item(0)->textContent : '';
    }

    private static function schema($xp) {
        $types = []; $errors = 0;
        foreach ($xp->query("//script[translate(@type,'LDJSON','ldjson')='application/ld+json']") as $s) {
            $data = json_decode($s->textContent, true);
            if ($data === null) { $errors++; continue; }
            $list = isset($data[0]) ? $data : [$data];
            foreach ($list as $obj) {
                if (!is_array($obj)) continue;
                if (isset($obj['@type'])) { foreach ((array) $obj['@type'] as $t) $types[] = $t; }
                if (isset($obj['@graph']) && is_array($obj['@graph'])) {
                    foreach ($obj['@graph'] as $g) { if (is_array($g) && isset($g['@type'])) foreach ((array) $g['@type'] as $t) $types[] = $t; }
                }
            }
        }
        return [array_values(array_unique($types)), $errors];
    }

    private static function word_count($html) {
        $text = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $html);
        $text = wp_strip_all_tags((string) $text);
        return preg_match_all('/\w+/u', $text);
    }

    private static function parse_robots($base) {
        $out = ['reachable' => false, 'status' => null, 'sitemaps' => [], 'agents' => []];
        $r = wp_remote_get(trailingslashit($base) . 'robots.txt', ['timeout' => 12, 'headers' => ['User-Agent' => self::UA]]);
        if (is_wp_error($r)) return $out;
        $out['status'] = (int) wp_remote_retrieve_response_code($r);
        if ($out['status'] !== 200) return $out;
        $out['reachable'] = true;
        $current = ['*'];
        foreach (preg_split('/\r\n|\r|\n/', (string) wp_remote_retrieve_body($r)) as $line) {
            $line = trim(preg_replace('/#.*$/', '', $line));
            if ($line === '') continue;
            $pos = strpos($line, ':');
            if ($pos === false) continue;
            $key = strtolower(trim(substr($line, 0, $pos)));
            $val = trim(substr($line, $pos + 1));
            if ($key === 'user-agent') { $current = [$val]; $out['agents'][$val] = $out['agents'][$val] ?? ['allow' => [], 'disallow' => []]; }
            elseif ($key === 'disallow') { foreach ($current as $a) { $out['agents'][$a] = $out['agents'][$a] ?? ['allow' => [], 'disallow' => []]; $out['agents'][$a]['disallow'][] = $val; } }
            elseif ($key === 'allow')    { foreach ($current as $a) { $out['agents'][$a] = $out['agents'][$a] ?? ['allow' => [], 'disallow' => []]; $out['agents'][$a]['allow'][] = $val; } }
            elseif ($key === 'sitemap')  { $out['sitemaps'][] = $val; }
        }
        return $out;
    }

    private static function path_blocked($robots, $agent, $path) {
        $rules = $robots['agents'][$agent] ?? ($robots['agents']['*'] ?? null);
        if (!$rules) return false;
        $best = -1; $blocked = false;
        foreach (['disallow', 'allow'] as $kind) {
            foreach ($rules[$kind] as $rule) {
                if ($rule === '') continue;
                $pat = '#^' . str_replace(['\*', '\$'], ['.*', '$'], preg_quote($rule, '#')) . '#';
                if (preg_match($pat, $path)) { if (strlen($rule) > $best) { $best = strlen($rule); $blocked = ($kind === 'disallow'); } }
            }
        }
        return $blocked;
    }

    private static function abs($rel, $base) {
        if (class_exists('WP_Http')) {
            $u = WP_Http::make_absolute_url($rel, $base);
            if ($u) return $u;
        }
        return $rel;
    }
    private static function strip_frag($u) { $p = strpos($u, '#'); return $p === false ? $u : substr($u, 0, $p); }
}
