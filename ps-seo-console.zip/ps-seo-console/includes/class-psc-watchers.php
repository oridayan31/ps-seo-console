<?php
if (!defined('ABSPATH')) exit;

/**
 * Scheduler / Watchers. When a trackable change happens, capture a baseline and
 * schedule a follow-up. When it comes due (daily cron), pull current metrics,
 * compute the delta, and drop a review card on the Board.
 */
class PSC_Watchers {

    const OPT_RULES = 'psc_scheduler_rules';

    public static function table() {
        global $wpdb; return $wpdb->prefix . 'psc_watches';
    }

    public static function ensure_table() {
        global $wpdb; $c = $wpdb->get_charset_collate(); $t = self::table();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            subject_url TEXT NULL,
            subject_label TEXT NULL,
            event_type VARCHAR(32) NOT NULL DEFAULT 'manual',
            review_after_days INT NOT NULL DEFAULT 14,
            baseline LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            due_at DATETIME NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'scheduled',
            fired_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY status (status),
            KEY due_at (due_at)
        ) {$c};");
    }

    /* ---- rules ---- */

    public static function default_rules() {
        return [
            'page_created'   => ['on' => true,  'days' => 14, 'label' => 'New page / collection created'],
            'redirect_set'   => ['on' => true,  'days' => 28, 'label' => '301 / canonical set'],
            'meta_rewrite'   => ['on' => true,  'days' => 14, 'label' => 'Meta title / description rewritten'],
            'post_published' => ['on' => false, 'days' => 28, 'label' => 'Blog post published'],
        ];
    }
    public static function rules() {
        $saved = get_option(self::OPT_RULES, []);
        $out = self::default_rules();
        if (is_array($saved)) {
            foreach ($out as $k => $v) {
                if (isset($saved[$k]['on']))   $out[$k]['on']   = (bool) $saved[$k]['on'];
                if (isset($saved[$k]['days'])) $out[$k]['days'] = max(1, (int) $saved[$k]['days']);
            }
        }
        return $out;
    }
    public static function save_rules($input) {
        $rules = self::rules();
        $save = [];
        foreach ($rules as $k => $v) {
            $save[$k] = [
                'on'   => !empty($input[$k]['on']),
                'days' => isset($input[$k]['days']) ? max(1, (int) $input[$k]['days']) : $v['days'],
            ];
        }
        update_option(self::OPT_RULES, $save);
    }

    /* ---- create ---- */

    public static function create_watch($subject_url, $event_type, $label = '', $days_override = null) {
        self::ensure_table();
        $rules = self::rules();
        $days = $days_override;
        if ($days === null) {
            $days = isset($rules[$event_type]['days']) ? (int) $rules[$event_type]['days'] : 14;
        }
        $now = current_time('mysql');
        $due = gmdate('Y-m-d H:i:s', strtotime($now . " +{$days} day"));
        $baseline = self::snapshot($subject_url);
        global $wpdb;
        $wpdb->insert(self::table(), [
            'subject_url'       => $subject_url ? esc_url_raw($subject_url) : null,
            'subject_label'     => $label !== '' ? sanitize_text_field($label) : ($subject_url ?: 'watch'),
            'event_type'        => sanitize_key($event_type),
            'review_after_days' => (int) $days,
            'baseline'          => wp_json_encode($baseline),
            'created_at'        => $now,
            'due_at'            => $due,
            'status'            => 'scheduled',
        ]);
        return $wpdb->insert_id;
    }

    private static function snapshot($url) {
        $m = $url && class_exists('PSC_GSC') ? PSC_GSC::page_metrics($url) : null;
        return [
            'clicks'      => $m ? (int) $m['clicks'] : 0,
            'impressions' => $m ? (int) $m['impressions'] : 0,
            'position'    => $m ? round((float) $m['position'], 1) : null,
            'at'          => current_time('mysql'),
        ];
    }

    /* ---- auto-create on publish ---- */

    public static function on_transition($new_status, $old_status, $post) {
        if ($new_status !== 'publish' || $old_status === 'publish') return;
        if (!$post || $post->post_status !== 'publish') return;
        $rules = self::rules();
        if ($post->post_type === 'page' && !empty($rules['page_created']['on'])) {
            self::create_watch(get_permalink($post->ID), 'page_created', get_the_title($post->ID));
        } elseif ($post->post_type === 'post' && !empty($rules['post_published']['on'])) {
            self::create_watch(get_permalink($post->ID), 'post_published', get_the_title($post->ID));
        }
    }

    /* ---- due check (cron) ---- */

    public static function check_due() {
        self::ensure_table();
        global $wpdb; $t = self::table();
        $now = current_time('mysql');
        $due = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$t} WHERE status='scheduled' AND due_at <= %s ORDER BY due_at ASC LIMIT 50",
            $now
        ), ARRAY_A);
        foreach ((array) $due as $w) {
            self::fire($w);
        }
        return is_array($due) ? count($due) : 0;
    }

    private static function fire($w) {
        global $wpdb;
        $base = json_decode((string) $w['baseline'], true);
        $base = is_array($base) ? $base : ['clicks' => 0, 'impressions' => 0, 'position' => null];
        $curr = self::snapshot($w['subject_url']);

        $days = (int) $w['review_after_days'];
        $label = $w['subject_label'] ?: $w['subject_url'];
        $deltaline = sprintf(
            'impr %d→%d · clicks %d→%d · pos %s→%s',
            (int) $base['impressions'], (int) $curr['impressions'],
            (int) $base['clicks'], (int) $curr['clicks'],
            $base['position'] === null ? '—' : $base['position'],
            $curr['position'] === null ? '—' : $curr['position']
        );
        $prompt = sprintf(
            "Review (%d days on): %s\n%s\nDecide: keep as-is / strengthen (content + internal links) / consolidate. If flat, investigate why.",
            $days, $label, $deltaline
        );

        // If a Google Search update overlapped the measurement window, flag it so a
        // ranking move isn't misattributed to our change.
        if (class_exists('PSC_GoogleStatus')) {
            $end_ts = strtotime($now);
            $start_ts = $end_ts - $days * DAY_IN_SECONDS;
            $hits = PSC_GoogleStatus::overlapping($start_ts, $end_ts);
            if ($hits) {
                $names = [];
                foreach (array_slice($hits, 0, 3) as $h) $names[] = $h['title'] . ' (' . $h['service'] . ')';
                $prompt .= "\n⚠ Google Search activity overlapped this window: " . implode('; ', $names) . '. A move here may be Google-side, not your change.';
            }
        }

        PSC_DB::create_task([
            'title'      => 'Review: ' . $label,
            'priority'   => 'YOU',
            'domain'     => 'art',
            'status'     => 'pending',
            'source'     => 'watcher',
            'target_url' => $w['subject_url'],
            'prompt'     => $prompt,
        ]);

        $wpdb->update(self::table(), ['status' => 'fired', 'fired_at' => current_time('mysql')], ['id' => (int) $w['id']]);
    }

    /* ---- read ---- */

    public static function upcoming($limit = 20) {
        global $wpdb; $t = self::table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$t} WHERE status='scheduled' ORDER BY due_at ASC LIMIT %d", $limit
        ), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function count_due_soon($days = 7) {
        global $wpdb; $t = self::table();
        $limit = gmdate('Y-m-d H:i:s', strtotime("+{$days} day"));
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$t} WHERE status='scheduled' AND due_at <= %s", $limit
        ));
    }
}
