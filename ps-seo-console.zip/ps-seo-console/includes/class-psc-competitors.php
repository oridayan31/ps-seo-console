<?php
if (!defined('ABSPATH')) exit;

/**
 * Competitor authority / backlink-gap analysis. Compares this site's referring
 * domains against a competitor set using the DataForSEO Backlinks "summary" API
 * (same login as the keyword connector — Backlinks is just a separate, metered
 * endpoint on that account). Fetches only on explicit refresh (to avoid silent
 * credit spend) and caches 24h.
 */
class PSC_Competitors {

    const OPT_LIST = 'psc_competitors';
    const CACHE    = 'psc_competitor_report';
    const ENDPOINT = 'https://api.dataforseo.com/v3/backlinks/summary/live';

    /** Seeded from the wall-art / print competitive set. */
    private static function seed() {
        return [
            'fineartamerica.com', 'art.com', 'desenio.com', 'bigwalldecor.com',
            'artbymaudsch.com', 'olivergal.com', 'pstrstudio.com', 'cattiecoylephotography.com',
        ];
    }

    public static function list() {
        $l = get_option(self::OPT_LIST, null);
        if (!is_array($l)) { $l = self::seed(); update_option(self::OPT_LIST, $l); }
        return array_values(array_unique($l));
    }

    public static function add($domain) {
        $d = self::normalize($domain);
        if (!$d) return [false, 'Enter a valid root domain (e.g. competitor.com).'];
        if (strpos($d, '.') === false) return [false, 'That does not look like a domain.'];
        $l = self::list();
        if (in_array($d, $l, true)) return [false, 'Already in the list.'];
        $l[] = $d; update_option(self::OPT_LIST, $l);
        delete_transient(self::CACHE);
        return [true, $d];
    }

    public static function remove($domain) {
        $d = self::normalize($domain);
        $l = array_values(array_filter(self::list(), function ($x) use ($d) { return $x !== $d; }));
        update_option(self::OPT_LIST, $l);
        delete_transient(self::CACHE);
        return [true, $d];
    }

    /** Cached report; pass force=true to spend credits and pull live data. */
    public static function report($force = false) {
        if (!$force) {
            $c = get_transient(self::CACHE);
            if (is_array($c)) return $c;
        }
        $own = self::own_domain();
        $competitors = self::list();
        $targets = array_values(array_unique(array_merge([$own], $competitors)));

        if (!class_exists('PSC_Connectors') || !PSC_Connectors::has_dataforseo()) {
            // Return the list with no metrics so the tab still renders + can be edited.
            $rows = [];
            foreach ($competitors as $c) $rows[] = ['domain' => $c, 'referring_domains' => null, 'authority' => null, 'you' => false];
            return ['status' => 'needs_dataforseo', 'own' => $own, 'you_rd' => null, 'median' => null, 'gap' => null, 'rows' => $rows, 'generated_at' => current_time('mysql')];
        }
        if (!$force) {
            // No cache yet and not forced: render the list, prompt to fetch.
            $rows = [];
            foreach ($competitors as $c) $rows[] = ['domain' => $c, 'referring_domains' => null, 'authority' => null, 'you' => false];
            return ['status' => 'idle', 'own' => $own, 'you_rd' => null, 'median' => null, 'gap' => null, 'rows' => $rows, 'generated_at' => null];
        }

        $data = self::fetch($targets);
        if (isset($data['error'])) {
            return ['status' => 'error', 'note' => $data['error'], 'own' => $own, 'rows' => [], 'generated_at' => current_time('mysql')];
        }

        $rows = [];
        $comp_rd = [];
        $you_rd = null;
        foreach ($targets as $t) {
            $m = $data[$t] ?? null;
            $rd = $m['referring_domains'] ?? null;
            $auth = isset($m['rank']) ? (int) round($m['rank'] / 10) : null; // DataForSEO rank 0-1000 → ~0-100
            $is_you = ($t === $own);
            if ($is_you) $you_rd = $rd;
            elseif ($rd !== null) $comp_rd[] = $rd;
            $rows[] = ['domain' => $t, 'referring_domains' => $rd, 'authority' => $auth, 'you' => $is_you];
        }
        usort($rows, function ($a, $b) { return (int) $b['referring_domains'] <=> (int) $a['referring_domains']; });

        $median = self::median($comp_rd);
        $gap = ($median && $you_rd) ? round($median / max(1, $you_rd), 1) : null;

        $report = [
            'status' => 'ok', 'own' => $own, 'you_rd' => $you_rd,
            'median' => $median, 'gap' => $gap, 'rows' => $rows,
            'generated_at' => current_time('mysql'),
        ];
        set_transient(self::CACHE, $report, DAY_IN_SECONDS);
        return $report;
    }

    /* ---------------- DataForSEO ---------------- */

    private static function fetch($targets) {
        $c = PSC_Connectors::dataforseo();
        $body = [];
        foreach ($targets as $t) $body[] = ['target' => $t, 'internal_list_limit' => 1, 'backlinks_status_type' => 'live'];
        $resp = wp_remote_post(self::ENDPOINT, [
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($c['login'] . ':' . $c['password']),
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($body),
        ]);
        if (is_wp_error($resp)) return ['error' => $resp->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($resp);
        $json = json_decode((string) wp_remote_retrieve_body($resp), true);
        if ($code === 401) return ['error' => 'DataForSEO auth failed — check the login/password in Settings.'];
        if (!is_array($json)) return ['error' => 'Unexpected response from DataForSEO.'];
        if ((int) ($json['status_code'] ?? 0) !== 20000) {
            return ['error' => 'DataForSEO: ' . ($json['status_message'] ?? 'request failed') . ' (the Backlinks API may not be enabled on this account).'];
        }
        $out = [];
        foreach (($json['tasks'] ?? []) as $task) {
            $target = $task['data']['target'] ?? ($task['result'][0]['target'] ?? null);
            if (!$target) continue;
            $r = $task['result'][0] ?? null;
            if (is_array($r)) {
                $out[$target] = ['referring_domains' => (int) ($r['referring_domains'] ?? 0), 'rank' => (int) ($r['rank'] ?? 0)];
            }
        }
        return $out;
    }

    /* ---------------- helpers ---------------- */

    private static function own_domain() {
        $h = wp_parse_url(home_url(), PHP_URL_HOST);
        return $h ? preg_replace('/^www\./', '', strtolower($h)) : '';
    }

    private static function normalize($d) {
        $d = strtolower(trim((string) $d));
        $d = preg_replace('#^https?://#', '', $d);
        $d = preg_replace('#/.*$#', '', $d);
        $d = preg_replace('/^www\./', '', $d);
        return preg_match('/^[a-z0-9.\-]+\.[a-z]{2,}$/', $d) ? $d : '';
    }

    private static function median($arr) {
        $arr = array_values(array_filter($arr, function ($v) { return $v !== null; }));
        sort($arr, SORT_NUMERIC);
        $n = count($arr);
        if ($n === 0) return null;
        $mid = intdiv($n, 2);
        return $n % 2 ? $arr[$mid] : (int) round(($arr[$mid - 1] + $arr[$mid]) / 2);
    }
}
