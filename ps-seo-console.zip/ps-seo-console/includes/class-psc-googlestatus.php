<?php
if (!defined('ABSPATH')) exit;

/**
 * Google Search Status Dashboard integration. Pulls the public incidents feed
 * (Crawling / Indexing / Ranking / Serving) so the Console can (a) show whether
 * Google itself is having an incident and (b) tell a Watcher review whether a
 * Google update overlapped the measurement window — so a ranking move isn't
 * misattributed to one of our own changes. Cached 6h.
 */
class PSC_GoogleStatus {

    const FEED  = 'https://status.search.google.com/incidents.json';
    const CACHE = 'psc_gsearch_status';

    public static function incidents($force = false) {
        if (!$force) {
            $c = get_transient(self::CACHE);
            if (is_array($c)) return $c;
        }
        $r = wp_remote_get(self::FEED, ['timeout' => 15, 'headers' => ['Accept' => 'application/json']]);
        if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
            return get_transient(self::CACHE) ?: [];
        }
        $data = json_decode((string) wp_remote_retrieve_body($r), true);
        if (!is_array($data)) return get_transient(self::CACHE) ?: [];
        $out = [];
        foreach ($data as $i) {
            if (!is_array($i)) continue;
            $out[] = [
                'id'       => $i['id'] ?? '',
                'title'    => $i['external_desc'] ?? '',
                'service'  => $i['service_name'] ?? '',
                'impact'   => $i['status_impact'] ?? '',     // SERVICE_INFORMATION / SERVICE_DISRUPTION / SERVICE_OUTAGE
                'severity' => $i['severity'] ?? '',
                'begin'    => $i['begin'] ?? '',
                'end'      => $i['end'] ?? null,
                'ongoing'  => empty($i['end']),
                'url'      => 'https://status.search.google.com/' . ltrim((string) ($i['uri'] ?? ''), '/'),
            ];
        }
        set_transient(self::CACHE, $out, 6 * HOUR_IN_SECONDS);
        return $out;
    }

    /** Incidents that are ongoing or end in the future. */
    public static function active() {
        $now = time(); $a = [];
        foreach (self::incidents() as $i) {
            $end = $i['end'] ? strtotime($i['end']) : null;
            if ($end === null || $end > $now) $a[] = $i;
        }
        return $a;
    }

    /** Newest-first; the feed is already ordered that way. */
    public static function recent($n = 3) {
        return array_slice(self::incidents(), 0, $n);
    }

    /** Incidents whose [begin, end] window intersects [$start_ts, $end_ts]. */
    public static function overlapping($start_ts, $end_ts) {
        $hits = [];
        foreach (self::incidents() as $i) {
            if (empty($i['begin'])) continue;
            $b = strtotime($i['begin']);
            $e = $i['end'] ? strtotime($i['end']) : time();
            if ($b <= $end_ts && $e >= $start_ts) $hits[] = $i;
        }
        return $hits;
    }
}
