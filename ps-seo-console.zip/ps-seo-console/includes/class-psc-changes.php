<?php
if (!defined('ABSPATH')) exit;

/**
 * Change → impact tracker. Log what you changed and where; the tracker captures the
 * target page's Search Console metrics as a baseline, snapshots them on every daily
 * sync, and reports the effect (clicks / CTR / position) against a realistic waiting
 * period for that kind of change — so "I added internal links to push this page" turns
 * into a tracked experiment with a verdict, not a guess.
 */
class PSC_Changes {

    const OPT = 'psc_changes';
    // realistic days before an effect is fair to judge, by change type
    const WAIT = [
        'internal_links' => 21, 'new_page' => 42, 'new_collection' => 42, 'meta' => 14,
        'title' => 14, 'content' => 28, 'redirect' => 21, 'schema' => 21, 'noindex_fix' => 21, 'other' => 28,
    ];

    public static function all() { $a = get_option(self::OPT, []); return is_array($a) ? $a : []; }

    public static function metrics($url) {
        if (!$url || !class_exists('PSC_GSC')) return null;
        $m = PSC_GSC::page_metrics($url);
        if (!is_array($m)) return null;
        $impr = (float) ($m['impressions'] ?? 0); $clicks = (float) ($m['clicks'] ?? 0);
        return ['clicks' => (int) $clicks, 'impr' => (int) $impr, 'ctr' => $impr > 0 ? round($clicks / $impr * 100, 2) : 0, 'pos' => round((float) ($m['position'] ?? 0), 1)];
    }

    public static function add($args) {
        $changes = self::all();
        $url = esc_url_raw($args['url'] ?? '');
        $entry = [
            'id'         => (string) (time() . rand(100, 999)),
            'title'      => sanitize_text_field($args['title'] ?? 'Change'),
            'url'        => $url,
            'kind'       => sanitize_key($args['kind'] ?? 'other'),
            'note'       => sanitize_textarea_field($args['note'] ?? ''),
            'date'       => !empty($args['date']) ? sanitize_text_field($args['date']) : current_time('Y-m-d'),
            'created_at' => current_time('mysql'),
            'baseline'   => self::metrics($url),
            'snapshots'  => [],
        ];
        array_unshift($changes, $entry);
        update_option(self::OPT, array_slice($changes, 0, 100), false);
        return $entry;
    }

    public static function remove($id) {
        $changes = array_values(array_filter(self::all(), function ($c) use ($id) { return $c['id'] !== $id; }));
        update_option(self::OPT, $changes, false);
        return true;
    }

    public static function snapshot_all() {
        $changes = self::all();
        $now = current_time('mysql');
        foreach ($changes as &$c) {
            if (empty($c['url'])) continue;
            $m = self::metrics($c['url']);
            if ($m) {
                if (empty($c['baseline'])) $c['baseline'] = $m; // fill baseline if it was empty at creation
                $c['snapshots'][] = ['at' => $now] + $m;
                if (count($c['snapshots']) > 90) $c['snapshots'] = array_slice($c['snapshots'], -90);
            }
        }
        unset($c);
        update_option(self::OPT, $changes, false);
    }

    public static function report() {
        $out = [];
        foreach (self::all() as $c) {
            $wait = self::WAIT[$c['kind']] ?? 28;
            $elapsed = max(0, (int) floor((current_time('timestamp') - strtotime($c['date'])) / DAY_IN_SECONDS));
            $status = $elapsed < max(3, (int) ($wait / 4)) ? 'too_early' : ($elapsed < $wait ? 'developing' : 'measurable');
            $latest = !empty($c['snapshots']) ? end($c['snapshots']) : self::metrics($c['url']);
            $base = $c['baseline'];
            $delta = null;
            if (is_array($base) && is_array($latest)) {
                $delta = [
                    'clicks' => (int) $latest['clicks'] - (int) $base['clicks'],
                    'impr'   => (int) $latest['impr'] - (int) $base['impr'],
                    'ctr'    => round((float) $latest['ctr'] - (float) $base['ctr'], 2),
                    'pos'    => round((float) $base['pos'] - (float) $latest['pos'], 1), // + = moved up (improved)
                ];
            }
            $out[] = [
                'id' => $c['id'], 'title' => $c['title'], 'url' => $c['url'], 'kind' => $c['kind'], 'note' => $c['note'],
                'date' => $c['date'], 'elapsed_days' => $elapsed, 'recommended_wait' => $wait, 'status' => $status,
                'baseline' => $base, 'latest' => $latest, 'delta' => $delta,
                'trend' => array_map(function ($s) { return ['at' => $s['at'], 'clicks' => $s['clicks'], 'pos' => $s['pos']]; }, $c['snapshots']),
            ];
        }
        return $out;
    }
}
