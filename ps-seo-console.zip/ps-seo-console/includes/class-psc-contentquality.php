<?php
if (!defined('ABSPATH')) exit;

/**
 * Content-quality / "helpful content" grader. There is no API that tells you
 * whether Google has demoted a site — so instead this reads a page's actual text
 * and grades it against Google's Helpful Content + spam-policy signals using the
 * site's own Anthropic key: AI "tells", thin/generic copy, keyword stuffing,
 * missing E-E-A-T, and templated/duplicative writing. Returns a score, a risk
 * band, the specific offending phrases, and concrete fixes.
 */
class PSC_ContentQuality {

    const MODEL = 'claude-sonnet-5';
    const UA    = 'PS-SEO-Console/1.0 (+content-quality)';

    public static function cache_key($url) { return 'psc_cq_' . md5($url); }

    public static function check_url($url, $force = false) {
        $url = esc_url_raw(trim($url));
        if (!$url) return ['error' => 'bad_url', 'message' => 'Enter a valid URL.'];
        if (!$force) { $c = get_transient(self::cache_key($url)); if (is_array($c)) return $c; }

        if (!class_exists('PSC_Connectors') || !PSC_Connectors::has_anthropic()) {
            return ['error' => 'no_key', 'message' => 'Add your Anthropic API key in Settings → Connectors to enable content grading.'];
        }

        // 1) fetch + extract main text
        $r = wp_remote_get($url, ['timeout' => 25, 'headers' => ['User-Agent' => self::UA]]);
        if (is_wp_error($r)) return ['error' => 'fetch', 'message' => $r->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($r);
        if ($code >= 400) return ['error' => 'fetch', 'message' => "Page returned HTTP {$code}."];
        $html = wp_remote_retrieve_body($r);

        $title = '';
        if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $title = trim(html_entity_decode(wp_strip_all_tags($m[1]), ENT_QUOTES));
        $desc = '';
        if (preg_match('#<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']#is', $html, $m)) $desc = trim($m[1]);

        $body = preg_replace('#<(script|style|noscript|svg)[^>]*>.*?</\1>#is', ' ', $html);
        $body = preg_replace('#<(nav|header|footer|form)\b[^>]*>.*?</\1>#is', ' ', $body);
        if (preg_match('#<body[^>]*>(.*)</body>#is', $body, $m)) $body = $m[1];
        $text = trim(preg_replace('/\s+/', ' ', html_entity_decode(wp_strip_all_tags($body), ENT_QUOTES)));
        $words = str_word_count($text);
        $text = mb_substr($text, 0, 8000);
        if (mb_strlen($text) < 120) return ['error' => 'thin', 'message' => 'Almost no server-rendered text found — content may be JS-injected, which Google may not index well.', 'word_count' => $words];

        // 2) grade with Claude
        $system = "You are a strict SEO content-quality auditor. Judge web page text against Google's Helpful Content system and spam policies (helpful, reliable, people-first content; demote scaled/unoriginal/keyword-stuffed/thin content lacking first-hand experience or E-E-A-T). Be specific and quote the actual phrases. Reply with ONLY minified JSON, no prose, no markdown fences.";
        $schema = '{"quality_score":0-100 int (higher=more helpful/original),"helpful_content_risk":"low|medium|high","ai_tells":[SHORT verbatim phrases <=8 words each, or []],"issues":[{"type":"thin|generic_filler|keyword_stuffing|no_first_hand_experience|weak_eeat|templated|unhelpful|over_optimized","detail":"specific, brief"}],"strengths":[short strings],"recommendations":[concrete fixes],"verdict":"one sentence"}';
        $user = "URL: {$url}\nTITLE: {$title}\nMETA: {$desc}\nWORD_COUNT: {$words}\n\nGrade this page's main content. Keep every string concise. Return JSON exactly matching this schema:\n{$schema}\n\nPAGE TEXT:\n{$text}";

        $resp = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'timeout' => 60,
            'headers' => ['x-api-key' => PSC_Connectors::anthropic(), 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json'],
            'body'    => wp_json_encode(['model' => self::MODEL, 'max_tokens' => 2500, 'system' => $system, 'messages' => [['role' => 'user', 'content' => $user]]]),
        ]);
        if (is_wp_error($resp)) return ['error' => 'api', 'message' => $resp->get_error_message()];
        $rc = (int) wp_remote_retrieve_response_code($resp);
        $rb = json_decode(wp_remote_retrieve_body($resp), true);
        if ($rc >= 400) return ['error' => 'api', 'message' => $rb['error']['message'] ?? "Anthropic API HTTP {$rc}"];

        $out = '';
        foreach (($rb['content'] ?? []) as $blk) if (($blk['type'] ?? '') === 'text') $out .= $blk['text'];
        $out = trim(preg_replace('/^```(?:json)?|```$/m', '', trim($out)));
        $graded = json_decode($out, true);
        if (!is_array($graded) && preg_match('/\{.*\}/s', $out, $mm)) $graded = json_decode($mm[0], true);
        if (!is_array($graded)) return ['error' => 'parse', 'message' => 'Could not parse the grading response (try again).', 'raw' => mb_substr($out, 0, 400)];

        $result = [
            'url'         => $url,
            'title'       => $title,
            'word_count'  => $words,
            'model'       => self::MODEL,
            'graded'      => $graded,
            'checked_at'  => current_time('mysql'),
        ];
        set_transient(self::cache_key($url), $result, 12 * HOUR_IN_SECONDS);
        return $result;
    }
}
