<?php
if (!defined('ABSPATH')) exit;

/**
 * Third-party data connectors: DataForSEO (keyword data), PageSpeed Insights
 * (Core Web Vitals), Anthropic (AI SEO). Keys live in options OR wp-config
 * constants (constants win). Includes connectivity tests and a scanner that
 * imports keys already stored by other plugins (e.g. SAI) WITHOUT ever
 * returning the raw secret over REST — it copies option->option internally
 * and reports masked values only.
 */
class PSC_Connectors {

    const OPT_DFS = 'psc_dataforseo';   // ['login','password']
    const OPT_PSI = 'psc_pagespeed';    // 'key'
    const OPT_ANT = 'psc_anthropic';    // 'key'

    /* ---------- getters (constant override wins) ---------- */

    public static function dataforseo() {
        if (defined('PSC_DATAFORSEO_LOGIN') && defined('PSC_DATAFORSEO_PASSWORD')) {
            return ['login' => constant('PSC_DATAFORSEO_LOGIN'), 'password' => constant('PSC_DATAFORSEO_PASSWORD')];
        }
        $o = get_option(self::OPT_DFS, []);
        return is_array($o) ? $o : [];
    }
    public static function pagespeed() {
        if (defined('PSC_PAGESPEED_KEY')) return (string) constant('PSC_PAGESPEED_KEY');
        return (string) get_option(self::OPT_PSI, '');
    }
    public static function anthropic() {
        if (defined('PSC_ANTHROPIC_KEY')) return (string) constant('PSC_ANTHROPIC_KEY');
        return (string) get_option(self::OPT_ANT, '');
    }

    public static function has_dataforseo() { $d = self::dataforseo(); return !empty($d['login']) && !empty($d['password']); }
    public static function has_pagespeed()  { return self::pagespeed() !== ''; }
    public static function has_anthropic()  { return self::anthropic() !== ''; }

    /* ---------- setters ---------- */

    public static function set_dataforseo($login, $password) {
        update_option(self::OPT_DFS, ['login' => sanitize_text_field($login), 'password' => trim((string) $password)]);
    }
    public static function set_pagespeed($key) { update_option(self::OPT_PSI, trim((string) $key)); }
    public static function set_anthropic($key) { update_option(self::OPT_ANT, trim((string) $key)); }

    public static function status() {
        return [
            'dataforseo' => ['configured' => self::has_dataforseo(), 'masked' => self::mask(self::dataforseo()['login'] ?? '')],
            'pagespeed'  => ['configured' => self::has_pagespeed(),  'masked' => self::mask(self::pagespeed())],
            'anthropic'  => ['configured' => self::has_anthropic(),  'masked' => self::mask(self::anthropic())],
        ];
    }

    /* ---------- connectivity tests ---------- */

    public static function test($which) {
        switch ($which) {
            case 'dataforseo': return self::test_dfs();
            case 'pagespeed':  return self::test_psi();
            case 'anthropic':  return self::test_ant();
        }
        return [false, 'Unknown connector'];
    }

    private static function test_dfs() {
        $d = self::dataforseo();
        if (empty($d['login']) || empty($d['password'])) return [false, 'Not configured'];
        $resp = wp_remote_get('https://api.dataforseo.com/v3/appendix/user_data', [
            'timeout' => 20,
            'headers' => ['Authorization' => 'Basic ' . base64_encode($d['login'] . ':' . $d['password'])],
        ]);
        if (is_wp_error($resp)) return [false, $resp->get_error_message()];
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        if (isset($b['tasks'][0]['result'][0]['money']['balance'])) {
            return [true, 'Connected · balance $' . $b['tasks'][0]['result'][0]['money']['balance']];
        }
        if ((int) wp_remote_retrieve_response_code($resp) === 401) return [false, 'Invalid login / password'];
        return [false, $b['status_message'] ?? 'Unexpected response'];
    }

    private static function test_psi() {
        $key = self::pagespeed();
        if ($key === '') return [false, 'Not configured'];
        $url = add_query_arg([
            'url' => home_url('/'), 'strategy' => 'mobile', 'key' => $key,
        ], 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed');
        $resp = wp_remote_get($url, ['timeout' => 40]);
        if (is_wp_error($resp)) return [false, $resp->get_error_message()];
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        if (isset($b['lighthouseResult']['categories']['performance']['score'])) {
            $score = (int) round($b['lighthouseResult']['categories']['performance']['score'] * 100);
            return [true, 'Connected · homepage perf ' . $score];
        }
        return [false, $b['error']['message'] ?? 'Unexpected response'];
    }

    private static function test_ant() {
        $key = self::anthropic();
        if ($key === '') return [false, 'Not configured'];
        // GET /v1/models lists models — no token cost.
        $resp = wp_remote_get('https://api.anthropic.com/v1/models', [
            'timeout' => 20,
            'headers' => ['x-api-key' => $key, 'anthropic-version' => '2023-06-01'],
        ]);
        if (is_wp_error($resp)) return [false, $resp->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($resp);
        if ($code === 200) return [true, 'Connected'];
        if ($code === 401) return [false, 'Invalid API key'];
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        return [false, $b['error']['message'] ?? ('HTTP ' . $code)];
    }

    /* ---------- SAI import scanner (safe: masked out, raw copied internally) ---------- */

    public static function scan() {
        global $wpdb;
        $found = [];
        // Anthropic keys anywhere in options.
        $rows = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options}
              WHERE option_value LIKE '%sk-ant-%' OR option_value LIKE '%AIza%'
                 OR option_name LIKE '%dataforseo%' OR option_name LIKE '%data_for_seo%'
                 OR option_name LIKE '%pagespeed%' OR option_name LIKE '%anthropic%'
                 OR option_name LIKE '%sai%' OR option_name LIKE '%seo_ai%'
              LIMIT 200", ARRAY_A
        );
        foreach ((array) $rows as $r) {
            $val = (string) $r['option_value'];
            if (preg_match('/sk-ant-[A-Za-z0-9_\-]{20,}/', $val, $m)) {
                $found['anthropic'] = ['option' => $r['option_name'], 'value' => $m[0], 'masked' => self::mask($m[0])];
            }
            if (preg_match('/AIza[0-9A-Za-z_\-]{35}/', $val, $m)) {
                $found['pagespeed'] = ['option' => $r['option_name'], 'value' => $m[0], 'masked' => self::mask($m[0])];
            }
            if (stripos($r['option_name'], 'dataforseo') !== false || stripos($r['option_name'], 'data_for_seo') !== false) {
                $unser = maybe_unserialize($val);
                $login = ''; $pass = '';
                if (is_array($unser)) {
                    foreach ($unser as $k => $v) {
                        if (!is_scalar($v)) continue;
                        if (stripos($k, 'login') !== false || stripos($k, 'email') !== false || stripos($k, 'user') !== false) $login = (string) $v;
                        if (stripos($k, 'pass') !== false || stripos($k, 'secret') !== false) $pass = (string) $v;
                    }
                }
                if ($login || $pass) {
                    $found['dataforseo'] = ['option' => $r['option_name'], 'login' => $login, 'password' => $pass, 'masked' => self::mask($login)];
                }
            }
        }
        // Return masked report only.
        $report = [];
        foreach ($found as $type => $f) {
            $report[$type] = ['option' => $f['option'], 'masked' => $f['masked']];
        }
        set_transient('psc_scan_found', $found, HOUR_IN_SECONDS); // raw cached server-side only, for import step
        return $report;
    }

    /** Import a scanned key into the Console's own settings (server-side only). */
    public static function import($type) {
        $found = get_transient('psc_scan_found');
        if (!is_array($found) || empty($found[$type])) return [false, 'Nothing to import — run scan first'];
        $f = $found[$type];
        if ($type === 'anthropic') { self::set_anthropic($f['value']); return [true, 'Imported Anthropic key']; }
        if ($type === 'pagespeed') { self::set_pagespeed($f['value']); return [true, 'Imported PageSpeed key']; }
        if ($type === 'dataforseo') { self::set_dataforseo($f['login'], $f['password']); return [true, 'Imported DataForSEO login']; }
        return [false, 'Unknown type'];
    }

    private static function mask($s) {
        $s = (string) $s;
        $len = strlen($s);
        if ($len === 0) return '';
        if ($len <= 8) return str_repeat('•', max(0, $len - 2)) . substr($s, -2);
        return substr($s, 0, 4) . '…' . substr($s, -4);
    }
}
