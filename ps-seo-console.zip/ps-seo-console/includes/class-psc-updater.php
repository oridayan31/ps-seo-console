<?php
if (!defined('ABSPATH')) exit;

/**
 * Remote self-update. Installs a verified plugin zip (this Console or the bridge)
 * pushed via REST, so new versions don't need a manual admin upload. Deliberately
 * hardened: requires a second secret (the update token) beyond WP auth, only accepts
 * an allow-listed slug, verifies a SHA-256, rejects any path outside the slug folder,
 * and backs up + rolls back on failure. Dormant until a token is set.
 */
class PSC_Updater {

    const OPT_TOKEN = 'psc_update_token';                 // password_hash of the token
    const ALLOWED   = ['ps-seo-console', 'ps-claude-bridge'];
    const OPT_SOURCE       = 'psc_update_source';         // manifest URL (pull)
    const OPT_SOURCE_TOKEN = 'psc_update_source_token';   // optional bearer for private source
    const OPT_AUTO         = 'psc_update_auto';           // '1' = install on cron, '0' = notify only

    /* ---- pull-source settings ---- */

    public static function source_url()   { return (string) get_option(self::OPT_SOURCE, ''); }
    public static function source_token() { return (string) get_option(self::OPT_SOURCE_TOKEN, ''); }
    public static function has_source()   { return self::source_url() !== ''; }
    public static function auto_on()      { return get_option(self::OPT_AUTO, '0') === '1'; }

    public static function save_source($url, $token, $auto) {
        $url = esc_url_raw(trim((string) $url));
        update_option(self::OPT_SOURCE, $url);
        if ($token !== null) update_option(self::OPT_SOURCE_TOKEN, trim((string) $token));
        update_option(self::OPT_AUTO, $auto ? '1' : '0');
    }

    public static function current_version($slug) {
        return self::installed_version(sanitize_key($slug));
    }

    /* ---- token ---- */

    public static function has_token() {
        if (defined('PSC_UPDATE_TOKEN') && constant('PSC_UPDATE_TOKEN') !== '') return true;
        return get_option(self::OPT_TOKEN, '') !== '';
    }

    public static function set_token($plain) {
        $plain = (string) $plain;
        if (strlen($plain) < 16) return [false, 'Use a token of at least 16 characters.'];
        update_option(self::OPT_TOKEN, password_hash($plain, PASSWORD_DEFAULT));
        return [true, 'Update token set.'];
    }

    public static function verify_token($provided) {
        $provided = (string) $provided;
        if ($provided === '') return false;
        if (defined('PSC_UPDATE_TOKEN') && constant('PSC_UPDATE_TOKEN') !== '') {
            return hash_equals((string) constant('PSC_UPDATE_TOKEN'), $provided);
        }
        $h = get_option(self::OPT_TOKEN, '');
        return $h !== '' && password_verify($provided, $h);
    }

    /* ---- install ---- */

    public static function install($slug, $zip_b64, $expected_sha256 = '') {
        if (!current_user_can('update_plugins')) return [false, 'Insufficient permissions.'];
        if (!self::has_token()) return [false, 'Update token not configured — set one in Settings first.'];
        $slug = sanitize_key($slug);
        if (!in_array($slug, self::ALLOWED, true)) return [false, 'Slug not allowed.'];

        $bytes = base64_decode((string) $zip_b64, true);
        if ($bytes === false || $bytes === '') return [false, 'Invalid or empty zip payload.'];
        return self::install_bytes($slug, $bytes, $expected_sha256);
    }

    /** Verified install from raw zip bytes — shared by the push endpoint and the pull check. */
    public static function install_bytes($slug, $bytes, $expected_sha256 = '') {
        $slug = sanitize_key($slug);
        if (!in_array($slug, self::ALLOWED, true)) return [false, 'Slug not allowed.'];
        if ($bytes === '' || $bytes === false) return [false, 'Empty package.'];
        if ($expected_sha256 !== '' && !hash_equals(strtolower($expected_sha256), hash('sha256', $bytes))) {
            return [false, 'Checksum mismatch — refusing to install.'];
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        WP_Filesystem();

        $tmp = wp_tempnam($slug . '.zip');
        if (!$tmp || file_put_contents($tmp, $bytes) === false) return [false, 'Could not write temp file.'];

        // Validate zip: every entry must live under "<slug>/", no traversal.
        if (!class_exists('ZipArchive')) { @unlink($tmp); return [false, 'ZipArchive not available on this host.']; }
        $za = new ZipArchive();
        if ($za->open($tmp) !== true) { @unlink($tmp); return [false, 'Not a valid zip.']; }
        for ($i = 0; $i < $za->numFiles; $i++) {
            $name = $za->getNameIndex($i);
            if (strpos($name, $slug . '/') !== 0 || strpos($name, '..') !== false) {
                $za->close(); @unlink($tmp);
                return [false, "Zip must contain only the {$slug}/ folder."];
            }
        }
        $za->close();

        $dir    = WP_PLUGIN_DIR . '/' . $slug;
        $backup = WP_PLUGIN_DIR . '/' . $slug . '.bak-' . gmdate('YmdHis');
        $had_dir = is_dir($dir);
        if ($had_dir) {
            if (!function_exists('copy_dir')) require_once ABSPATH . 'wp-admin/includes/file.php';
            $cp = copy_dir($dir, $backup);
            if (is_wp_error($cp)) { @unlink($tmp); return [false, 'Backup failed: ' . $cp->get_error_message()]; }
        }

        // Overwrite in place.
        $overwrite = function ($options) {
            $options['clear_destination'] = true;
            $options['abort_if_destination_exists'] = false;
            return $options;
        };
        add_filter('upgrader_package_options', $overwrite);
        $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
        $result = $upgrader->install($tmp);
        remove_filter('upgrader_package_options', $overwrite);
        @unlink($tmp);

        $ok = ($result === true);
        if (is_wp_error($result)) $ok = false;

        if (!$ok) {
            // roll back
            if ($had_dir && is_dir($backup)) {
                $fs_ok = true;
                if (is_dir($dir)) { $fs_ok = self::rmdir_recursive($dir); }
                if ($fs_ok) copy_dir($backup, $dir);
            }
            self::rmdir_recursive($backup);
            return [false, is_wp_error($result) ? $result->get_error_message() : 'Install failed — rolled back.'];
        }

        // success — keep the plugin active, clean up backup
        $main = $slug . '/' . $slug . '.php';
        if (function_exists('is_plugin_active') && !is_plugin_active($main) && $slug === 'ps-seo-console') {
            @activate_plugin($main);
        }
        if ($had_dir && is_dir($backup)) self::rmdir_recursive($backup);

        return [true, 'Installed.', self::installed_version($slug)];
    }

    /**
     * Pull model: fetch the manifest from the configured source, and if it names a
     * newer version, download + verify + install it. $do_install=false only reports.
     * Manifest JSON: {"slug","version","zip_url","sha256"}.
     */
    public static function check_remote($do_install = true, $slug = 'ps-seo-console') {
        $url = self::source_url();
        if ($url === '') return ['status' => 'no_source'];
        $headers = ['Accept' => 'application/json'];
        $tok = self::source_token();
        if ($tok !== '') $headers['Authorization'] = 'Bearer ' . $tok;

        $r = wp_remote_get(add_query_arg('_cb', time(), $url), ['timeout' => 20, 'headers' => $headers]);
        if (is_wp_error($r)) return ['status' => 'error', 'message' => $r->get_error_message()];
        if ((int) wp_remote_retrieve_response_code($r) !== 200) {
            return ['status' => 'error', 'message' => 'Manifest HTTP ' . wp_remote_retrieve_response_code($r)];
        }
        $m = json_decode((string) wp_remote_retrieve_body($r), true);
        if (!is_array($m) || empty($m['version']) || empty($m['zip_url'])) {
            return ['status' => 'error', 'message' => 'Manifest missing version/zip_url.'];
        }
        $mslug = sanitize_key($m['slug'] ?? $slug);
        if (!in_array($mslug, self::ALLOWED, true)) return ['status' => 'error', 'message' => 'Manifest slug not allowed.'];

        $current = self::current_version($mslug);
        $latest  = (string) $m['version'];
        if ($current !== '' && version_compare($latest, $current, '<=')) {
            return ['status' => 'up_to_date', 'current' => $current, 'latest' => $latest, 'slug' => $mslug];
        }
        if (!$do_install) {
            return ['status' => 'available', 'current' => $current, 'latest' => $latest, 'slug' => $mslug];
        }

        // download the package
        $zr = wp_remote_get(add_query_arg('_cb', time(), (string) $m['zip_url']), ['timeout' => 120, 'headers' => $tok !== '' ? ['Authorization' => 'Bearer ' . $tok] : []]);
        if (is_wp_error($zr)) return ['status' => 'error', 'message' => 'Download: ' . $zr->get_error_message()];
        if ((int) wp_remote_retrieve_response_code($zr) !== 200) {
            return ['status' => 'error', 'message' => 'Download HTTP ' . wp_remote_retrieve_response_code($zr)];
        }
        $bytes = (string) wp_remote_retrieve_body($zr);
        list($ok, $msg, $ver) = self::install_bytes($mslug, $bytes, (string) ($m['sha256'] ?? ''));
        return ['status' => $ok ? 'installed' : 'error', 'message' => $msg, 'current' => $current, 'latest' => $ver ?: $latest, 'slug' => $mslug];
    }

    /** Read the Version: header of the freshly installed main file. */
    private static function installed_version($slug) {
        $file = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
        if (!is_readable($file)) return '';
        $head = file_get_contents($file, false, null, 0, 4096);
        return preg_match('/^\s*\*\s*Version:\s*(.+)$/mi', (string) $head, $m) ? trim($m[1]) : '';
    }

    private static function rmdir_recursive($path) {
        if (!is_dir($path)) return true;
        $items = @scandir($path);
        if ($items === false) return false;
        foreach ($items as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $path . '/' . $it;
            if (is_dir($p)) self::rmdir_recursive($p); else @unlink($p);
        }
        return @rmdir($path);
    }
}
