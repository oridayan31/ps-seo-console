<?php
if (!defined('ABSPATH')) exit;

/**
 * Insights & recommendations. Reads the same live signals the Console computes
 * (audit groups, conversion funnel + gateways, GSC KPIs, Google status) and turns
 * them into ranked, plain-English findings with a recommended action — so the
 * dashboard surfaces "what's wrong + what to do", not just raw counts. Regenerates
 * from current data each load (cached 15m).
 */
class PSC_Insights {

    const CACHE = 'psc_insights';
    const RANK  = ['critical' => 0, 'warning' => 1, 'opportunity' => 2, 'info' => 3];

    public static function generate($force = false) {
        if (!$force) { $c = get_transient(self::CACHE); if (is_array($c)) return $c; }

        $ins = [];
        $groups = (PSC_Audit::get_signals()['groups'] ?? []);
        $count = function ($key) use ($groups) {
            foreach ($groups as $g) if (($g['key'] ?? '') === $key) return (int) ($g['count'] ?? 0);
            return 0;
        };

        // --- Merchant Center disapprovals ---
        if (($d = $count('gmc_disapproved')) > 0) {
            $ins[] = self::c('critical', "Merchant Center: {$d} products disapproved",
                "{$d} products are disapproved — blocked from Google Shopping (free + paid listings).",
                'Pull the disapproval reasons and fix the feed policy issue. Biggest revenue unlock.', 'conversion');
        }
        // --- noindex ---
        if (($n = $count('noindex')) > 0) {
            $ins[] = self::c('critical', "{$n} live pages set to noindex",
                "{$n} published pages tell Google not to index them — invisible in search.",
                'Review each; remove noindex on real pages (thank-you/cart pages are fine).', 'audit');
        }
        // --- technical blocker ---
        foreach ($groups as $g) {
            if (($g['key'] ?? '') === 'technical' && ($g['severity'] ?? '') === 'hi' && (int) ($g['count'] ?? 0) > 0) {
                $ins[] = self::c('critical', 'Site-level indexability blocker',
                    'A HTTPS, robots.txt, or XML-sitemap problem is blocking crawling/indexing.',
                    'Fix it first — nothing else ranks until crawling works.', 'audit');
            }
        }

        // --- Conversion: GA4 purchase gap + gateway concentration/failures ---
        $conv = class_exists('PSC_Conversion') ? PSC_Conversion::report(28) : null;
        if (is_array($conv)) {
            $f = $conv['funnel'] ?? [];
            $gw = $conv['gateways'] ?? [];
            $woo = (int) ($gw['window_orders'] ?? 0);
            if (($f['status'] ?? '') === 'ok') {
                $gp = (int) ($f['purchases'] ?? 0);
                if ($woo > 0 && $gp === 0) {
                    $ins[] = self::c('critical', 'GA4 is not recording purchases',
                        "WooCommerce had {$woo} orders recently but GA4 shows 0 purchases — revenue & conversion reporting is blind.",
                        'Fire the GA4 purchase event on the order-received page (GTM / PixelYourSite / GA4 ecommerce).', 'conversion');
                }
                if (($f['cart_abandonment'] ?? null) !== null && $f['cart_abandonment'] >= 80 && (int) ($f['add_to_carts'] ?? 0) >= 10) {
                    $ins[] = self::c('warning', 'High cart abandonment (' . $f['cart_abandonment'] . '%)',
                        'Most add-to-carts never complete checkout.',
                        'Check shipping-cost surprise, forced account creation, and gateway friction.', 'conversion');
                }
            }
            if (($gw['status'] ?? '') === 'ok' && $woo > 0) {
                $active = array_values(array_filter($gw['items'], function ($x) { return (int) ($x['orders'] ?? 0) > 0; }));
                if (count($active) === 1) {
                    $ins[] = self::c('warning', 'Only one payment method is being used',
                        "All {$woo} recent orders came through {$active[0]['title']}; other gateways sit idle.",
                        'Test that card / alternative checkout actually completes — 0 card sales while advertising may be lost revenue.', 'conversion');
                }
                foreach ($gw['items'] as $it) {
                    if (($it['health'] ?? '') === 'high_failures') {
                        $ins[] = self::c('critical', 'Payment gateway failing: ' . $it['title'],
                            ($it['fail_rate'] ?? 0) . '% of recent orders failed.',
                            'Check the gateway credentials / status now — this is lost revenue.', 'conversion');
                    }
                }
            }
        }

        // --- Search opportunities ---
        if (($sd = $count('gsc_striking')) > 0) {
            $ins[] = self::c('opportunity', "{$sd} pages one step from page 1",
                "{$sd} pages rank position 5–15 with real impressions.",
                'Strengthen content + internal links + titles to cross to page 1. Best traffic ROI.', 'audit');
        }
        if (($ctr = $count('gsc_ctr')) > 0) {
            $ins[] = self::c('opportunity', "{$ctr} pages: high impressions, low CTR",
                "{$ctr} pages get impressions but almost no clicks.",
                'Rewrite titles + meta descriptions to earn the click (META-FIX).', 'audit');
        }
        $k = class_exists('PSC_GSC') ? PSC_GSC::kpis() : null;
        if (is_array($k) && isset($k['ctr']['value'], $k['position']['value']) && $k['ctr']['value'] < 1.0 && $k['position']['value'] > 10) {
            $ins[] = self::c('opportunity', 'Sitewide CTR is low at page-2 positions',
                'CTR ' . $k['ctr']['value'] . '% at average position ' . $k['position']['value'] . ' — mostly page 2.',
                'Ranking pushes + better titles/meta are the levers.', 'overview');
        }

        // --- cleanup ---
        if (($m = $count('missing_meta_desc')) > 0) {
            $ins[] = self::c('warning', "{$m} pages missing meta descriptions",
                "{$m} pages have missing or short meta descriptions.",
                'Write unique, click-worthy summaries.', 'audit');
        }
        if (($a = $count('product_alt_text')) > 0) {
            $ins[] = self::c('info', "{$a} product images missing alt text",
                "{$a} images have no alt attribute.",
                'Add descriptive alt text (accessibility + image search).', 'audit');
        }

        // --- Google Search status (context) ---
        if (class_exists('PSC_GoogleStatus')) {
            foreach (PSC_GoogleStatus::active() as $i) {
                $ins[] = self::c('info', 'Google ' . $i['service'] . ' update in progress',
                    $i['title'] . ' — a ranking or traffic move right now may be Google-side.',
                    'Check this before attributing a change to your own work.', 'overview');
            }
        }

        usort($ins, function ($x, $y) { return (self::RANK[$x['severity']] ?? 9) <=> (self::RANK[$y['severity']] ?? 9); });
        set_transient(self::CACHE, $ins, 15 * MINUTE_IN_SECONDS);
        return $ins;
    }

    private static function c($severity, $title, $finding, $action, $tab) {
        return ['severity' => $severity, 'title' => $title, 'finding' => $finding, 'action' => $action, 'tab' => $tab];
    }
}
