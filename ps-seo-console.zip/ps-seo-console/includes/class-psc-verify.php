<?php
if (!defined('ABSPATH')) exit;

/**
 * Fix verification queue.
 * Every "Fix now" / approved fix lands here as PENDING. "Verify fixes (N)" re-scans each
 * fixed page live, confirms the specific issue is actually gone, and only then:
 *   - logs the change to the Changes→impact tracker (so its SEO effect gets measured),
 *   - updates the stored crawl result for that URL (so it drops off the need-to-fix lists),
 *   - clears the site-health cache.
 * Fixes that are NOT verified stay in the queue marked "still present".
 */
class PSC_Verify {

    const OPT = 'psc_pending_verify';

    public static function items() { $i = get_option(self::OPT, []); return is_array($i) ? $i : []; }
    public static function count() { return count(self::items()); }

    public static function queue($url, $code, $field, $value) {
        $items = self::items();
        // replace an older pending entry for the same url+code
        $items = array_values(array_filter($items, function ($i) use ($url, $code) { return !($i['url'] === $url && $i['code'] === $code); }));
        $items[] = ['id' => substr(md5($url . $code . microtime()), 0, 8), 'url' => $url, 'code' => $code,
                    'field' => $field, 'value' => mb_substr((string) $value, 0, 500), 'fixed_at' => current_time('mysql'), 'status' => 'pending'];
        update_option(self::OPT, array_slice($items, -60), false);
        return true;
    }

    /** Is the specific issue gone, judging from a fresh live scan of the page? */
    private static function issue_gone($item, $res) {
        $code = $item['code'];
        $codes = array_map(function ($x) { return is_array($x) ? ($x['c'] ?? '') : (string) $x; }, $res['issues'] ?? []);
        $cs = is_array($res['cs'] ?? null) ? $res['cs'] : [];
        switch ($code) {
            case 'stuffing':       return (float) ($cs['stuf'] ?? 0) < 3.5;
            case 'ai_content':     return (float) ($cs['fill'] ?? 0) < 3;
            case 'robotic':        return (int) ($cs['sents'] ?? 0) < 15 || (float) ($cs['svar'] ?? 99) >= 4;
            case 'generic_anchor': return (int) ($cs['ga'] ?? 0) < 5;
            case 'dense_links':
                $w = (int) ($res['words'] ?? 0); $lc = (int) ($res['lc'] ?? 0);
                if ($w <= 300) return true;
                $per100 = $lc / ($w / 100);
                return $per100 <= 10 && !($lc <= 1 && $w > 600);
            case 'duplicate': // verified when the canonical tag points at the chosen primary
                $r = wp_remote_get($item['url'], ['timeout' => 10, 'headers' => ['User-Agent' => 'PSC-Verify/1.0']]);
                $html = is_wp_error($r) ? '' : wp_remote_retrieve_body($r);
                return preg_match('#<link[^>]+rel=["\']canonical["\'][^>]+href=["\']' . preg_quote(untrailingslashit($item['value']), '#') . '/?["\']#i', $html)
                    || preg_match('#href=["\']' . preg_quote(untrailingslashit($item['value']), '#') . '/?["\'][^>]+rel=["\']canonical["\']#i', $html);
            default: // crawl issue codes (title_long, meta_missing, no_h1, thin, ...) — gone if the fresh scan no longer reports them
                return !in_array($code, $codes, true);
        }
    }

    /** Replace this URL's row in the stored crawl results so fix lists reflect reality. */
    private static function update_crawl_row($url, $res) {
        $state = get_option('psc_crawl_state', []);
        if (!is_array($state) || empty($state['results'])) return;
        foreach ($state['results'] as &$row) {
            if ($row['u'] === $url) {
                $row = ['u' => $url, 's' => $res['score'], 'n' => $res['noindex'] ?? false, 'i' => $res['issues'] ?? [],
                        'w' => $res['words'] ?? null, 'lc' => $res['lc'] ?? 0, 'sig' => $res['sig'] ?? '', 'cs' => $res['cs'] ?? []];
                break;
            }
        }
        unset($row);
        update_option('psc_crawl_state', $state, false);
    }

    private static $kind_map = ['title_long' => 'title', 'title_missing' => 'title', 'meta_missing' => 'meta', 'meta_long' => 'meta',
        'no_h1' => 'content', 'duplicate' => 'schema', 'stuffing' => 'content', 'ai_content' => 'content', 'robotic' => 'content',
        'thin' => 'content', 'dense_links' => 'internal_links', 'generic_anchor' => 'internal_links'];

    /** Verify everything pending: re-scan each fixed page live. */
    public static function run() {
        $items = self::items();
        if (!$items) return ['verified' => [], 'still' => [], 'remaining' => 0];
        $verified = []; $still = [];
        foreach ($items as $item) {
            $res = PSC_Crawl::check_page($item['url']);
            self::update_crawl_row($item['url'], $res);
            if (self::issue_gone($item, $res)) {
                if (class_exists('PSC_Changes')) PSC_Changes::add([
                    'title' => '✓ Verified fix: ' . $item['field'] . ' — ' . wp_parse_url($item['url'], PHP_URL_PATH),
                    'url' => $item['url'], 'kind' => self::$kind_map[$item['code']] ?? 'other',
                    'note' => 'Verified live on ' . current_time('Y-m-d H:i') . '. ' . $item['value'],
                ]);
                $verified[] = ['url' => preg_replace('#^https?://[^/]+#', '', $item['url']), 'field' => $item['field']];
            } else {
                $item['status'] = 'still_present'; $item['checked_at'] = current_time('mysql');
                $still[] = $item;
            }
        }
        update_option(self::OPT, $still, false);
        delete_transient('psc_site_health'); // fix lists recompute from the updated crawl rows
        return ['verified' => $verified, 'still' => array_map(function ($i) {
            return ['url' => preg_replace('#^https?://[^/]+#', '', $i['url']), 'field' => $i['field'], 'code' => $i['code']];
        }, $still), 'remaining' => count($still)];
    }
}
