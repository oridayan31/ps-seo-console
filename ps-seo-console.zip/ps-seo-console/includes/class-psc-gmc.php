<?php
if (!defined('ABSPATH')) exit;

/**
 * Merchant Center (Content API v2.1) — product statuses aggregated into feed
 * health: active / disapproved / expiring, plus disapproval reasons grouped.
 * Cached as a snapshot (feed health is a "now" value, not a trend).
 */
class PSC_GMC {

    const OPT_ID = 'psc_gmc_id';
    const CACHE  = 'psc_gmc_status';
    const API    = 'https://shoppingcontent.googleapis.com/content/v2.1';

    public static function get_id()  { return get_option(self::OPT_ID, ''); }
    public static function set_id($id) { update_option(self::OPT_ID, preg_replace('/[^0-9]/', '', (string) $id)); }

    public static function get_status($force = false) {
        if (!$force) {
            $c = get_transient(self::CACHE);
            if (is_array($c)) return $c;
        }
        return self::sync();
    }

    public static function sync() {
        $id = self::get_id();
        if (!PSC_Google::is_connected() || !$id) {
            return ['connected' => false, 'active' => 0, 'disapproved' => 0, 'expiring' => 0, 'total' => 0, 'reasons' => []];
        }
        $active = 0; $disapproved = 0; $limited = 0; $expiring = 0; $total = 0;
        $reasons = [];
        $pageToken = '';
        $guard = 0;
        do {
            $url = self::API . '/' . rawurlencode($id) . '/productstatuses?maxResults=250';
            if ($pageToken) $url .= '&pageToken=' . rawurlencode($pageToken);
            $r = PSC_Google::get($url);
            if (is_wp_error($r)) {
                return ['connected' => true, 'error' => $r->get_error_message(), 'active' => 0, 'disapproved' => 0, 'limited' => 0, 'expiring' => 0, 'total' => 0, 'reasons' => []];
            }
            foreach (($r['resources'] ?? []) as $p) {
                $total++;
                // A product is truly disapproved only if it's approved in NO country anywhere.
                // Approved in some-but-not-all targeted countries = "limited" (still serving), which
                // Merchant Center counts as Approved — not as "Not approved".
                $approved_anywhere = false;
                $disapproved_somewhere = false;
                foreach (($p['destinationStatuses'] ?? []) as $d) {
                    if (!empty($d['approvedCountries'])) $approved_anywhere = true;
                    if (($d['status'] ?? '') === 'disapproved' || !empty($d['disapprovedCountries'])) $disapproved_somewhere = true;
                }
                if (!$approved_anywhere) {
                    $disapproved++;
                    foreach (($p['itemLevelIssues'] ?? []) as $iss) {
                        if (($iss['servability'] ?? '') === 'disapproved') {
                            $code = $iss['code'] ?? 'other';
                            $reasons[$code] = ($reasons[$code] ?? 0) + 1;
                        }
                    }
                } elseif ($disapproved_somewhere) {
                    $limited++;
                } else {
                    $active++;
                }
            }
            $pageToken = $r['nextPageToken'] ?? '';
            $guard++;
        } while ($pageToken && $guard < 40);

        arsort($reasons);
        $payload = [
            'connected'   => true,
            'active'      => $active,
            'disapproved' => $disapproved,
            'limited'     => $limited,
            'expiring'    => $expiring,
            'total'       => $total,
            'reasons'     => $reasons,
            'synced_at'   => current_time('mysql'),
        ];
        set_transient(self::CACHE, $payload, DAY_IN_SECONDS);
        return $payload;
    }

    public static function debug_sample() {
        $id = self::get_id();
        if (!$id) return ['no_id' => true];
        $r = PSC_Google::get(self::API . '/' . rawurlencode($id) . '/productstatuses?maxResults=5');
        if (is_wp_error($r)) return ['error' => $r->get_error_message()];
        $out = ['returned' => count($r['resources'] ?? []), 'has_next' => !empty($r['nextPageToken']), 'samples' => []];
        foreach (array_slice($r['resources'] ?? [], 0, 5) as $p) {
            $out['samples'][] = [
                'destinationStatuses' => $p['destinationStatuses'] ?? [],
                'issues' => array_map(function ($i) { return ['code' => $i['code'] ?? '', 'servability' => $i['servability'] ?? '']; }, array_slice($p['itemLevelIssues'] ?? [], 0, 4)),
            ];
        }
        return $out;
    }
}
