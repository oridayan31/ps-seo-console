<?php
if (!defined('ABSPATH')) exit;

/**
 * GA4 Data API — daily sessions + purchase revenue by landing page.
 * Property discovery via the Admin API. Dated, self-provisioning, idempotent.
 */
class PSC_GA4 {

    const OPT_PROP = 'psc_ga4_property';
    const DATA  = 'https://analyticsdata.googleapis.com/v1beta';
    const ADMIN = 'https://analyticsadmin.googleapis.com/v1beta';

    public static function table() {
        global $wpdb; return $wpdb->prefix . 'psc_ga4_daily';
    }

    public static function ensure_table() {
        global $wpdb; $c = $wpdb->get_charset_collate(); $t = self::table();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t} (
            property VARCHAR(64) NOT NULL, day DATE NOT NULL, channel VARCHAR(64) NOT NULL DEFAULT '',
            sessions INT DEFAULT 0, users INT DEFAULT 0, revenue FLOAT DEFAULT 0,
            PRIMARY KEY (property, day, channel)
        ) {$c};");
    }

    public static function discover_properties() {
        $r = PSC_Google::get(self::ADMIN . '/accountSummaries');
        if (is_wp_error($r)) return $r;
        $out = [];
        foreach (($r['accountSummaries'] ?? []) as $acc) {
            foreach (($acc['propertySummaries'] ?? []) as $p) {
                if (!empty($p['property'])) {
                    $out[] = ['id' => $p['property'], 'name' => $p['displayName'] ?? $p['property']];
                }
            }
        }
        return $out;
    }

    public static function get_property() { return get_option(self::OPT_PROP, ''); }
    public static function set_property($p) { update_option(self::OPT_PROP, sanitize_text_field($p)); }

    public static function is_empty() {
        global $wpdb; $t = self::table();
        return 0 === (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t}");
    }

    public static function sync() {
        if (!PSC_Google::is_connected()) return new WP_Error('not_connected', 'Google not connected');
        $prop = self::get_property();
        if (!$prop) return new WP_Error('no_property', 'No GA4 property selected');
        self::ensure_table();
        $days  = self::is_empty() ? 90 : 30;
        $start = gmdate('Y-m-d', strtotime("-{$days} day"));
        $end   = 'today';

        $url = self::DATA . '/' . rawurlencode($prop) . ':runReport';
        $payload = [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date'], ['name' => 'sessionDefaultChannelGroup']],
            'metrics'    => [['name' => 'sessions'], ['name' => 'totalUsers'], ['name' => 'purchaseRevenue']],
            'limit'      => 10000,
        ];
        $r = PSC_Google::post($url, $payload);
        if (is_wp_error($r)) return $r;

        global $wpdb; $t = self::table();
        foreach (($r['rows'] ?? []) as $row) {
            $d = $row['dimensionValues'] ?? [];
            $m = $row['metricValues'] ?? [];
            $rawDay = $d[0]['value'] ?? '';
            if (strlen($rawDay) !== 8) continue;
            $day = substr($rawDay, 0, 4) . '-' . substr($rawDay, 4, 2) . '-' . substr($rawDay, 6, 2);
            $data = [
                'property' => $prop, 'day' => $day,
                'channel'  => mb_substr((string) ($d[1]['value'] ?? ''), 0, 60),
                'sessions' => (int) ($m[0]['value'] ?? 0),
                'users'    => (int) ($m[1]['value'] ?? 0),
                'revenue'  => (float) ($m[2]['value'] ?? 0),
            ];
            $sql = "INSERT INTO {$t} (property,day,channel,sessions,users,revenue) VALUES (%s,%s,%s,%d,%d,%f)
                    ON DUPLICATE KEY UPDATE sessions=VALUES(sessions),users=VALUES(users),revenue=VALUES(revenue)";
            $wpdb->query($wpdb->prepare($sql, $data['property'], $data['day'], $data['channel'], $data['sessions'], $data['users'], $data['revenue']));
        }
        update_option('psc_ga4_last_sync', current_time('mysql'));
        return true;
    }

    /** Organic revenue, last 28d vs prior 28d. */
    public static function organic_revenue_kpi() {
        global $wpdb;
        if (!PSC_Google::is_connected() || self::is_empty()) return null;
        $t = self::table(); $prop = self::get_property();
        $cur  = self::revenue_window($t, $prop, 28, 0);
        $prev = self::revenue_window($t, $prop, 28, 28);
        $delta = $prev > 0 ? round((($cur - $prev) / $prev) * 100, 1) : null;
        return ['value' => round($cur, 0), 'delta_pct' => $delta, 'dir' => $cur >= $prev ? 'up' : 'down'];
    }

    private static function revenue_window($t, $prop, $len, $offset) {
        global $wpdb;
        $end   = gmdate('Y-m-d', strtotime("-{$offset} day"));
        $start = gmdate('Y-m-d', strtotime("-" . ($len + $offset) . " day"));
        return (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(revenue),0) FROM {$t}
              WHERE property=%s AND day BETWEEN %s AND %s
                AND channel IN ('Organic Search','Organic Social','Organic Shopping')",
            $prop, $start, $end
        ));
    }

    /** Ecommerce funnel totals for the last N days: sessions → ATC → checkout → purchase. */
    public static function funnel($days = 28) {
        if (!PSC_Google::is_connected()) return new WP_Error('not_connected', 'Google not connected');
        $prop = self::get_property();
        if (!$prop) return new WP_Error('no_property', 'No GA4 property selected');
        $start = gmdate('Y-m-d', strtotime("-{$days} day"));
        $url = self::DATA . '/' . rawurlencode($prop) . ':runReport';
        $payload = [
            'dateRanges' => [['startDate' => $start, 'endDate' => 'today']],
            'metrics' => [
                ['name' => 'sessions'], ['name' => 'addToCarts'], ['name' => 'checkouts'],
                ['name' => 'ecommercePurchases'], ['name' => 'purchaseRevenue'],
            ],
        ];
        $r = PSC_Google::post($url, $payload);
        if (is_wp_error($r)) return $r;
        $m = $r['rows'][0]['metricValues'] ?? [];
        $sessions = (int) ($m[0]['value'] ?? 0);
        $atc = (int) ($m[1]['value'] ?? 0);
        $chk = (int) ($m[2]['value'] ?? 0);
        $pur = (int) ($m[3]['value'] ?? 0);
        $rev = (float) ($m[4]['value'] ?? 0);
        $rate = function ($n, $d) { return $d > 0 ? round($n / $d * 100, 1) : null; };
        return [
            'days' => $days, 'sessions' => $sessions, 'add_to_carts' => $atc, 'checkouts' => $chk,
            'purchases' => $pur, 'revenue' => round($rev, 2),
            'cr' => $rate($pur, $sessions),
            'atc_to_checkout' => $rate($chk, $atc),
            'checkout_to_purchase' => $rate($pur, $chk),
            'cart_abandonment' => $atc > 0 ? round((1 - $pur / $atc) * 100, 1) : null,
            'checkout_abandonment' => $chk > 0 ? round((1 - $pur / $chk) * 100, 1) : null,
        ];
    }
}
