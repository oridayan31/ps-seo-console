<?php
if (!defined('ABSPATH')) exit;

/**
 * Conversion analysis: the ecommerce funnel (from GA4), payment-gateway health
 * (from WooCommerce orders), and a checkout-configuration audit (from WooCommerce
 * settings). Cached so the tab is cheap to render; force=1 recomputes.
 */
class PSC_Conversion {

    const CACHE = 'psc_conversion_report';
    const MAX_ORDERS = 5000; // safety cap for the gateway tally window

    public static function report($days = 28, $force = false) {
        $days = max(7, min(90, (int) $days));
        $ck = self::CACHE . '_' . $days;
        if (!$force) {
            $cached = get_transient($ck);
            if (is_array($cached)) return $cached;
        }
        $report = [
            'days'         => $days,
            'funnel'       => self::funnel($days),
            'gateways'     => self::gateways($days),
            'checkout'     => self::checkout_audit(),
            'generated_at' => current_time('mysql'),
        ];
        set_transient($ck, $report, 30 * MINUTE_IN_SECONDS);
        return $report;
    }

    /* ---------------- funnel (GA4) ---------------- */

    private static function funnel($days) {
        if (!class_exists('PSC_GA4') || !class_exists('PSC_Google') || !PSC_Google::is_connected()) {
            return ['status' => 'needs_google', 'note' => 'Connect Google (GA4) in Settings to see the funnel.'];
        }
        $f = PSC_GA4::funnel($days);
        if (is_wp_error($f)) return ['status' => 'error', 'note' => $f->get_error_message()];
        $f['status'] = 'ok';
        return $f;
    }

    /* ---------------- gateway health (WooCommerce) ---------------- */

    private static function gateways($days) {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_orders')) {
            return ['status' => 'no_woo', 'items' => []];
        }
        $enabled = [];
        if (function_exists('WC') && WC()->payment_gateways()) {
            foreach (WC()->payment_gateways()->payment_gateways() as $id => $gw) {
                if (isset($gw->enabled) && $gw->enabled === 'yes') {
                    $enabled[$id] = $gw->get_title();
                }
            }
        }

        $rows = [];
        foreach ($enabled as $id => $title) {
            $rows[$id] = ['id' => $id, 'title' => $title, 'enabled' => true, 'orders' => 0, 'success' => 0, 'failed' => 0, 'revenue' => 0.0];
        }

        $since = gmdate('Y-m-d H:i:s', strtotime("-{$days} day"));
        $ids = wc_get_orders([
            'limit'        => self::MAX_ORDERS,
            'date_created' => '>=' . $since,
            'return'       => 'ids',
            'orderby'      => 'date',
            'order'        => 'DESC',
        ]);
        $counted = 0;
        foreach ((array) $ids as $oid) {
            $o = wc_get_order($oid);
            if (!$o || !is_callable([$o, 'get_payment_method'])) continue; // refunds (WC_Order_Refund) have no payment method — skip
            $counted++;
            $pm = $o->get_payment_method();
            if (!$pm) $pm = '(none)';
            if (!isset($rows[$pm])) {
                $rows[$pm] = ['id' => $pm, 'title' => $o->get_payment_method_title() ?: $pm, 'enabled' => false, 'orders' => 0, 'success' => 0, 'failed' => 0, 'revenue' => 0.0];
            }
            $status = $o->get_status();
            $rows[$pm]['orders']++;
            if (in_array($status, ['completed', 'processing', 'on-hold'], true)) {
                $rows[$pm]['success']++;
                $rows[$pm]['revenue'] += (float) $o->get_total();
            } elseif ($status === 'failed') {
                $rows[$pm]['failed']++;
            }
        }

        foreach ($rows as &$r) {
            $r['revenue'] = round($r['revenue'], 2);
            $r['fail_rate'] = $r['orders'] > 0 ? round($r['failed'] / $r['orders'] * 100, 1) : 0.0;
            if ($r['enabled'] && $r['orders'] === 0) {
                $r['health'] = 'idle';
                $r['flag'] = 'Enabled but no orders in the window — confirm it still works.';
            } elseif ($r['fail_rate'] >= 15) {
                $r['health'] = 'high_failures';
                $r['flag'] = $r['fail_rate'] . '% of orders failed — check credentials / gateway status.';
            } else {
                $r['health'] = 'ok';
                $r['flag'] = '';
            }
        }
        unset($r);

        // sort by revenue desc
        uasort($rows, function ($a, $b) { return $b['revenue'] <=> $a['revenue']; });

        return ['status' => 'ok', 'window_orders' => $counted, 'items' => array_values($rows)];
    }

    /* ---------------- checkout config audit (WooCommerce) ---------------- */

    private static function checkout_audit() {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_page_id')) {
            return ['status' => 'no_woo', 'checks' => []];
        }
        $checks = [];

        $cid = wc_get_page_id('checkout');
        $checks[] = ($cid > 0 && get_post_status($cid) === 'publish')
            ? self::chk('P0', 'PASS', 'Checkout page is set and published.')
            : self::chk('P0', 'FAIL', 'No published checkout page set.', 'Set it under WooCommerce → Settings → Advanced → Page setup.');

        $cart = wc_get_page_id('cart');
        $checks[] = ($cart > 0 && get_post_status($cart) === 'publish')
            ? self::chk('P2', 'PASS', 'Cart page is set and published.')
            : self::chk('P2', 'WARN', 'No published cart page set.', 'Set the cart page so the cart step is reachable.');

        $n_enabled = 0;
        if (function_exists('WC') && WC()->payment_gateways()) {
            foreach (WC()->payment_gateways()->payment_gateways() as $gw) {
                if (isset($gw->enabled) && $gw->enabled === 'yes') $n_enabled++;
            }
        }
        $checks[] = $n_enabled >= 1
            ? self::chk('P0', 'PASS', "{$n_enabled} payment gateway(s) enabled.")
            : self::chk('P0', 'FAIL', 'No payment gateways enabled — checkout cannot complete.', 'Enable at least one gateway.');

        $guest = get_option('woocommerce_enable_guest_checkout');
        $checks[] = ($guest === 'yes')
            ? self::chk('P1', 'PASS', 'Guest checkout is enabled.')
            : self::chk('P1', 'WARN', 'Guest checkout is disabled — forcing account creation adds friction.', 'Allow guest checkout unless there is a strong reason not to.');

        $https = strpos(home_url(), 'https://') === 0;
        $checks[] = $https
            ? self::chk('P0', 'PASS', 'Store is served over HTTPS.')
            : self::chk('P0', 'FAIL', 'Store is not fully HTTPS — payment pages must be secure.', 'Force HTTPS site-wide.');

        // terms & conditions page (trust / legal at checkout)
        $terms = (int) get_option('woocommerce_terms_page_id');
        $checks[] = ($terms > 0)
            ? self::chk('P3', 'PASS', 'Terms & conditions page is configured.')
            : self::chk('P3', 'WARN', 'No terms & conditions page set for checkout.', 'Add one for trust and legal cover.');

        // account creation friction: require password / account at checkout
        $must_login = get_option('woocommerce_enable_checkout_login_reminder');
        // (informational only; not scored)

        $fails = 0; $warns = 0;
        foreach ($checks as $c) { if ($c['status'] === 'FAIL') $fails++; elseif ($c['status'] === 'WARN') $warns++; }
        $verdict = $fails > 0 ? 'Blocking issue' : ($warns > 0 ? 'Minor friction' : 'Clean');

        return ['status' => 'ok', 'verdict' => $verdict, 'fails' => $fails, 'warns' => $warns, 'checks' => $checks];
    }

    private static function chk($priority, $status, $finding, $action = '') {
        return ['priority' => $priority, 'status' => $status, 'finding' => $finding, 'action' => $action];
    }
}
