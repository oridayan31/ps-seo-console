<?php
if (!defined('ABSPATH')) exit;

/**
 * Admin UI: one top-level page with tabs (Board · Audit · Overview · Settings),
 * rendered in the Pulse "lite" skin. Assets load ONLY on this page — zero
 * storefront footprint.
 */
class PSC_Admin {

    const SLUG = 'ps-seo-console';
    const OPT  = 'psc_settings';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('admin_init', [__CLASS__, 'maybe_save_settings']);
    }

    public static function settings() {
        $defaults = ['merchant_id' => '', 'scan_time' => '06:30'];
        $opt = get_option(self::OPT, []);
        return wp_parse_args(is_array($opt) ? $opt : [], $defaults);
    }

    public static function menu() {
        add_menu_page(
            'SEO Console', 'SEO Console', 'manage_options', self::SLUG,
            [__CLASS__, 'render'], 'dashicons-chart-line', 58
        );
    }

    public static function assets($hook) {
        if ($hook !== 'toplevel_page_' . self::SLUG) return; // our page only
        wp_enqueue_style(
            'psc-fonts',
            'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Heebo:wght@400;500;700&family=DM+Serif+Display&display=swap',
            [], null
        );
        wp_enqueue_style('psc-console', PSC_URL . 'admin/css/console.css', [], PSC_VERSION);
        wp_enqueue_script('psc-console', PSC_URL . 'admin/js/console.js', [], PSC_VERSION, true);
        wp_localize_script('psc-console', 'PSC', [
            'rest'  => esc_url_raw(rest_url(PSC_REST_NS)),
            'nonce' => wp_create_nonce('wp_rest'),
            'page'  => admin_url('admin.php?page=' . self::SLUG),
        ]);
    }

    public static function maybe_save_settings() {
        if (!current_user_can('manage_options')) return;
        $notice = null;

        // 1) Connect Google (paste SA JSON)
        if (!empty($_POST['psc_connect_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_connect_nonce'])), 'psc_connect')) {
            $json = isset($_POST['sa_json']) ? trim((string) wp_unslash($_POST['sa_json'])) : '';
            list($ok, $msg) = PSC_Google::save_sa($json);
            if ($ok) { PSC_GSC::sync(); PSC_GMC::sync(); }
            $notice = [$ok ? 'success' : 'error', $msg];
        }

        // 2) Disconnect
        if (!empty($_POST['psc_disconnect_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_disconnect_nonce'])), 'psc_disconnect')) {
            PSC_Google::disconnect();
            $notice = ['success', 'Google disconnected.'];
        }

        // 3) Settings + scheduler
        if (!empty($_POST['psc_settings_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_settings_nonce'])), 'psc_save_settings')) {
            $opt = self::settings();
            $scan = isset($_POST['scan_time']) ? sanitize_text_field(wp_unslash($_POST['scan_time'])) : '06:30';
            $opt['scan_time'] = preg_match('/^\d{1,2}:\d{2}$/', $scan) ? $scan : '06:30';
            update_option(self::OPT, $opt);

            if (isset($_POST['merchant_id']))  PSC_GMC::set_id((string) wp_unslash($_POST['merchant_id']));
            if (!empty($_POST['gsc_site']))     PSC_GSC::set_site((string) wp_unslash($_POST['gsc_site']));
            if (!empty($_POST['ga4_property'])) PSC_GA4::set_property((string) wp_unslash($_POST['ga4_property']));

            if (isset($_POST['rules']) && is_array($_POST['rules'])) {
                PSC_Watchers::save_rules(wp_unslash($_POST['rules']));
            }
            $notice = ['success', 'Settings saved.'];
        }

        // 4) Connectors (DataForSEO / PageSpeed / Anthropic)
        if (!empty($_POST['psc_connectors_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_connectors_nonce'])), 'psc_connectors')) {
            $dl = isset($_POST['dfs_login']) ? trim((string) wp_unslash($_POST['dfs_login'])) : '';
            $dp = isset($_POST['dfs_password']) ? trim((string) wp_unslash($_POST['dfs_password'])) : '';
            if ($dl !== '' || $dp !== '') PSC_Connectors::set_dataforseo($dl, $dp);
            $psi = isset($_POST['psi_key']) ? trim((string) wp_unslash($_POST['psi_key'])) : '';
            if ($psi !== '') PSC_Connectors::set_pagespeed($psi);
            $ant = isset($_POST['ant_key']) ? trim((string) wp_unslash($_POST['ant_key'])) : '';
            if ($ant !== '') PSC_Connectors::set_anthropic($ant);
            $notice = ['success', 'Connectors saved.'];
        }

        // 5) Auto-update token
        if (!empty($_POST['psc_update_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_update_nonce'])), 'psc_update')) {
            $tok = isset($_POST['psc_update_token']) ? trim((string) wp_unslash($_POST['psc_update_token'])) : '';
            if ($tok !== '') {
                list($ok, $msg) = PSC_Updater::set_token($tok);
                $notice = [$ok ? 'success' : 'error', $msg];
            }
        }

        // 6) Email alerts
        if (!empty($_POST['psc_alerts_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_alerts_nonce'])), 'psc_alerts')) {
            PSC_Alerts::save_settings(
                !empty($_POST['alerts_enabled']),
                isset($_POST['alerts_to']) ? trim((string) wp_unslash($_POST['alerts_to'])) : '',
                isset($_POST['alerts_tier']) ? sanitize_key((string) wp_unslash($_POST['alerts_tier'])) : 'critical'
            );
            $notice = ['success', 'Alert settings saved.'];
        }

        // 7) Automatic updates (pull source)
        if (!empty($_POST['psc_autoupdate_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_autoupdate_nonce'])), 'psc_autoupdate')) {
            $src = isset($_POST['update_source']) ? trim((string) wp_unslash($_POST['update_source'])) : '';
            $tok = isset($_POST['update_source_token']) ? trim((string) wp_unslash($_POST['update_source_token'])) : null;
            PSC_Updater::save_source($src, ($tok === '' ? null : $tok), !empty($_POST['update_auto']));
            $notice = ['success', 'Automatic-update source saved.'];
        }

        // 8) Google OAuth client (sign-in)
        if (!empty($_POST['psc_oauth_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['psc_oauth_nonce'])), 'psc_oauth')) {
            PSC_OAuth::save_client(
                isset($_POST['oauth_client_id']) ? wp_unslash($_POST['oauth_client_id']) : '',
                isset($_POST['oauth_client_secret']) ? wp_unslash($_POST['oauth_client_secret']) : ''
            );
            $notice = ['success', 'Google sign-in credentials saved. Now click Connect with Google.'];
        }

        if ($notice) {
            add_action('admin_notices', function () use ($notice) {
                printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
                    esc_attr($notice[0]), esc_html($notice[1]));
            });
        }
    }

    private static function current_tab() {
        $tab = isset($_GET['tab']) ? sanitize_key((string) $_GET['tab']) : 'board';
        return in_array($tab, ['board', 'audit', 'overview', 'conversion', 'competitors', 'settings'], true) ? $tab : 'board';
    }

    public static function tab_url($tab) {
        return admin_url('admin.php?page=' . self::SLUG . '&tab=' . $tab);
    }

    public static function render() {
        if (!current_user_can('manage_options')) return;
        $tab      = self::current_tab();
        $progress = PSC_DB::progress();
        $signals  = PSC_Audit::get_signals();
        $settings = self::settings();

        echo '<div class="wrap psc-wrap"><div class="psc" data-theme="light">';
        self::header($tab, $signals);

        $view = PSC_DIR . 'admin/views/' . $tab . '.php';
        if (file_exists($view)) {
            include $view; // $progress, $signals, $settings available in scope
        }

        echo '<div class="psc-note"><strong>Phase 1 · local data.</strong> Board and audit run on data already inside WordPress. Connect Google in Settings to light up Search Console, GA4 and Merchant Center metrics (Phase 2).</div>';
        echo '</div></div>';
    }

    private static function header($tab, $signals) {
        $opps = isset($signals['summary']['opportunities']) ? (int) $signals['summary']['opportunities'] : 0;
        ?>
        <div class="psc-head">
            <h1 class="psc-title">PS SEO Console</h1>
            <button class="psc-themebtn" type="button" onclick="pscToggleTheme()" title="Toggle theme">🌙</button>
        </div>
        <p class="psc-subtitle">Your live SEO program — metrics, board, audit, and connections in one place.</p>
        <div class="psc-tabs">
            <a class="psc-tab <?php echo $tab==='board'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('board')); ?>">Board</a>
            <a class="psc-tab <?php echo $tab==='audit'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('audit')); ?>">Audit<?php if($opps): ?> <span class="psc-b"><?php echo esc_html($opps); ?></span><?php endif; ?></a>
            <a class="psc-tab <?php echo $tab==='overview'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('overview')); ?>">Overview</a>
            <a class="psc-tab <?php echo $tab==='conversion'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('conversion')); ?>">Conversion</a>
            <a class="psc-tab <?php echo $tab==='competitors'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('competitors')); ?>">Competitors</a>
            <a class="psc-tab <?php echo $tab==='settings'?'active':''; ?>" href="<?php echo esc_url(self::tab_url('settings')); ?>">Settings</a>
        </div>
        <?php
    }

    /* ---- shared render helpers used by views ---- */

    public static function kpi_row() {
        $kpis = class_exists('PSC_GSC') ? PSC_GSC::kpis() : null;
        if (!$kpis) {
            $locked = ['Clicks · 28d', 'Impressions · 28d', 'Avg CTR', 'Avg position'];
            echo '<div class="psc-kpis">';
            foreach ($locked as $lab) {
                echo '<div class="psc-kpi locked"><div class="psc-lab">' . esc_html($lab) . ' <span class="psc-src">GSC</span></div>';
                echo '<div class="psc-val muted">—</div><div class="psc-foot"><span class="psc-lockhint">🔒 connect Google</span></div></div>';
            }
            echo '</div>';
            return;
        }
        $c = $kpis['clicks']; $i = $kpis['impressions']; $ctr = $kpis['ctr']; $pos = $kpis['position'];
        $box = function ($lab, $val, $deltaHtml, $dir) {
            $cls = $dir === 'up' ? 'up' : 'down';
            echo '<div class="psc-kpi"><div class="psc-lab">' . esc_html($lab) . ' <span class="psc-src">GSC</span></div>';
            echo '<div class="psc-val">' . esc_html($val) . '</div><div class="psc-foot">';
            echo '<span class="psc-delta ' . esc_attr($cls) . '">' . $deltaHtml . '</span></div></div>';
        };
        echo '<div class="psc-kpis">';
        $box('Clicks · 28d', number_format((int) $c['value']),
            ($c['dir'] === 'up' ? '▲ ' : '▼ ') . ($c['delta_pct'] === null ? '—' : esc_html($c['delta_pct']) . '%'), $c['dir']);
        $box('Impressions · 28d', self::hnum((int) $i['value']),
            ($i['dir'] === 'up' ? '▲ ' : '▼ ') . ($i['delta_pct'] === null ? '—' : esc_html($i['delta_pct']) . '%'), $i['dir']);
        $box('Avg CTR', esc_html($ctr['value']) . '%',
            ($ctr['dir'] === 'up' ? '▲ ' : '▼ ') . esc_html($ctr['delta_pt']) . 'pt', $ctr['dir']);
        $box('Avg position', esc_html($pos['value']),
            ($pos['dir'] === 'up' ? '↑ ' : '↓ ') . ($pos['delta'] === null ? '—' : esc_html(abs($pos['delta'])) . ' ' . ($pos['dir'] === 'up' ? 'better' : 'worse')), $pos['dir']);
        echo '</div>';
    }

    private static function hnum($n) {
        return $n >= 1000 ? round($n / 1000, 1) . 'k' : (string) $n;
    }

    public static function esc_prompt($text) {
        return esc_html($text);
    }
}
