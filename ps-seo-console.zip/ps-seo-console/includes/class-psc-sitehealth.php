<?php
if (!defined('ABSPATH')) exit;

/**
 * Site-wide SEO health analyzers built on the crawl graph + GSC:
 *  - content_health(): depth + uniqueness (thin, duplicate content, no-H1, missing meta) — not the AI check.
 *  - link_health(): internal-link graph — orphans, under-linked ranking pages, links wasted on dead/tag pages, over-linking.
 *  - consolidation(): cannibalization (one query, many pages), thin tag/archive pages to noindex, duplicate pages to merge.
 * Covers every page type the crawl visits (products, categories, tags, collections, pages, posts).
 */
class PSC_SiteHealth {

    const CACHE = 'psc_site_health';

    private static function crawl() { $s = get_option('psc_crawl_state', []); return is_array($s) ? $s : []; }
    private static function path($url) { $p = wp_parse_url($url, PHP_URL_PATH); return $p ? rtrim($p, '/') : ''; }
    private static function short($url) { return preg_replace('#^https?://[^/]+#', '', $url); }

    private static function gsc_clicks_by_path() {
        global $wpdb;
        $map = [];
        if (class_exists('PSC_GSC') && PSC_Google::is_connected() && !PSC_GSC::is_empty()) {
            $t = $wpdb->prefix . 'psc_gsc_pages'; $site = PSC_GSC::get_site();
            $rows = $wpdb->get_results($wpdb->prepare("SELECT page, SUM(clicks) c FROM {$t} WHERE site_url=%s AND day >= %s GROUP BY page", $site, gmdate('Y-m-d', strtotime('-28 day'))), ARRAY_A);
            foreach ((array) $rows as $r) $map[self::path($r['page'])] = (int) $r['c'];
        }
        return $map;
    }

    public static function all($force = false) {
        if (!$force) { $c = get_transient(self::CACHE); if (is_array($c)) return $c; }
        $out = ['content' => self::content_health(), 'links' => self::link_health(), 'consolidation' => self::consolidation(),
                'crawl_ready' => !empty(self::crawl()['results'])];
        if (empty(self::crawl()['running'])) set_transient(self::CACHE, $out, 6 * HOUR_IN_SECONDS); // don't freeze partial results mid-crawl
        return $out;
    }

    /* ---------------- content health (depth + uniqueness + genuineness) ---------------- */

    // Editorial length ranges per template (from Google-aligned guidance; min = flag threshold)
    const LEN = ['Single product' => [100, 800], 'Product category' => [80, 600], 'Category archive' => [80, 600],
                 'Collection page' => [120, 1200], 'Blog post' => [400, 4500], 'Page' => [150, 4000], 'Homepage' => [200, 1500]];

    public static function content_health() {
        $res = self::crawl()['results'] ?? [];
        if (!$res) return ['status' => 'no_crawl'];
        $slugmap = class_exists('PSC_Crawl') ? PSC_Crawl::slugmap() : [];
        $thin = []; $noh1 = []; $nometa = []; $sigmap = [];
        $ai_flagged = []; $stuffed = []; $robotic = []; $short_tpl = [];
        foreach ($res as $r) {
            if (($r['s'] ?? null) === null) continue;
            $u = self::short($r['u']); $w = (int) ($r['w'] ?? 0);
            $tpl = PSC_Crawl::template_of($r['u'], $slugmap);
            $codes = array_map(function ($x) { return is_array($x) ? ($x['c'] ?? '') : $x; }, $r['i'] ?? []);
            if (in_array('no_h1', $codes, true)) $noh1[] = ['url' => $u, 'full' => $r['u'], 'template' => $tpl];
            if (in_array('meta_missing', $codes, true)) $nometa[] = ['url' => $u, 'full' => $r['u'], 'template' => $tpl];
            $sig = $r['sig'] ?? ''; if ($sig) { $sigmap[$sig][] = $u; }
            // length vs template expectation (no universal word count — judged per page type)
            $range = self::LEN[$tpl] ?? [120, 5000];
            if ($w > 0 && $w < $range[0]) { $thin[] = ['url' => $u, 'full' => $r['u'], 'words' => $w, 'template' => $tpl, 'expect' => $range[0] . '+']; }
            // genuineness signals captured during the deep crawl
            $cs = is_array($r['cs'] ?? null) ? $r['cs'] : [];
            $isContent = in_array($tpl, ['Blog post', 'Collection page', 'Page', 'Product category', 'Homepage'], true);
            if ($isContent && $w > 250) {
                if ((float) ($cs['fill'] ?? 0) >= 3) $ai_flagged[] = ['url' => $u, 'full' => $r['u'], 'template' => $tpl, 'why' => 'AI-filler phrasing (' . $cs['fill'] . ' stock phrases per 1k words) — rewrite in a first-hand curator voice'];
                if ((float) ($cs['stuf'] ?? 0) >= 3.5) $stuffed[] = ['url' => $u, 'full' => $r['u'], 'template' => $tpl, 'why' => 'Keyword stuffing — ' . (!empty($cs['stufw']) ? '“' . $cs['stufw'] . '” alone is ' : 'one word is ') . $cs['stuf'] . '% of all text' . (!empty($cs['stufw']) ? '' : ' (re-scan to see which word)')];
                if ((int) ($cs['sents'] ?? 0) >= 15 && (float) ($cs['svar'] ?? 99) > 0 && (float) ($cs['svar'] ?? 99) < 4) $robotic[] = ['url' => $u, 'full' => $r['u'], 'template' => $tpl, 'why' => 'Uniform machine-like sentence rhythm — vary sentence length, add specifics'];
            }
        }
        $dups = [];
        foreach ($sigmap as $urls) if (count($urls) > 1) $dups[] = $urls;
        $total = count($res);
        $genuineness_flags = count($ai_flagged) + count($stuffed) + count($robotic);
        $bad = count($thin) + count($noh1) + count($nometa) + array_sum(array_map('count', $dups)) + $genuineness_flags * 2;
        $score = $total ? max(0, min(100, (int) round(100 - ($bad / max(1, $total)) * 130))) : null;
        usort($thin, function ($a, $b) { return $a['words'] <=> $b['words']; });
        $a = [];
        if ($ai_flagged || $robotic) $a[] = ($genuineness_flags) . ' pages read AI-generated (stock phrasing / uniform rhythm) — Google\'s scaled-content policy risk. Rewrite with first-hand specifics: curation choices, materials (310gsm archival giclée), sizing, real room pairings.';
        if ($stuffed) $a[] = count($stuffed) . ' pages keyword-stuff — cut repetition, write for the reader.';
        if ($thin)  $a[] = count($thin) . ' pages are under their template\'s useful length — add genuine depth (specs, fit, use, curation) or consolidate. No padding: right length = shortest that fully serves the query.';
        if ($dups)  $a[] = count($dups) . ' groups of near-identical content — rewrite to be unique or canonicalize to the primary.';
        if ($noh1)  $a[] = count($noh1) . ' pages have no H1.';
        if ($nometa)$a[] = count($nometa) . ' pages missing meta descriptions.';
        return ['status' => 'ok', 'score' => $score, 'total' => $total,
                'ai_count' => count($ai_flagged), 'ai' => array_slice($ai_flagged, 0, 12),
                'stuffed_count' => count($stuffed), 'stuffed' => array_slice($stuffed, 0, 12),
                'robotic_count' => count($robotic), 'robotic' => array_slice($robotic, 0, 10),
                'thin_count' => count($thin), 'thin' => array_slice($thin, 0, 15),
                'duplicate_groups' => count($dups), 'duplicates' => array_slice($dups, 0, 10),
                'no_h1' => count($noh1), 'no_h1_list' => array_slice($noh1, 0, 10),
                'missing_meta' => count($nometa), 'missing_meta_list' => array_slice($nometa, 0, 15),
                'actions' => $a];
    }

    /* ---------------- internal linking health ---------------- */
    public static function link_health() {
        $s = self::crawl(); $res = $s['results'] ?? []; $inbound = $s['inbound'] ?? [];
        if (!$res) return ['status' => 'no_crawl'];
        if (empty($inbound)) return ['status' => 'no_links', 'note' => 'Re-crawl the site to build the internal-link graph.'];
        $clicks = self::gsc_clicks_by_path();
        $noindex_paths = [];
        foreach ($res as $r) if (!empty($r['n'])) $noindex_paths[self::path($r['u'])] = 1;
        $slugmap = class_exists('PSC_Crawl') ? PSC_Crawl::slugmap() : [];
        $over = []; $orphans = []; $underlinked = []; $dense = []; $generic = [];
        foreach ($res as $r) {
            if (($r['s'] ?? null) === null) continue;
            $p = self::path($r['u']); $lc = (int) ($r['lc'] ?? 0); $inb = (int) ($inbound[$p] ?? 0);
            $w = (int) ($r['w'] ?? 0); $cs = is_array($r['cs'] ?? null) ? $r['cs'] : [];
            $tpl = PSC_Crawl::template_of($r['u'], $slugmap);
            if ($lc > 150) $over[] = ['url' => self::short($r['u']), 'links' => $lc];
            if ($inb === 0 && $p !== '' && !preg_match('#/(tag|category|product-category|product-tag|author|page)/#i', $r['u'])) $orphans[] = ['url' => self::short($r['u']), 'full' => $r['u']];
            $c = (int) ($clicks[$p] ?? 0);
            if ($c >= 3 && $inb < 3) $underlinked[] = ['url' => self::short($r['u']), 'full' => $r['u'], 'clicks' => $c, 'inbound' => $inb];
            // naturalness: in-copy link density + anchor quality on content pages
            if (in_array($tpl, ['Blog post', 'Page', 'Collection page'], true) && $w > 300) {
                $per100 = round($lc / ($w / 100), 1);
                if ($per100 > 10) $dense[] = ['url' => self::short($r['u']), 'full' => $r['u'], 'ratio' => $per100, 'why' => $per100 . ' links per 100 words — reads like a link farm; keep only contextual links'];
                if ($lc <= 1 && $w > 600) $dense[] = ['url' => self::short($r['u']), 'full' => $r['u'], 'ratio' => $per100, 'why' => 'Long content with almost no internal links — add 2-4 contextual links to related collections/products'];
            }
            if ((int) ($cs['ga'] ?? 0) >= 5) $generic[] = ['url' => self::short($r['u']), 'full' => $r['u'], 'count' => (int) $cs['ga'], 'why' => $cs['ga'] . ' generic anchors ("click here"/"read more") — use descriptive anchor text'];
        }
        $wasted = [];
        foreach ($inbound as $path => $cnt) {
            $isdead = isset($noindex_paths[$path]) || preg_match('#/(tag|product-tag)/#i', $path);
            if ($isdead && $cnt > 0 && (int) ($clicks[$path] ?? 0) === 0) $wasted[] = ['path' => $path, 'inbound' => (int) $cnt];
        }
        usort($over, function ($a, $b) { return $b['links'] <=> $a['links']; });
        usort($wasted, function ($a, $b) { return $b['inbound'] <=> $a['inbound']; });
        usort($underlinked, function ($a, $b) { return $b['clicks'] <=> $a['clicks']; });
        $total = count($res);
        $bad = count($over) + count($orphans) + count($wasted) + count($underlinked) + count($dense) + count($generic);
        $score = $total ? max(0, min(100, (int) round(100 - ($bad / max(1, $total)) * 120))) : null;
        $a = [];
        if ($underlinked) $a[] = count($underlinked) . ' ranking pages are under-linked (real clicks, <3 internal links in) — add contextual links to them from related pages. Highest link ROI.';
        if ($orphans)     $a[] = count($orphans) . ' orphan pages (nothing links to them) — link from a relevant hub/collection so they get crawled and pass equity.';
        if ($wasted)      $a[] = count($wasted) . ' dead targets (noindex/tag pages with no rank) are receiving internal links — repoint those to real ranking pages to stop leaking equity.';
        if ($dense)       $a[] = count($dense) . ' content pages have unnatural in-copy linking (too dense or none at all) — aim for a few descriptive, contextual links per piece.';
        if ($generic)     $a[] = count($generic) . ' pages lean on generic anchors — switch to descriptive anchor text so the link explains its destination.';
        if ($over)        $a[] = count($over) . ' pages carry 150+ links — trim so equity stays focused and links read naturally.';
        return ['status' => 'ok', 'score' => $score, 'total' => $total,
                'underlinked_count' => count($underlinked), 'underlinked' => array_slice($underlinked, 0, 12),
                'orphan_count' => count($orphans), 'orphans' => array_slice($orphans, 0, 15),
                'wasted_count' => count($wasted), 'wasted' => array_slice($wasted, 0, 12),
                'dense_count' => count($dense), 'dense' => array_slice($dense, 0, 12),
                'generic_count' => count($generic), 'generic' => array_slice($generic, 0, 10),
                'over_count' => count($over), 'over' => array_slice($over, 0, 10), 'actions' => $a];
    }

    /* ---------------- consolidation / cannibalization ---------------- */
    public static function consolidation() {
        $res = self::crawl()['results'] ?? [];
        $pairs = class_exists('PSC_GSC') ? PSC_GSC::query_page_pairs(28, 1500) : [];
        $byq = [];
        foreach ($pairs as $row) {
            $q = $row['keys'][0] ?? ''; $pg = $row['keys'][1] ?? '';
            if ($q === '' || $pg === '') continue;
            $byq[$q][] = ['page' => self::short($pg), 'clicks' => (int) ($row['clicks'] ?? 0), 'impr' => (int) ($row['impressions'] ?? 0), 'pos' => round((float) ($row['position'] ?? 0), 1)];
        }
        $cannib = [];
        foreach ($byq as $q => $pages) {
            if (count($pages) >= 2) {
                $imp = array_sum(array_map(function ($x) { return $x['impr']; }, $pages));
                if ($imp >= 20) { usort($pages, function ($a, $b) { return $b['clicks'] <=> $a['clicks']; }); $cannib[] = ['query' => $q, 'pages' => array_slice($pages, 0, 4), 'impr' => $imp]; }
            }
        }
        usort($cannib, function ($a, $b) { return $b['impr'] <=> $a['impr']; });

        $clicks = self::gsc_clicks_by_path();
        $thin_tags = [];
        foreach ($res as $r) if (preg_match('#/(tag|product-tag)/#i', $r['u']) && (int) ($clicks[self::path($r['u'])] ?? 0) === 0) $thin_tags[] = self::short($r['u']);

        $sigmap = [];
        foreach ($res as $r) { $sig = $r['sig'] ?? ''; if ($sig) $sigmap[$sig][] = self::short($r['u']); }
        $dups = []; foreach ($sigmap as $urls) if (count($urls) > 1) $dups[] = $urls;

        $a = [];
        if ($cannib)    $a[] = count($cannib) . ' queries have multiple pages competing — pick one primary per query, canonicalize/merge the rest, and consolidate internal links + content into the winner.';
        if ($thin_tags) $a[] = count($thin_tags) . ' tag pages have zero clicks — noindex them (or 301 the few with demand into collections) so they stop diluting crawl + relevance.';
        if ($dups)      $a[] = count($dups) . ' duplicate-content groups — merge into one canonical page.';
        return ['status' => 'ok',
                'cannibalization_count' => count($cannib), 'cannibalization' => array_slice($cannib, 0, 12),
                'thin_tag_count' => count($thin_tags), 'thin_tags' => array_slice($thin_tags, 0, 15),
                'duplicate_groups' => count($dups), 'duplicates' => array_slice($dups, 0, 8), 'actions' => $a];
    }
}
