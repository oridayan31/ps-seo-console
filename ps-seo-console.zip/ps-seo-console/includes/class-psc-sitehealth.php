<?php
if (!defined('ABSPATH')) exit;

/**
 * Site-wide SEO health analyzers built on the crawl graph + GSC:
 *  - content_health(): depth + uniqueness (thin, duplicate content, no-H1, missing meta) — not the AI check.
 *  - link_health(): internal-link graph — orphans, under-linked ranking pages, links wasted on dead/tag pages, over-linking.
 *  - consolidation(): cannibalization (one query, many pages), thin tag/archive pages to noindex, duplicate pages to merge.
 * Covers every page type the crawl visits (products, categories, tags, collections, pages, posts).
 */
class PSC_SiteHealth {

    const CACHE = 'psc_site_health';

    private static function crawl() { $s = get_option('psc_crawl_state', []); return is_array($s) ? $s : []; }
    private static function path($url) { $p = wp_parse_url($url, PHP_URL_PATH); return $p ? rtrim($p, '/') : ''; }
    private static function short($url) { return preg_replace('#^https?://[^/]+#', '', $url); }

    private static function gsc_clicks_by_path() {
        global $wpdb;
        $map = [];
        if (class_exists('PSC_GSC') && PSC_Google::is_connected() && !PSC_GSC::is_empty()) {
            $t = $wpdb->prefix . 'psc_gsc_pages'; $site = PSC_GSC::get_site();
            $rows = $wpdb->get_results($wpdb->prepare("SELECT page, SUM(clicks) c FROM {$t} WHERE site_url=%s AND day >= %s GROUP BY page", $site, gmdate('Y-m-d', strtotime('-28 day'))), ARRAY_A);
            foreach ((array) $rows as $r) $map[self::path($r['page'])] = (int) $r['c'];
        }
        return $map;
    }

    public static function all($force = false) {
        if (!$force) { $c = get_transient(self::CACHE); if (is_array($c)) return $c; }
        $out = ['content' => self::content_health(), 'links' => self::link_health(), 'consolidation' => self::consolidation(),
                'crawl_ready' => !empty(self::crawl()['results'])];
        set_transient(self::CACHE, $out, 6 * HOUR_IN_SECONDS);
        return $out;
    }

    /* ---------------- content health (depth + uniqueness) ---------------- */
    public static function content_health() {
        $res = self::crawl()['results'] ?? [];
        if (!$res) return ['status' => 'no_crawl'];
        $thin = []; $noh1 = 0; $nometa = 0; $sigmap = [];
        foreach ($res as $r) {
            if (($r['s'] ?? null) === null) continue;
            $w = (int) ($r['w'] ?? 0);
            $codes = array_map(function ($x) { return is_array($x) ? ($x['c'] ?? '') : $x; }, $r['i'] ?? []);
            if (in_array('thin', $codes, true) || ($w > 0 && $w < 200)) $thin[] = ['url' => self::short($r['u']), 'words' => $w];
            if (in_array('no_h1', $codes, true)) $noh1++;
            if (in_array('meta_missing', $codes, true)) $nometa++;
            $sig = $r['sig'] ?? ''; if ($sig) { $sigmap[$sig][] = self::short($r['u']); }
        }
        $dups = [];
        foreach ($sigmap as $urls) if (count($urls) > 1) $dups[] = $urls;
        $total = count($res);
        $bad = count($thin) + $noh1 + $nometa + array_sum(array_map('count', $dups));
        $score = $total ? max(0, min(100, (int) round(100 - ($bad / max(1, $total)) * 130))) : null;
        usort($thin, function ($a, $b) { return $a['words'] <=> $b['words']; });
        $a = [];
        if ($thin)  $a[] = 'Expand or consolidate ' . count($thin) . ' thin pages — add genuine depth (specs, use, curation) or merge into a stronger page.';
        if ($dups)  $a[] = count($dups) . ' groups of near-identical content — rewrite to be unique or canonicalize the weaker ones to the primary.';
        if ($noh1)  $a[] = $noh1 . ' pages have no H1 — add a descriptive H1 with the target topic.';
        if ($nometa)$a[] = $nometa . ' pages missing meta descriptions — the Audit tab can auto-fix these.';
        return ['status' => 'ok', 'score' => $score, 'total' => $total,
                'thin_count' => count($thin), 'thin' => array_slice($thin, 0, 15),
                'duplicate_groups' => count($dups), 'duplicates' => array_slice($dups, 0, 8),
                'no_h1' => $noh1, 'missing_meta' => $nometa, 'actions' => $a];
    }

    /* ---------------- internal linking health ---------------- */
    public static function link_health() {
        $s = self::crawl(); $res = $s['results'] ?? []; $inbound = $s['inbound'] ?? [];
        if (!$res) return ['status' => 'no_crawl'];
        if (empty($inbound)) return ['status' => 'no_links', 'note' => 'Re-crawl the site to build the internal-link graph.'];
        $clicks = self::gsc_clicks_by_path();
        $noindex_paths = [];
        foreach ($res as $r) if (!empty($r['n'])) $noindex_paths[self::path($r['u'])] = 1;
        $over = []; $orphans = []; $underlinked = [];
        foreach ($res as $r) {
            if (($r['s'] ?? null) === null) continue;
            $p = self::path($r['u']); $lc = (int) ($r['lc'] ?? 0); $inb = (int) ($inbound[$p] ?? 0);
            if ($lc > 150) $over[] = ['url' => self::short($r['u']), 'links' => $lc];
            if ($inb === 0 && $p !== '' && !preg_match('#/(tag|category|product-category|product-tag|author|page)/#i', $r['u'])) $orphans[] = self::short($r['u']);
            $c = (int) ($clicks[$p] ?? 0);
            if ($c >= 3 && $inb < 3) $underlinked[] = ['url' => self::short($r['u']), 'clicks' => $c, 'inbound' => $inb];
        }
        $wasted = [];
        foreach ($inbound as $path => $cnt) {
            $isdead = isset($noindex_paths[$path]) || preg_match('#/(tag|product-tag)/#i', $path);
            if ($isdead && $cnt > 0 && (int) ($clicks[$path] ?? 0) === 0) $wasted[] = ['path' => $path, 'inbound' => (int) $cnt];
        }
        usort($over, function ($a, $b) { return $b['links'] <=> $a['links']; });
        usort($wasted, function ($a, $b) { return $b['inbound'] <=> $a['inbound']; });
        usort($underlinked, function ($a, $b) { return $b['clicks'] <=> $a['clicks']; });
        $total = count($res);
        $bad = count($over) + count($orphans) + count($wasted) + count($underlinked);
        $score = $total ? max(0, min(100, (int) round(100 - ($bad / max(1, $total)) * 120))) : null;
        $a = [];
        if ($underlinked) $a[] = count($underlinked) . ' ranking pages are under-linked (real clicks, <3 internal links in) — add contextual links to them from related pages. Highest link ROI.';
        if ($orphans)     $a[] = count($orphans) . ' orphan pages (nothing links to them) — link from a relevant hub/collection so they get crawled and pass equity.';
        if ($wasted)      $a[] = count($wasted) . ' dead targets (noindex/tag pages with no rank) are receiving internal links — repoint those to real ranking pages to stop leaking equity.';
        if ($over)        $a[] = count($over) . ' pages carry 150+ links — trim so equity stays focused and links read naturally.';
        return ['status' => 'ok', 'score' => $score, 'total' => $total,
                'underlinked_count' => count($underlinked), 'underlinked' => array_slice($underlinked, 0, 12),
                'orphan_count' => count($orphans), 'orphans' => array_slice($orphans, 0, 15),
                'wasted_count' => count($wasted), 'wasted' => array_slice($wasted, 0, 12),
                'over_count' => count($over), 'over' => array_slice($over, 0, 10), 'actions' => $a];
    }

    /* ---------------- consolidation / cannibalization ---------------- */
    public static function consolidation() {
        $res = self::crawl()['results'] ?? [];
        $pairs = class_exists('PSC_GSC') ? PSC_GSC::query_page_pairs(28, 1500) : [];
        $byq = [];
        foreach ($pairs as $row) {
            $q = $row['keys'][0] ?? ''; $pg = $row['keys'][1] ?? '';
            if ($q === '' || $pg === '') continue;
            $byq[$q][] = ['page' => self::short($pg), 'clicks' => (int) ($row['clicks'] ?? 0), 'impr' => (int) ($row['impressions'] ?? 0), 'pos' => round((float) ($row['position'] ?? 0), 1)];
        }
        $cannib = [];
        foreach ($byq as $q => $pages) {
            if (count($pages) >= 2) {
                $imp = array_sum(array_map(function ($x) { return $x['impr']; }, $pages));
                if ($imp >= 20) { usort($pages, function ($a, $b) { return $b['clicks'] <=> $a['clicks']; }); $cannib[] = ['query' => $q, 'pages' => array_slice($pages, 0, 4), 'impr' => $imp]; }
            }
        }
        usort($cannib, function ($a, $b) { return $b['impr'] <=> $a['impr']; });

        $clicks = self::gsc_clicks_by_path();
        $thin_tags = [];
        foreach ($res as $r) if (preg_match('#/(tag|product-tag)/#i', $r['u']) && (int) ($clicks[self::path($r['u'])] ?? 0) === 0) $thin_tags[] = self::short($r['u']);

        $sigmap = [];
        foreach ($res as $r) { $sig = $r['sig'] ?? ''; if ($sig) $sigmap[$sig][] = self::short($r['u']); }
        $dups = []; foreach ($sigmap as $urls) if (count($urls) > 1) $dups[] = $urls;

        $a = [];
        if ($cannib)    $a[] = count($cannib) . ' queries have multiple pages competing — pick one primary per query, canonicalize/merge the rest, and consolidate internal links + content into the winner.';
        if ($thin_tags) $a[] = count($thin_tags) . ' tag pages have zero clicks — noindex them (or 301 the few with demand into collections) so they stop diluting crawl + relevance.';
        if ($dups)      $a[] = count($dups) . ' duplicate-content groups — merge into one canonical page.';
        return ['status' => 'ok',
                'cannibalization_count' => count($cannib), 'cannibalization' => array_slice($cannib, 0, 12),
                'thin_tag_count' => count($thin_tags), 'thin_tags' => array_slice($thin_tags, 0, 15),
                'duplicate_groups' => count($dups), 'duplicates' => array_slice($dups, 0, 8), 'actions' => $a];
    }
}
