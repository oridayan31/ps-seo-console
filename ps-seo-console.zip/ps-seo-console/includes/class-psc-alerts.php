<?php
if (!defined('ABSPATH')) exit;

/**
 * Critical email alerts. Reads signals the Console already computes and emails only
 * NEW, actionable, critical conditions — then remembers them so a persistent problem
 * isn't re-sent every run, and sends a short "resolved" note when it clears.
 * Non-critical items (Google updates, low health) stay on the dashboard unless the
 * recipient opts into the wider tier.
 */
class PSC_Alerts {

    const OPT_ENABLED   = 'psc_alerts_enabled';
    const OPT_TO        = 'psc_alerts_to';
    const OPT_TIER      = 'psc_alerts_tier';   // 'critical' | 'all'
    const STATE         = 'psc_alerts_active'; // key => ['title','severity','detail','url','ts']

    /* ---- settings ---- */

    public static function is_enabled() { return get_option(self::OPT_ENABLED, '1') === '1'; }
    public static function recipient()  { $t = get_option(self::OPT_TO, ''); return $t !== '' ? $t : get_option('admin_email'); }
    public static function tier()        { return get_option(self::OPT_TIER, 'critical') === 'all' ? 'all' : 'critical'; }

    public static function save_settings($enabled, $to, $tier) {
        update_option(self::OPT_ENABLED, $enabled ? '1' : '0');
        update_option(self::OPT_TO, is_email($to) ? sanitize_email($to) : '');
        update_option(self::OPT_TIER, $tier === 'all' ? 'all' : 'critical');
    }

    /* ---- evaluate current conditions ---- */

    public static function evaluate() {
        $out = [];

        // Audit-derived (cached): noindex on live pages + site-level technical blockers.
        if (class_exists('PSC_Audit')) {
            $sig = PSC_Audit::get_signals();
            $groups = $sig['groups'] ?? [];
            foreach ($groups as $g) {
                $key = $g['key'] ?? '';
                $count = (int) ($g['count'] ?? 0);
                if ($key === 'noindex' && $count > 0) {
                    $out['noindex'] = self::a('critical', "{$count} live page(s) set to noindex",
                        'Published pages are telling Google not to index them — invisible in search until fixed.', admin_url('admin.php?page=ps-seo-console&tab=audit'));
                }
                if ($key === 'technical' && ($g['severity'] ?? '') === 'hi' && $count > 0) {
                    $out['technical'] = self::a('critical', 'Site-level indexability blocker',
                        'A HTTPS, robots.txt, or XML-sitemap problem is blocking crawling/indexing.', admin_url('admin.php?page=ps-seo-console&tab=audit'));
                }
                if ($key === 'gmc_disapproved' && $count > 0) {
                    $out['gmc'] = self::a('warning', "{$count} product(s) disapproved in Merchant Center",
                        'Disapproved products are not shown in Shopping/free listings.', admin_url('admin.php?page=ps-seo-console&tab=audit'));
                }
            }
        }

        // Payment gateways (from the cached conversion report; do not force a recompute here).
        $conv = get_transient('psc_conversion_report_28');
        if (is_array($conv) && (($conv['gateways']['status'] ?? '') === 'ok')) {
            foreach ($conv['gateways']['items'] as $g) {
                if (($g['health'] ?? '') === 'high_failures') {
                    $out['gw_fail_' . $g['id']] = self::a('critical', 'Payment gateway failing: ' . $g['title'],
                        $g['fail_rate'] . '% of recent orders failed — check credentials / gateway status.', admin_url('admin.php?page=ps-seo-console&tab=conversion'));
                } elseif (($g['health'] ?? '') === 'idle') {
                    $out['gw_idle_' . $g['id']] = self::a('warning', 'Payment gateway idle: ' . $g['title'],
                        'Enabled but no orders in the window — confirm it still works.', admin_url('admin.php?page=ps-seo-console&tab=conversion'));
                }
            }
        }

        // Search traffic cliff (28d vs prior 28d).
        if (class_exists('PSC_GSC')) {
            $k = PSC_GSC::kpis();
            if (is_array($k) && isset($k['clicks']['delta_pct']) && $k['clicks']['delta_pct'] !== null) {
                if ($k['clicks']['dir'] === 'down' && $k['clicks']['delta_pct'] <= -40 && (int) $k['clicks']['value'] >= 20) {
                    $out['traffic'] = self::a('critical', 'Search clicks down ' . abs($k['clicks']['delta_pct']) . '% (28d)',
                        'A sharp organic-traffic drop. Check Google Search status + recent changes before assuming a bug.', admin_url('admin.php?page=ps-seo-console&tab=overview'));
                }
            }
        }

        return $out;
    }

    /* ---- run: diff against last state, email new + resolved ---- */

    public static function run() {
        if (!self::is_enabled()) return;
        $cur  = self::evaluate();
        $prev = get_option(self::STATE, []);
        if (!is_array($prev)) $prev = [];
        $tier = self::tier();
        $emailable = function ($sev) use ($tier) {
            return $sev === 'critical' || ($tier === 'all' && $sev === 'warning');
        };
        $new = []; $resolved = [];
        foreach ($cur as $key => $it) {
            if (!isset($prev[$key]) && $emailable($it['severity'])) $new[] = $it;
        }
        foreach ($prev as $key => $it) {
            if (!isset($cur[$key]) && $emailable($it['severity'] ?? '')) $resolved[] = $it;
        }
        if ($new || $resolved) self::send($new, $resolved);
        update_option(self::STATE, $cur);
        update_option('psc_alerts_last_run', current_time('mysql'));
    }

    /* ---- email ---- */

    private static function send($new, $resolved) {
        $to = self::recipient();
        if (!$to) return;
        $site = wp_parse_url(home_url(), PHP_URL_HOST);
        $n = count($new);
        $subject = $n
            ? sprintf('[Print Studio] %d critical alert%s', $n, $n === 1 ? '' : 's')
            : '[Print Studio] alert resolved';

        $lines = [];
        if ($new) {
            $lines[] = 'NEW:';
            foreach ($new as $a) {
                $lines[] = ' • ' . strtoupper($a['severity']) . ' — ' . $a['title'];
                if (!empty($a['detail'])) $lines[] = '     ' . $a['detail'];
                if (!empty($a['url']))    $lines[] = '     ' . $a['url'];
            }
        }
        if ($resolved) {
            $lines[] = '';
            $lines[] = 'RESOLVED:';
            foreach ($resolved as $a) $lines[] = ' • ' . $a['title'];
        }
        $lines[] = '';
        $lines[] = 'Open the console: ' . admin_url('admin.php?page=ps-seo-console');
        $lines[] = '(' . $site . ' · PS SEO Console)';

        wp_mail($to, $subject, implode("\n", $lines));
    }

    /** Send a sample email to confirm delivery + settings. */
    public static function test() {
        $to = self::recipient();
        if (!$to) return [false, 'No recipient — set one or an admin email.'];
        $ok = wp_mail($to, '[Print Studio] test alert',
            "This is a test from PS SEO Console.\nIf you received it, critical alerts will reach: {$to}\n\nTier: " . self::tier() . "\nConsole: " . admin_url('admin.php?page=ps-seo-console'));
        return $ok ? [true, 'Test email sent to ' . $to] : [false, 'wp_mail() returned false — check the site mailer (SMTP).'];
    }

    private static function a($severity, $title, $detail = '', $url = '') {
        return ['severity' => $severity, 'title' => $title, 'detail' => $detail, 'url' => $url, 'ts' => time()];
    }
}
