<?php
if (!defined('ABSPATH')) exit;

/**
 * Google service-account auth (server-to-server, no interactive OAuth).
 * Signs an RS256 JWT with the SA private key, exchanges it for an access token,
 * caches the token, and exposes authorized GET/POST helpers.
 *
 * The SA JSON can live in the option `psc_google_sa` OR, more securely, in a
 * wp-config constant PSC_GOOGLE_SA_JSON (raw JSON string) which takes priority.
 */
class PSC_Google {

    const OPT_SA    = 'psc_google_sa';
    const OPT_META  = 'psc_google_meta';   // token_email, authorized_at, last_error
    const TOKEN_KEY = 'psc_google_token';
    const SCOPES    = 'https://www.googleapis.com/auth/webmasters.readonly https://www.googleapis.com/auth/analytics.readonly https://www.googleapis.com/auth/content';

    /* ---- SA storage ---- */

    public static function get_sa() {
        if (defined('PSC_GOOGLE_SA_JSON')) {
            $j = json_decode((string) constant('PSC_GOOGLE_SA_JSON'), true);
            if (is_array($j)) return $j;
        }
        $sa = get_option(self::OPT_SA, []);
        return is_array($sa) ? $sa : [];
    }

    public static function is_connected() {
        if (class_exists('PSC_OAuth') && PSC_OAuth::is_connected()) return true;
        $sa = self::get_sa();
        return !empty($sa['client_email']) && !empty($sa['private_key']);
    }

    /** Validate + store a pasted SA JSON string. Returns [ok, message]. */
    public static function save_sa($json_string) {
        $sa = json_decode((string) $json_string, true);
        if (!is_array($sa) || empty($sa['client_email']) || empty($sa['private_key'])) {
            return [false, 'That does not look like a service-account JSON key (missing client_email / private_key).'];
        }
        update_option(self::OPT_SA, $sa);
        delete_transient(self::TOKEN_KEY);
        // Verify by fetching a token immediately.
        $tok = self::get_token(true);
        if (is_wp_error($tok)) {
            self::set_meta(['last_error' => $tok->get_error_message()]);
            return [false, 'Saved, but token fetch failed: ' . $tok->get_error_message()];
        }
        self::set_meta([
            'token_email'    => $sa['client_email'],
            'authorized_at'  => current_time('mysql'),
            'last_error'     => '',
        ]);
        return [true, 'Connected. Service account authorized.'];
    }

    public static function disconnect() {
        delete_option(self::OPT_SA);
        delete_option(self::OPT_META);
        delete_transient(self::TOKEN_KEY);
    }

    public static function meta() {
        $m = get_option(self::OPT_META, []);
        return is_array($m) ? $m : [];
    }
    private static function set_meta($patch) {
        update_option(self::OPT_META, array_merge(self::meta(), $patch));
    }

    /* ---- token ---- */

    public static function get_token($force = false) {
        // Prefer OAuth (sign-in) when connected; fall back to service account.
        if (class_exists('PSC_OAuth') && PSC_OAuth::is_connected()) {
            return PSC_OAuth::access_token($force);
        }
        if (!$force) {
            $cached = get_transient(self::TOKEN_KEY);
            if ($cached) return $cached;
        }
        $sa = self::get_sa();
        if (empty($sa['client_email']) || empty($sa['private_key'])) {
            return new WP_Error('no_sa', 'No service account configured.');
        }
        if (!function_exists('openssl_sign')) {
            return new WP_Error('no_openssl', 'OpenSSL is required to sign the Google JWT.');
        }
        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss'   => $sa['client_email'],
            'scope' => self::SCOPES,
            'aud'   => 'https://oauth2.googleapis.com/token',
            'exp'   => $now + 3600,
            'iat'   => $now,
        ];
        $jwt = self::b64u(wp_json_encode($header)) . '.' . self::b64u(wp_json_encode($claim));
        $sig = '';
        $ok = openssl_sign($jwt, $sig, $sa['private_key'], 'sha256WithRSAEncryption');
        if (!$ok) {
            return new WP_Error('sign_failed', 'Could not sign JWT (bad private key?).');
        }
        $assertion = $jwt . '.' . self::b64u($sig);

        $resp = wp_remote_post('https://oauth2.googleapis.com/token', [
            'timeout' => 20,
            'body'    => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $assertion,
            ],
        ]);
        if (is_wp_error($resp)) return $resp;
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (empty($body['access_token'])) {
            $msg = isset($body['error_description']) ? $body['error_description'] : 'token exchange failed';
            return new WP_Error('token_failed', $msg);
        }
        $ttl = isset($body['expires_in']) ? max(60, (int) $body['expires_in'] - 120) : 3000;
        set_transient(self::TOKEN_KEY, $body['access_token'], $ttl);
        return $body['access_token'];
    }

    /* ---- authorized requests ---- */

    public static function get($url) {
        return self::request('GET', $url, null);
    }
    public static function post($url, $payload) {
        return self::request('POST', $url, $payload);
    }

    private static function request($method, $url, $payload) {
        $token = self::get_token();
        if (is_wp_error($token)) return $token;
        $args = [
            'method'  => $method,
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
        ];
        if ($payload !== null) $args['body'] = wp_json_encode($payload);
        $resp = wp_remote_request($url, $args);
        if (is_wp_error($resp)) return $resp;
        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code < 200 || $code >= 300) {
            $msg = isset($body['error']['message']) ? $body['error']['message'] : ('HTTP ' . $code);
            self::set_meta(['last_error' => $msg]);
            return new WP_Error('google_http_' . $code, $msg, ['status' => $code]);
        }
        return is_array($body) ? $body : [];
    }

    private static function b64u($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}
