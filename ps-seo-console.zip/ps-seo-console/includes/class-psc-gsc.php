<?php
if (!defined('ABSPATH')) exit;

/**
 * Search Console integration. Stores DATED rows (not snapshots) so we get
 * real trends. Self-provisioning tables, self-backfilling window
 * (90d first run, 30d subsequent), idempotent upserts.
 */
class PSC_GSC {

    const OPT_SITE = 'psc_gsc_site';
    const API = 'https://searchconsole.googleapis.com/webmasters/v3';

    public static function tables() {
        global $wpdb;
        return [
            'daily'   => $wpdb->prefix . 'psc_gsc_daily',
            'queries' => $wpdb->prefix . 'psc_gsc_queries',
            'pages'   => $wpdb->prefix . 'psc_gsc_pages',
        ];
    }

    public static function ensure_tables() {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        $t = self::tables();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t['daily']} (
            site_url VARCHAR(191) NOT NULL, day DATE NOT NULL,
            clicks INT DEFAULT 0, impressions INT DEFAULT 0, ctr FLOAT DEFAULT 0, position FLOAT DEFAULT 0,
            PRIMARY KEY (site_url, day)
        ) {$c};");
        dbDelta("CREATE TABLE {$t['queries']} (
            site_url VARCHAR(191) NOT NULL, day DATE NOT NULL, query VARCHAR(191) NOT NULL,
            clicks INT DEFAULT 0, impressions INT DEFAULT 0, ctr FLOAT DEFAULT 0, position FLOAT DEFAULT 0,
            PRIMARY KEY (site_url, day, query)
        ) {$c};");
        dbDelta("CREATE TABLE {$t['pages']} (
            site_url VARCHAR(191) NOT NULL, day DATE NOT NULL, page VARCHAR(191) NOT NULL,
            clicks INT DEFAULT 0, impressions INT DEFAULT 0, ctr FLOAT DEFAULT 0, position FLOAT DEFAULT 0,
            PRIMARY KEY (site_url, day, page)
        ) {$c};");
    }

    /* ---- site selection ---- */

    public static function list_sites() {
        $r = PSC_Google::get(self::API . '/sites');
        if (is_wp_error($r)) return $r;
        $out = [];
        foreach (($r['siteEntry'] ?? []) as $s) {
            if (!empty($s['siteUrl'])) $out[] = $s['siteUrl'];
        }
        return $out;
    }

    public static function get_site() {
        $site = get_option(self::OPT_SITE, '');
        if ($site) return $site;
        // default guess = home_url with trailing slash
        return trailingslashit(home_url());
    }
    public static function set_site($site) {
        update_option(self::OPT_SITE, esc_url_raw($site));
    }

    /* ---- sync ---- */

    public static function sync() {
        if (!PSC_Google::is_connected()) return new WP_Error('not_connected', 'Google not connected');
        self::ensure_tables();
        $site = self::get_site();
        $empty = self::is_empty();
        $days  = $empty ? 90 : 30;
        $end   = gmdate('Y-m-d', strtotime('-1 day'));       // GSC finalizes ~1 day behind
        $start = gmdate('Y-m-d', strtotime("-{$days} day"));

        $errs = [];
        $r1 = self::fetch_and_store($site, $start, $end, ['date'], 'daily');    if (is_wp_error($r1)) $errs[] = $r1->get_error_message();
        $r2 = self::fetch_and_store($site, $start, $end, ['query'], 'queries'); if (is_wp_error($r2)) $errs[] = $r2->get_error_message();
        $r3 = self::fetch_and_store($site, $start, $end, ['page'], 'pages');    if (is_wp_error($r3)) $errs[] = $r3->get_error_message();

        update_option('psc_gsc_last_sync', current_time('mysql'));
        return $errs ? new WP_Error('gsc_partial', implode('; ', $errs)) : true;
    }

    private static function fetch_and_store($site, $start, $end, $dims, $bucket) {
        // For query/page dimensions GSC does not return per-day; add 'date' so rows are dated.
        $dimensions = in_array('date', $dims, true) ? $dims : array_merge(['date'], $dims);
        $url = self::API . '/sites/' . rawurlencode($site) . '/searchAnalytics/query';
        $payload = [
            'startDate'  => $start,
            'endDate'    => $end,
            'dimensions' => $dimensions,
            'rowLimit'   => ($bucket === 'daily') ? 1000 : 5000,
        ];
        $r = PSC_Google::post($url, $payload);
        if (is_wp_error($r)) return $r;
        $rows = $r['rows'] ?? [];
        if (empty($rows)) return true;

        global $wpdb;
        $t = self::tables()[$bucket];
        foreach ($rows as $row) {
            $k = $row['keys'] ?? [];
            $day = $k[0] ?? null;
            if (!$day) continue;
            $data = [
                'site_url'    => $site,
                'day'         => $day,
                'clicks'      => (int) ($row['clicks'] ?? 0),
                'impressions' => (int) ($row['impressions'] ?? 0),
                'ctr'         => (float) ($row['ctr'] ?? 0),
                'position'    => (float) ($row['position'] ?? 0),
            ];
            if ($bucket === 'queries')  $data['query'] = mb_substr((string) ($k[1] ?? ''), 0, 190);
            if ($bucket === 'pages')    $data['page']  = mb_substr((string) ($k[1] ?? ''), 0, 190);
            self::upsert($t, $data, $bucket);
        }
        return true;
    }

    private static function upsert($table, $data, $bucket) {
        global $wpdb;
        $cols = array_keys($data);
        $place = implode(',', array_fill(0, count($cols), '%s'));
        $vals = array_values($data);
        $updates = 'clicks=VALUES(clicks),impressions=VALUES(impressions),ctr=VALUES(ctr),position=VALUES(position)';
        $sql = "INSERT INTO {$table} (" . implode(',', $cols) . ") VALUES ({$place}) ON DUPLICATE KEY UPDATE {$updates}";
        $wpdb->query($wpdb->prepare($sql, $vals));
    }

    public static function is_empty() {
        global $wpdb;
        $t = self::tables()['daily'];
        return 0 === (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t}");
    }

    /* ---- KPI computation: last 28d vs prior 28d ---- */

    public static function kpis() {
        global $wpdb;
        if (!PSC_Google::is_connected() || self::is_empty()) return null;
        $t = self::tables()['daily'];
        $site = self::get_site();
        $cur  = self::window_totals($t, $site, 28, 0);
        $prev = self::window_totals($t, $site, 28, 28);
        return [
            'clicks'      => self::metric($cur['clicks'], $prev['clicks']),
            'impressions' => self::metric($cur['impressions'], $prev['impressions']),
            'ctr'         => self::metric_ctr($cur, $prev),
            'position'    => self::metric_pos($cur['position'], $prev['position']),
        ];
    }

    private static function window_totals($t, $site, $len, $offset) {
        global $wpdb;
        $end   = gmdate('Y-m-d', strtotime("-" . (1 + $offset) . " day"));
        $start = gmdate('Y-m-d', strtotime("-" . ($len + $offset) . " day"));
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT COALESCE(SUM(clicks),0) clicks, COALESCE(SUM(impressions),0) impressions,
                    COALESCE(SUM(position*impressions)/NULLIF(SUM(impressions),0),0) position
               FROM {$t} WHERE site_url=%s AND day BETWEEN %s AND %s",
            $site, $start, $end
        ), ARRAY_A);
        return [
            'clicks'      => (int) ($row['clicks'] ?? 0),
            'impressions' => (int) ($row['impressions'] ?? 0),
            'position'    => (float) ($row['position'] ?? 0),
        ];
    }

    private static function metric($cur, $prev) {
        $delta = $prev > 0 ? (($cur - $prev) / $prev) * 100 : null;
        return ['value' => $cur, 'delta_pct' => $delta === null ? null : round($delta, 1), 'dir' => $cur >= $prev ? 'up' : 'down'];
    }
    private static function metric_ctr($cur, $prev) {
        $c = $cur['impressions'] > 0 ? $cur['clicks'] / $cur['impressions'] * 100 : 0;
        $p = $prev['impressions'] > 0 ? $prev['clicks'] / $prev['impressions'] * 100 : 0;
        return ['value' => round($c, 2), 'delta_pt' => round($c - $p, 2), 'dir' => $c >= $p ? 'up' : 'down'];
    }
    private static function metric_pos($cur, $prev) {
        // lower is better → improvement when cur < prev
        $improved = $prev > 0 && $cur < $prev;
        return ['value' => round($cur, 1), 'delta' => $prev > 0 ? round($prev - $cur, 1) : null, 'dir' => $improved ? 'up' : 'down'];
    }

    /* ---- signals for the audit ---- */

    public static function ctr_gap_pages($limit = 20) {
        // page-1 pages (pos <= 10) with high impressions and near-zero CTR, latest snapshot
        global $wpdb;
        if (!PSC_Google::is_connected() || self::is_empty()) return [];
        $t = self::tables()['pages'];
        $site = self::get_site();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT page, AVG(position) pos, SUM(impressions) impr, SUM(clicks) clk
               FROM {$t} WHERE site_url=%s AND day >= %s
             GROUP BY page HAVING pos <= 10 AND impr >= 200 AND (clk/NULLIF(impr,0)) < 0.005
             ORDER BY impr DESC LIMIT %d",
            $site, gmdate('Y-m-d', strtotime('-28 day')), $limit
        ), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function striking_distance($limit = 50) {
        global $wpdb;
        if (!PSC_Google::is_connected() || self::is_empty()) return [];
        $t = self::tables()['pages'];
        $site = self::get_site();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT page, AVG(position) pos, SUM(impressions) impr
               FROM {$t} WHERE site_url=%s AND day >= %s
             GROUP BY page HAVING pos > 5 AND pos <= 15
             ORDER BY impr DESC LIMIT %d",
            $site, gmdate('Y-m-d', strtotime('-28 day')), $limit
        ), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function page_metrics($url) {
        global $wpdb;
        if (!PSC_Google::is_connected() || self::is_empty()) return null;
        $t = self::tables()['pages'];
        $site = self::get_site();
        return $wpdb->get_row($wpdb->prepare(
            "SELECT SUM(clicks) clicks, SUM(impressions) impressions, AVG(position) position
               FROM {$t} WHERE site_url=%s AND page=%s AND day >= %s",
            $site, $url, gmdate('Y-m-d', strtotime('-28 day'))
        ), ARRAY_A);
    }
}
