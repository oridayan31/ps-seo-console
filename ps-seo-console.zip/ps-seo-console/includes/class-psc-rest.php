<?php
if (!defined('ABSPATH')) exit;

/**
 * REST surface (namespace ps-seo/v1). Same auth model as ps-claude-bridge:
 * WP Application Passwords over HTTP Basic, admin only. This is how Claude
 * reads metrics and writes board cards live, and how the admin UI persists.
 */
class PSC_REST {

    public static function perm() {
        return current_user_can('manage_options');
    }

    public static function register_routes() {
        $ns = PSC_REST_NS;

        register_rest_route($ns, '/health', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => [__CLASS__, 'health'],
        ]);

        register_rest_route($ns, '/dashboard', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => [__CLASS__, 'dashboard'],
        ]);

        register_rest_route($ns, '/tasks', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    return rest_ensure_response(PSC_DB::get_tasks([
                        'status'   => $r['status'],
                        'priority' => $r['priority'],
                        'domain'   => $r['domain'],
                    ]));
                },
            ],
            [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    $p = $r->get_json_params();
                    if (empty($p) || empty($p['title'])) {
                        return new WP_Error('bad_request', 'title is required', ['status' => 400]);
                    }
                    $task = PSC_DB::create_task($p);
                    return $task ? rest_ensure_response($task)
                                 : new WP_Error('create_failed', 'Could not create task', ['status' => 500]);
                },
            ],
        ]);

        register_rest_route($ns, '/tasks/(?P<id>\d+)', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    $t = PSC_DB::get_task((int) $r['id']);
                    return $t ? rest_ensure_response($t) : new WP_Error('not_found', 'Not found', ['status' => 404]);
                },
            ],
            [
                'methods' => 'PUT,PATCH', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    $p = $r->get_json_params();
                    $before = PSC_DB::get_task((int) $r['id']);
                    $t = PSC_DB::update_task((int) $r['id'], is_array($p) ? $p : []);
                    // When an action is completed and points at a page, start tracking its result.
                    if ($t && ($t['status'] ?? '') === 'done' && ($before['status'] ?? '') !== 'done'
                        && !empty($t['target_url']) && class_exists('PSC_Changes')) {
                        $existing = false;
                        foreach (PSC_Changes::all() as $c) if (($c['url'] ?? '') === $t['target_url']) { $existing = true; break; }
                        if (!$existing) PSC_Changes::add(['title' => $t['title'], 'url' => $t['target_url'], 'kind' => ($t['source'] === 'opportunity' ? 'internal_links' : 'other'), 'note' => 'Action completed']);
                    }
                    return $t ? rest_ensure_response($t) : new WP_Error('not_found', 'Not found', ['status' => 404]);
                },
            ],
            [
                'methods' => 'DELETE', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    return rest_ensure_response(['deleted' => PSC_DB::delete_task((int) $r['id'])]);
                },
            ],
        ]);

        register_rest_route($ns, '/signals', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                return rest_ensure_response(PSC_Audit::get_signals(!empty($r['force'])));
            },
        ]);

        register_rest_route($ns, '/gmc/debug', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                return rest_ensure_response(['status' => PSC_GMC::get_status(true), 'sample' => PSC_GMC::debug_sample()]);
            },
        ]);

        register_rest_route($ns, '/google/property', [            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                if (!empty($p['ga4']))  PSC_GA4::set_property((string) $p['ga4']);
                if (!empty($p['gsc']))  PSC_GSC::set_site((string) $p['gsc']);
                if (isset($p['gmc']))   PSC_GMC::set_id((string) $p['gmc']);
                return rest_ensure_response([
                    'ga4' => PSC_GA4::get_property(),
                    'gsc' => PSC_GSC::get_site(),
                    'gmc' => PSC_GMC::get_id(),
                ]);
            },
        ]);

        register_rest_route($ns, '/insights', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                return rest_ensure_response(PSC_Insights::generate(!empty($r['force'])));
            },
        ]);

        register_rest_route($ns, '/content-quality', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $url = $r['url'] ?: home_url('/');
                return rest_ensure_response(PSC_ContentQuality::check_url($url, !empty($r['force'])));
            },
        ]);

        register_rest_route($ns, '/brain', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                return rest_ensure_response(PSC_Brain::ask((string) ($p['question'] ?? '')));
            },
        ]);

        register_rest_route($ns, '/crawl/start', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Crawl::start()); },
        ]);
        register_rest_route($ns, '/crawl/step', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { $p = $r->get_json_params(); return rest_ensure_response(PSC_Crawl::step((int) ($p['size'] ?? 12))); },
        ]);
        register_rest_route($ns, '/crawl/tick', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { $p = $r->get_json_params(); return rest_ensure_response(PSC_Crawl::tick((int) ($p['size'] ?? 12))); },
        ]);
        register_rest_route($ns, '/crawl/report', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Crawl::report()); },
        ]);
        register_rest_route($ns, '/crawl/progress', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Crawl::progress()); },
        ]);
        register_rest_route($ns, '/crawl/fix', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { $p = $r->get_json_params(); return rest_ensure_response(PSC_Crawl::fix((string) ($p['url'] ?? ''), (string) ($p['code'] ?? ''))); },
        ]);

        /* ---- change → impact tracker ---- */
        register_rest_route($ns, '/changes', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function () { return rest_ensure_response(PSC_Changes::report()); },
            ],
            [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) { return rest_ensure_response(PSC_Changes::add($r->get_json_params())); },
            ],
        ]);
        register_rest_route($ns, '/changes/(?P<id>[\w]+)', [
            'methods' => 'DELETE', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { PSC_Changes::remove($r['id']); return rest_ensure_response(['deleted' => true]); },
        ]);

        register_rest_route($ns, '/site-health', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { return rest_ensure_response(PSC_SiteHealth::all(!empty($r['force']))); },
        ]);
        register_rest_route($ns, '/fix/preview', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                return rest_ensure_response(PSC_Fixer::preview((string) ($p['url'] ?? ''), (string) ($p['code'] ?? ''), is_array($p['extra'] ?? null) ? $p['extra'] : []));
            },
        ]);
        register_rest_route($ns, '/fix/apply', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { $p = $r->get_json_params(); return rest_ensure_response(PSC_Fixer::apply((string) ($p['id'] ?? ''))); },
        ]);
        register_rest_route($ns, '/verify', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(['count' => PSC_Verify::count(), 'items' => PSC_Verify::items()]); },
        ]);
        register_rest_route($ns, '/verify/run', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Verify::run()); },
        ]);

        /* ---- opportunities (pages + keywords) with detailed actions ---- */
        register_rest_route($ns, '/opportunities', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                $editlink = function ($url) {
                    $pid = function_exists('url_to_postid') ? url_to_postid($url) : 0;
                    if (!$pid && trim((string) wp_parse_url($url, PHP_URL_PATH), '/') === '') $pid = (int) get_option('page_on_front');
                    return $pid ? admin_url('post.php?post=' . $pid . '&action=edit') : '';
                };
                $pages = [];
                foreach (PSC_GSC::striking_distance(20) as $p) {
                    $pages[] = [
                        'url' => $p['page'], 'edit_url' => $editlink($p['page']),
                        'position' => round((float) $p['pos'], 1), 'impressions' => (int) $p['impr'],
                        'type' => 'striking_distance',
                        'action' => 'Push to page 1 — ranks ' . round((float) $p['pos'], 1) . ' with ' . (int) $p['impr'] . ' impressions.',
                        'how' => [
                            'Confirm the target keyword is in the H1, the title tag, and the first paragraph.',
                            'Add 2–3 internal links TO this page from your most relevant existing pages, using descriptive anchor text (the keyword — never "read more").',
                            'Tighten the meta title + description to match intent, keyword near the front.',
                            'If thin, add 150–300 words of genuinely specific content (sizing, materials, room examples, pairings).',
                            'Log it in Changes & Impact and re-check in ~3 weeks.',
                        ],
                    ];
                }
                foreach (PSC_GSC::ctr_upside(15) as $p) {
                    $pages[] = [
                        'url' => $p['page'], 'edit_url' => $editlink($p['page']),
                        'position' => round((float) $p['pos'], 1), 'impressions' => (int) $p['impr'], 'ctr' => round((float) $p['ctr'] * 100, 2),
                        'type' => 'ctr_upside',
                        'action' => 'Lift CTR — ranks ' . round((float) $p['pos'], 1) . ' with ' . (int) $p['impr'] . ' impressions but only ' . round((float) $p['ctr'] * 100, 2) . '% CTR.',
                        'how' => [
                            'The ranking is fine — this is a click-through problem, so focus on the snippet.',
                            'Rewrite the meta title to lead with the benefit/keyword, under ~60 characters.',
                            'Rewrite the meta description (~150 chars) with a concrete hook — free shipping over $69, 310gsm archival Giclée, ~75-yr life.',
                            'Add a number or year to the title where honest (e.g. "12 ideas", "[2026]") to stand out in results.',
                            'Log it and re-check CTR in ~2 weeks.',
                        ],
                    ];
                }
                $keywords = [];
                foreach (PSC_GSC::keyword_opportunities(25) as $q) {
                    $keywords[] = [
                        'query' => $q['query'], 'position' => round((float) $q['pos'], 1),
                        'impressions' => (int) $q['impr'], 'clicks' => (int) $q['clicks'],
                        'action' => 'Ranks ' . round((float) $q['pos'], 1) . ' with ' . (int) $q['impr'] . ' impressions — capture it.',
                        'how' => [
                            'Find the single best-matching page for "' . $q['query'] . '" (or decide a new page is needed).',
                            'Work the exact phrase into that page\'s H1/title and cover the intent in the body copy.',
                            'Add 2–3 internal links to it using "' . $q['query'] . '" (or close variants) as anchor text.',
                            'If no page fits the intent, build a dedicated collection/guide page targeting it.',
                        ],
                    ];
                }
                return rest_ensure_response(['pages' => $pages, 'keywords' => $keywords]);
            },
        ]);

        /* ---- brain research-approval loop ---- */
        register_rest_route($ns, '/brain/research', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function () { return rest_ensure_response(PSC_Brain::research_items()); },
            ],
            [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function () { return rest_ensure_response(PSC_Brain::propose_research()); },
            ],
        ]);
        register_rest_route($ns, '/brain/research/approve', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { $p = $r->get_json_params(); return rest_ensure_response(PSC_Brain::approve_research((string) ($p['id'] ?? ''))); },
        ]);
        register_rest_route($ns, '/brain/refresh', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                $res = PSC_Brain::refresh_analysis();
                if (!empty($res['error'])) return rest_ensure_response(['ok' => false, 'message' => $res['message'] ?? 'error']);
                return rest_ensure_response(['ok' => true] + PSC_Brain::get_analysis());
            },
        ]);
        register_rest_route($ns, '/brain/knowledge', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function () {
                    return rest_ensure_response(['knowledge' => PSC_Brain::knowledge(), 'custom' => PSC_Brain::is_custom()]);
                },
            ],
            [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    $p = $r->get_json_params();
                    if (isset($p['knowledge'])) PSC_Brain::save_knowledge((string) $p['knowledge']);
                    return rest_ensure_response(['ok' => true, 'custom' => PSC_Brain::is_custom()]);
                },
            ],
        ]);

        register_rest_route($ns, '/scan', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                return rest_ensure_response(PSC_Audit::run_and_cache());
            },
        ]);

        /* ---- Phase 2: Google + metrics ---- */

        register_rest_route($ns, '/connect', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                list($ok, $msg) = PSC_Google::save_sa($p['json'] ?? '');
                return rest_ensure_response(['ok' => $ok, 'message' => $msg, 'meta' => PSC_Google::meta()]);
            },
        ]);

        register_rest_route($ns, '/connect/status', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                return rest_ensure_response([
                    'connected' => PSC_Google::is_connected(),
                    'meta'      => PSC_Google::meta(),
                    'gsc_site'  => PSC_GSC::get_site(),
                    'ga4'       => PSC_GA4::get_property(),
                    'gmc'       => PSC_GMC::get_id(),
                ]);
            },
        ]);

        register_rest_route($ns, '/sync', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                $out = ['gsc' => null, 'ga4' => null, 'gmc' => null];
                if (PSC_Google::is_connected()) {
                    $g = PSC_GSC::sync(); $out['gsc'] = is_wp_error($g) ? $g->get_error_message() : 'ok';
                    $a = PSC_GA4::sync(); $out['ga4'] = is_wp_error($a) ? $a->get_error_message() : 'ok';
                    $m = PSC_GMC::sync(); $out['gmc'] = isset($m['error']) ? $m['error'] : 'ok';
                }
                PSC_Audit::run_and_cache();
                return rest_ensure_response($out);
            },
        ]);

        register_rest_route($ns, '/kpis', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                return rest_ensure_response([
                    'gsc'     => PSC_GSC::kpis(),
                    'revenue' => PSC_GA4::organic_revenue_kpi(),
                    'feed'    => PSC_GMC::get_status(),
                ]);
            },
        ]);

        register_rest_route($ns, '/watches', [
            [
                'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function () { return rest_ensure_response(PSC_Watchers::upcoming(50)); },
            ],
            [
                'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
                'callback' => function ($r) {
                    $p = $r->get_json_params();
                    if (empty($p['subject_url']) && empty($p['label'])) {
                        return new WP_Error('bad_request', 'subject_url or label required', ['status' => 400]);
                    }
                    $id = PSC_Watchers::create_watch(
                        $p['subject_url'] ?? '', $p['event_type'] ?? 'manual',
                        $p['label'] ?? '', isset($p['days']) ? (int) $p['days'] : null
                    );
                    return rest_ensure_response(['id' => $id]);
                },
            ],
        ]);

        /* ---- Connectors (DataForSEO / PageSpeed / Anthropic) ---- */
        register_rest_route($ns, '/connectors', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Connectors::status()); },
        ]);
        register_rest_route($ns, '/connectors/test', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                list($ok, $msg) = PSC_Connectors::test(sanitize_key($p['which'] ?? ''));
                return rest_ensure_response(['ok' => $ok, 'message' => $msg]);
            },
        ]);
        register_rest_route($ns, '/connectors/scan', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () { return rest_ensure_response(PSC_Connectors::scan()); },
        ]);
        register_rest_route($ns, '/connectors/import', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                list($ok, $msg) = PSC_Connectors::import(sanitize_key($p['type'] ?? ''));
                return rest_ensure_response(['ok' => $ok, 'message' => $msg]);
            },
        ]);

        /* ---- Per-URL SEO/AEO page audit (ported from seo-aeo-auditor) ---- */
        register_rest_route($ns, '/page-audit', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $url = esc_url_raw((string) $r['url']);
                if (!$url) return new WP_Error('bad_request', 'url required', ['status' => 400]);
                $key = 'psc_pa_' . md5($url);
                if (empty($r['force'])) {
                    $cached = get_transient($key);
                    if (is_array($cached)) return rest_ensure_response($cached);
                }
                $report = PSC_PageAudit::audit($url);
                set_transient($key, $report, HOUR_IN_SECONDS);
                return rest_ensure_response($report);
            },
        ]);

        /* ---- Conversion analysis (funnel + gateways + checkout) ---- */
        register_rest_route($ns, '/conversion', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $days = isset($r['days']) ? max(7, min(90, (int) $r['days'])) : 28;
                return rest_ensure_response(PSC_Conversion::report($days, !empty($r['force'])));
            },
        ]);

        /* ---- Google Search status (incidents feed) ---- */
        register_rest_route($ns, '/google-status', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                if (!empty($r['force'])) PSC_GoogleStatus::incidents(true);
                return rest_ensure_response([
                    'active' => PSC_GoogleStatus::active(),
                    'recent' => PSC_GoogleStatus::recent(5),
                ]);
            },
        ]);

        /* ---- Competitor authority / backlink gap ---- */
        register_rest_route($ns, '/competitors', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) { return rest_ensure_response(PSC_Competitors::report(!empty($r['force']))); },
        ]);
        register_rest_route($ns, '/competitors/add', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                list($ok, $msg) = PSC_Competitors::add((string) ($p['domain'] ?? ''));
                return rest_ensure_response(['ok' => $ok, 'message' => $msg]);
            },
        ]);
        register_rest_route($ns, '/competitors/remove', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                list($ok, $msg) = PSC_Competitors::remove((string) ($p['domain'] ?? ''));
                return rest_ensure_response(['ok' => $ok, 'message' => $msg]);
            },
        ]);

        /* ---- Self-update (verified, token-gated, slug-restricted) ---- */
        register_rest_route($ns, '/update', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                if (!PSC_Updater::verify_token((string) ($p['token'] ?? ''))) {
                    return new WP_Error('forbidden', 'Invalid or missing update token.', ['status' => 403]);
                }
                $res = PSC_Updater::install(
                    (string) ($p['slug'] ?? ''),
                    (string) ($p['zip_b64'] ?? ''),
                    (string) ($p['sha256'] ?? '')
                );
                return rest_ensure_response(['ok' => $res[0], 'message' => $res[1], 'version' => $res[2] ?? '']);
            },
        ]);

        /* ---- Verify Google can actually read (lists GSC sites + GA4 properties) ---- */
        register_rest_route($ns, '/google/verify', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                $out = ['connected' => PSC_Google::is_connected(), 'token' => null, 'gsc' => null, 'ga4' => null];
                $tok = PSC_Google::get_token(true);
                if (is_wp_error($tok)) { $out['token'] = 'ERROR: ' . $tok->get_error_message(); return rest_ensure_response($out); }
                $out['token'] = 'ok';
                $sites = PSC_GSC::list_sites();
                $out['gsc'] = is_wp_error($sites) ? ['error' => $sites->get_error_message()] : $sites;
                $props = PSC_GA4::discover_properties();
                $out['ga4'] = is_wp_error($props) ? ['error' => $props->get_error_message()] : $props;
                $out['ga4_selected'] = PSC_GA4::get_property();
                if ($out['ga4_selected']) {
                    $tok = PSC_Google::get_token(true);
                    if (!is_wp_error($tok)) {
                        $resp = wp_remote_post(
                            'https://analyticsdata.googleapis.com/v1beta/' . $out['ga4_selected'] . ':runReport',
                            ['timeout' => 20, 'headers' => ['Authorization' => 'Bearer ' . $tok, 'Content-Type' => 'application/json'],
                             'body' => wp_json_encode(['dateRanges' => [['startDate' => '7daysAgo', 'endDate' => 'today']], 'metrics' => [['name' => 'sessions']]])]
                        );
                        $out['ga4_probe'] = ['code' => (int) wp_remote_retrieve_response_code($resp), 'body' => json_decode(wp_remote_retrieve_body($resp), true)];
                    }
                }
                return rest_ensure_response($out);
            },
        ]);

        /* ---- Alerts (current conditions + test email) ---- */
        register_rest_route($ns, '/alerts', [            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                return rest_ensure_response([
                    'enabled' => PSC_Alerts::is_enabled(),
                    'recipient' => PSC_Alerts::recipient(),
                    'active' => array_values(PSC_Alerts::evaluate()),
                ]);
            },
        ]);
        register_rest_route($ns, '/alerts/test', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function () {
                list($ok, $msg) = PSC_Alerts::test();
                return rest_ensure_response(['ok' => $ok, 'message' => $msg]);
            },
        ]);

        /* ---- Pull-based self-update: check the configured source (+optional install) ---- */
        register_rest_route($ns, '/update/check', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                $install = !empty($p['install']);
                $res = PSC_Updater::check_remote($install);
                return rest_ensure_response($res);
            },
        ]);
        register_rest_route($ns, '/update/source', [
            'methods' => 'POST', 'permission_callback' => [__CLASS__, 'perm'],
            'callback' => function ($r) {
                $p = $r->get_json_params();
                PSC_Updater::save_source(
                    (string) ($p['url'] ?? ''),
                    array_key_exists('token', $p) ? (string) $p['token'] : null,
                    !empty($p['auto'])
                );
                return rest_ensure_response(['ok' => true, 'source' => PSC_Updater::source_url(), 'token_set' => PSC_Updater::source_token() !== '', 'auto' => PSC_Updater::auto_on()]);
            },
        ]);
    }

    public static function health() {
        $pushed = (string) get_option('psc_pushed_version', '');
        return [
            'ok'           => true,
            'plugin'       => 'ps-seo-console',
            'version'      => PSC_VERSION,
            'rollback_detected' => ($pushed !== '' && version_compare(PSC_VERSION, $pushed, '<')) ? ('running ' . PSC_VERSION . ' but ' . $pushed . ' was pushed') : false,
            'wp'           => get_bloginfo('version'),
            'php'          => PHP_VERSION,
            'yoast'        => defined('WPSEO_VERSION') ? WPSEO_VERSION : null,
            'woocommerce'  => defined('WC_VERSION') ? WC_VERSION : null,
            'google'       => PSC_Google::is_connected(),
            'user'         => wp_get_current_user()->user_login,
            'site'         => home_url(),
            'rest'         => rest_url(PSC_REST_NS),
            'update_source'    => class_exists('PSC_Updater') ? PSC_Updater::source_url() : '',
            'update_token_set' => class_exists('PSC_Updater') ? (PSC_Updater::source_token() !== '') : false,
            'update_auto'      => class_exists('PSC_Updater') ? PSC_Updater::auto_on() : false,
            'oauth'        => class_exists('PSC_OAuth') ? [
                'client_set' => PSC_OAuth::has_client(),
                'connected'  => PSC_OAuth::is_connected(),
                'redirect'   => PSC_OAuth::redirect_uri(),
                'email'      => PSC_OAuth::meta()['email'] ?? '',
                'last_error' => PSC_OAuth::meta()['last_error'] ?? '',
            ] : null,
        ];
    }

    public static function dashboard() {
        $signals = PSC_Audit::get_signals();
        return [
            'progress' => PSC_DB::progress(),
            'health'   => $signals['health'] ?? PSC_Audit::health_score(),
            'summary'  => $signals['summary'] ?? ['opportunities' => 0, 'high' => 0],
            'sources'  => [
                'search_console'  => PSC_Google::is_connected(),
                'ga4'             => PSC_Google::is_connected() && (bool) PSC_GA4::get_property(),
                'merchant_center' => PSC_Google::is_connected() && (bool) PSC_GMC::get_id(),
                'bridge'          => class_exists('PS_Claude_Bridge'),
            ],
            'kpis'     => PSC_GSC::kpis(),
            'watches_due' => PSC_Watchers::count_due_soon(7),
            'generated_at' => current_time('mysql'),
        ];
    }
}
