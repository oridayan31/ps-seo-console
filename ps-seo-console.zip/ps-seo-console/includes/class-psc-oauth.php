<?php
if (!defined('ABSPATH')) exit;

/**
 * "Sign in with Google" (OAuth 2.0, offline). The user logs in with the account
 * that already owns their Search Console / GA4 / Merchant properties and approves
 * once; we keep the refresh token and mint short-lived access tokens for the APIs.
 * No service account, no adding users anywhere. Client id/secret come from an OAuth
 * client the user creates once (or wp-config constants).
 */
class PSC_OAuth {

    const OPT_CLIENT  = 'psc_oauth_client';   // ['id','secret']
    const OPT_REFRESH = 'psc_oauth_refresh';
    const OPT_META    = 'psc_oauth_meta';     // ['email','connected_at','last_error']
    const TOKEN       = 'psc_oauth_access';    // transient (access token)
    const AUTH_URL    = 'https://accounts.google.com/o/oauth2/v2/auth';
    const TOKEN_URL   = 'https://oauth2.googleapis.com/token';
    const SCOPES = [
        'https://www.googleapis.com/auth/webmasters.readonly',
        'https://www.googleapis.com/auth/analytics.readonly',
        'https://www.googleapis.com/auth/content',
        'openid', 'email',
    ];

    /* ---- client credentials ---- */

    public static function client_id() {
        if (defined('PSC_OAUTH_CLIENT_ID') && constant('PSC_OAUTH_CLIENT_ID') !== '') return (string) constant('PSC_OAUTH_CLIENT_ID');
        $c = get_option(self::OPT_CLIENT, []);
        return is_array($c) ? (string) ($c['id'] ?? '') : '';
    }
    public static function client_secret() {
        if (defined('PSC_OAUTH_CLIENT_SECRET') && constant('PSC_OAUTH_CLIENT_SECRET') !== '') return (string) constant('PSC_OAUTH_CLIENT_SECRET');
        $c = get_option(self::OPT_CLIENT, []);
        return is_array($c) ? (string) ($c['secret'] ?? '') : '';
    }
    public static function has_client()  { return self::client_id() !== '' && self::client_secret() !== ''; }
    public static function is_connected() { return self::has_client() && get_option(self::OPT_REFRESH, '') !== ''; }
    public static function meta()          { $m = get_option(self::OPT_META, []); return is_array($m) ? $m : []; }

    public static function save_client($id, $secret) {
        $id = trim((string) $id); $secret = trim((string) $secret);
        $cur = get_option(self::OPT_CLIENT, []);
        if (!is_array($cur)) $cur = [];
        if ($id !== '') $cur['id'] = $id;
        if ($secret !== '') $cur['secret'] = $secret;
        update_option(self::OPT_CLIENT, $cur);
    }

    public static function redirect_uri() {
        return admin_url('admin-post.php?action=psc_oauth_cb');
    }

    /* ---- authorize ---- */

    public static function auth_url() {
        $state = wp_generate_password(24, false);
        set_transient('psc_oauth_state_' . get_current_user_id(), $state, 600);
        return self::AUTH_URL . '?' . http_build_query([
            'client_id'     => self::client_id(),
            'redirect_uri'  => self::redirect_uri(),
            'response_type' => 'code',
            'scope'         => implode(' ', self::SCOPES),
            'access_type'   => 'offline',
            'prompt'        => 'consent',
            'include_granted_scopes' => 'true',
            'state'         => $state,
        ]);
    }

    /** admin-post callback: exchange the code for tokens. */
    public static function handle_callback() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $settings = admin_url('admin.php?page=ps-seo-console&tab=settings');
        $state = isset($_GET['state']) ? sanitize_text_field(wp_unslash($_GET['state'])) : '';
        $saved = get_transient('psc_oauth_state_' . get_current_user_id());
        delete_transient('psc_oauth_state_' . get_current_user_id());
        if (!empty($_GET['error'])) { wp_safe_redirect(add_query_arg('psc_oauth', 'denied', $settings)); exit; }
        if (!$state || !hash_equals((string) $saved, $state)) { wp_safe_redirect(add_query_arg('psc_oauth', 'badstate', $settings)); exit; }
        $code = isset($_GET['code']) ? sanitize_text_field(wp_unslash($_GET['code'])) : '';
        if ($code === '') { wp_safe_redirect(add_query_arg('psc_oauth', 'nocode', $settings)); exit; }

        $resp = wp_remote_post(self::TOKEN_URL, ['timeout' => 20, 'body' => [
            'code'          => $code,
            'client_id'     => self::client_id(),
            'client_secret' => self::client_secret(),
            'redirect_uri'  => self::redirect_uri(),
            'grant_type'    => 'authorization_code',
        ]]);
        if (is_wp_error($resp)) { self::set_meta(['last_error' => $resp->get_error_message()]); wp_safe_redirect(add_query_arg('psc_oauth', 'error', $settings)); exit; }
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        if (empty($b['refresh_token'])) {
            $msg = $b['error_description'] ?? 'no refresh token returned (revoke prior access + retry)';
            self::set_meta(['last_error' => $msg]);
            wp_safe_redirect(add_query_arg('psc_oauth', 'error', $settings)); exit;
        }
        update_option(self::OPT_REFRESH, $b['refresh_token']);
        if (!empty($b['access_token'])) {
            $ttl = isset($b['expires_in']) ? max(60, (int) $b['expires_in'] - 120) : 3000;
            set_transient(self::TOKEN, $b['access_token'], $ttl);
        }
        self::set_meta(['email' => self::email_from_id_token($b['id_token'] ?? ''), 'connected_at' => current_time('mysql'), 'last_error' => '']);
        wp_safe_redirect(add_query_arg('psc_oauth', 'connected', $settings));
        exit;
    }

    public static function handle_disconnect() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('psc_oauth_disconnect');
        $rt = get_option(self::OPT_REFRESH, '');
        if ($rt) wp_remote_post('https://oauth2.googleapis.com/revoke', ['timeout' => 10, 'body' => ['token' => $rt]]);
        delete_option(self::OPT_REFRESH);
        delete_option(self::OPT_META);
        delete_transient(self::TOKEN);
        wp_safe_redirect(admin_url('admin.php?page=ps-seo-console&tab=settings&psc_oauth=disconnected'));
        exit;
    }

    /* ---- access token (used by PSC_Google) ---- */

    public static function access_token($force = false) {
        if (!$force) { $c = get_transient(self::TOKEN); if ($c) return $c; }
        if (!self::is_connected()) return new WP_Error('not_connected', 'Google not connected via OAuth.');
        $resp = wp_remote_post(self::TOKEN_URL, ['timeout' => 20, 'body' => [
            'client_id'     => self::client_id(),
            'client_secret' => self::client_secret(),
            'refresh_token' => get_option(self::OPT_REFRESH, ''),
            'grant_type'    => 'refresh_token',
        ]]);
        if (is_wp_error($resp)) return $resp;
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        if (empty($b['access_token'])) {
            $msg = $b['error_description'] ?? 'refresh failed';
            self::set_meta(['last_error' => $msg]);
            return new WP_Error('refresh_failed', $msg);
        }
        $ttl = isset($b['expires_in']) ? max(60, (int) $b['expires_in'] - 120) : 3000;
        set_transient(self::TOKEN, $b['access_token'], $ttl);
        return $b['access_token'];
    }

    /* ---- helpers ---- */

    private static function set_meta($patch) { update_option(self::OPT_META, array_merge(self::meta(), $patch)); }

    private static function email_from_id_token($jwt) {
        $parts = explode('.', (string) $jwt);
        if (count($parts) < 2) return '';
        $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
        return is_array($payload) ? (string) ($payload['email'] ?? '') : '';
    }
}
