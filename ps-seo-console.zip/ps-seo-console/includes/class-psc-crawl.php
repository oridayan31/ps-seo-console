<?php
if (!defined('ABSPATH')) exit;

/**
 * Whole-site crawl. Enumerates every URL from the XML sitemap (Yoast or WP core),
 * then runs a fast single-fetch on-page audit across all of them in client-driven
 * batches (so nothing times out), storing a per-page score + issues and a site
 * aggregate. This is what makes "audit every page" real, without 700 slow requests
 * in one shot.
 */
class PSC_Crawl {

    const OPT   = 'psc_crawl_state';
    const UA    = 'PS-SEO-Console/1.0 (+site-crawl)';
    const CAP   = 3000;

    /* ---------- URL enumeration ---------- */

    public static function collect_urls() {
        $roots = [home_url('/sitemap_index.xml'), home_url('/sitemap.xml'), home_url('/wp-sitemap.xml')];
        $seen = []; $urls = [];
        $host = wp_parse_url(home_url(), PHP_URL_HOST);

        $fetch = function ($u) {
            for ($try = 0; $try < 3; $try++) {
                $r = wp_remote_get($u, ['timeout' => 20, 'headers' => ['User-Agent' => self::UA]]);
                if (!is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) < 400) return wp_remote_retrieve_body($r);
                sleep(1);
            }
            return '';
        };

        $index_xml = '';
        foreach ($roots as $root) { $index_xml = $fetch($root); if ($index_xml !== '') break; }
        if ($index_xml === '') return [];

        // sub-sitemaps referenced by the index
        $subs = [];
        if (preg_match_all('#<sitemap>.*?<loc>(.*?)</loc>#is', $index_xml, $m)) $subs = $m[1];
        if (!$subs) $subs = [$root]; // was a flat sitemap already

        foreach (array_slice($subs, 0, 60) as $sub) {
            $xml = ($sub === $root) ? $index_xml : $fetch(html_entity_decode($sub));
            if ($xml === '') continue;
            if (preg_match_all('#<url>.*?<loc>(.*?)</loc>#is', $xml, $mm)) {
                foreach ($mm[1] as $loc) {
                    $loc = trim(html_entity_decode($loc));
                    if (wp_parse_url($loc, PHP_URL_HOST) !== $host) continue;
                    if (isset($seen[$loc])) continue;
                    $seen[$loc] = 1; $urls[] = $loc;
                    if (count($urls) >= self::CAP) break 2;
                }
            }
        }
        return $urls;
    }

    /* ---------- per-page fast audit (single fetch) ---------- */

    public static function check_page($url) {
        $r = wp_remote_get($url, ['timeout' => 8, 'redirection' => 2, 'headers' => ['User-Agent' => self::UA]]);
        if (is_wp_error($r)) return ['url' => $url, 'score' => null, 'error' => $r->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($r);
        $html = wp_remote_retrieve_body($r);
        $issues = []; $noindex = false; $score = 100;
        if ($code >= 400) return ['url' => $url, 'score' => 0, 'http' => $code, 'noindex' => false, 'issues' => [['c' => 'http', 'd' => "Returns HTTP {$code}", 'f' => false]]];

        $add = function ($c, $d, $f) use (&$issues) { $issues[] = ['c' => $c, 'd' => $d, 'f' => $f]; };

        // headings (with text) for H1 + skip detail
        $heads = [];
        if (preg_match_all('#<h([1-6])[^>]*>(.*?)</h\1>#is', $html, $hm, PREG_SET_ORDER)) {
            foreach ($hm as $h) $heads[] = ['lvl' => (int) $h[1], 'text' => trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($h[2])))];
        }
        $h1s = array_values(array_filter($heads, function ($h) { return $h['lvl'] === 1; }));

        // robots meta
        if (preg_match('#<meta[^>]+name=["\']robots["\'][^>]+content=["\']([^"\']*)#i', $html, $m) && stripos($m[1], 'noindex') !== false) {
            $noindex = true; $add('noindex', 'Page is set to noindex — Google is told not to index it', false); $score -= 60;
        }
        // title
        $title = '';
        if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $title = trim(html_entity_decode(wp_strip_all_tags($m[1]), ENT_QUOTES));
        $tlen = mb_strlen($title);
        if ($title === '') { $add('title_missing', 'No <title> tag', true); $score -= 25; }
        elseif ($tlen > 60) { $add('title_long', "Title is {$tlen} chars (aim ≤60) — Google truncates it in results: “{$title}”", true); $score -= 4; }
        // meta description
        $mdesc = '';
        if (preg_match('#<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']#is', $html, $m)) $mdesc = trim($m[1]);
        if ($mdesc === '') { $add('meta_missing', 'No meta description — Google writes its own snippet', true); $score -= 10; }
        elseif (mb_strlen($mdesc) > 160) { $add('meta_long', 'Meta description ' . mb_strlen($mdesc) . ' chars (aim ≤160) — gets cut off', true); $score -= 2; }
        // canonical
        if (!preg_match('#<link[^>]+rel=["\']canonical["\']#i', $html)) { $add('no_canonical', 'No canonical tag', false); $score -= 5; }
        // H1
        if (count($h1s) === 0) { $add('no_h1', 'No H1 heading on the page', false); $score -= 12; }
        elseif (count($h1s) > 1) {
            $add('multi_h1', count($h1s) . ' H1 tags (should be one): “' . implode('” / “', array_map(function ($h) { return mb_substr($h['text'], 0, 40); }, array_slice($h1s, 0, 3))) . '”', false); $score -= 6;
        }
        // heading skip (with the exact jump + text)
        for ($i = 1; $i < count($heads); $i++) {
            if ($heads[$i]['lvl'] - $heads[$i-1]['lvl'] > 1) {
                $add('heading_skip', "Heading jumps H{$heads[$i-1]['lvl']}→H{$heads[$i]['lvl']} at “" . mb_substr($heads[$i]['text'], 0, 45) . '”', false);
                $score -= 6; break;
            }
        }
        // body text / thin
        $body = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $html);
        $words = str_word_count(wp_strip_all_tags($body));
        if ($words < 120) { $add('thin', "Thin content — only {$words} words of text", false); $score -= 8; }
        // img alt
        $imgs = preg_match_all('#<img\b[^>]*>#i', $html, $im);
        $noalt = 0;
        if ($imgs) foreach ($im[0] as $tag) if (!preg_match('#\balt\s*=\s*["\'][^"\']*["\']#i', $tag)) $noalt++;
        if ($noalt > 0) { $add('img_noalt', "{$noalt} image" . ($noalt > 1 ? 's' : '') . ' missing alt text (of ' . $imgs . ')', false); $score -= min(8, $noalt); }

        // internal links (for the link-graph: over/under-linking, orphans, links to dead pages)
        $host = wp_parse_url(home_url(), PHP_URL_HOST);
        $lc = 0; $targets = []; $generic_anchors = 0;
        if (preg_match_all('#<a\b[^>]*href=["\']([^"\'>]+)["\'][^>]*>(.*?)</a>#is', $html, $am, PREG_SET_ORDER)) {
            foreach ($am as $a) {
                $href = trim($a[1]);
                if ($href === '' || $href[0] === '#' || stripos($href, 'mailto:') === 0 || stripos($href, 'tel:') === 0 || stripos($href, 'javascript:') === 0) continue;
                if ($href[0] === '/') $href = home_url($href);
                $ph = wp_parse_url($href, PHP_URL_HOST);
                if ($ph && $ph !== $host) continue;         // external
                if (!$ph && strpos($href, '://') !== false) continue;
                $path = wp_parse_url($href, PHP_URL_PATH);
                if (!$path) continue;
                $path = rtrim($path, '/'); if ($path === '') continue;
                $lc++; $targets[$path] = 1;
                $atext = strtolower(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($a[2]))));
                if (in_array($atext, ['click here', 'here', 'read more', 'learn more', 'more', 'see more', 'view more', 'shop now', 'view all'], true)) $generic_anchors++;
            }
        }

        /* ---- deep content signals (genuineness / naturalness / stuffing), per Google helpful-content guidance ---- */
        $text = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($body)));
        $lt = strtolower($text);
        // generic AI-filler phrases (density per 1000 words)
        $fillers = ['in today\'s', 'whether you\'re', 'look no further', 'elevate your', 'isn\'t just', 'more than just',
            'seamlessly', 'transform your space', 'make a statement', 'game-changer', 'when it comes to', 'dive into',
            'a testament to', 'in conclusion', 'unlock the', 'it\'s important to note', 'effortlessly', 'stunning addition',
            'perfect blend', 'takes center stage', 'speaks volumes', 'breathe new life'];
        $fill = 0; foreach ($fillers as $f) $fill += substr_count($lt, $f);
        $fill_k = $words > 50 ? round($fill / max(1, $words) * 1000, 1) : 0;
        // keyword stuffing: share of the most repeated meaningful word
        $stop = ['the','a','an','and','or','of','to','in','for','with','on','your','our','is','are','that','this','it','as','at','by','from','you','we'];
        $wlist = array_filter(str_word_count($lt, 1), function ($w) use ($stop) { return strlen($w) > 3 && !in_array($w, $stop, true); });
        $freq = array_count_values($wlist); arsort($freq);
        $topshare = ($wlist && $words > 100) ? round(reset($freq) / max(1, count($wlist)) * 100, 1) : 0;
        // robotic rhythm: sentence-length uniformity (low variance across many sentences reads machine-written)
        $sents = preg_split('/[.!?]+\s/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $slens = array_map(function ($s) { return str_word_count($s); }, array_slice($sents, 0, 80));
        $svar = 0;
        if (count($slens) >= 8) {
            $mean = array_sum($slens) / count($slens);
            $svar = round(sqrt(array_sum(array_map(function ($l) use ($mean) { return ($l - $mean) ** 2; }, $slens)) / count($slens)), 1);
        }
        $cs = ['fill' => $fill_k, 'stuf' => $topshare, 'svar' => $svar, 'ga' => $generic_anchors, 'sents' => count($sents)];

        $score = max(0, min(100, $score));
        $norm = preg_replace('/\s+/', ' ', strtolower(preg_replace('/[^a-z0-9 ]+/i', ' ', wp_strip_all_tags($body))));
        $sig = md5(mb_substr(trim($norm), 0, 2500));
        return ['url' => $url, 'score' => $score, 'http' => $code, 'noindex' => $noindex, 'words' => $words,
                'issues' => $issues, 'lc' => $lc, 'targets' => array_keys($targets), 'sig' => $sig, 'cs' => $cs];
    }

    /* ---------- batch lifecycle (DB-persisted, background-safe) ---------- */

    public static function start() {
        $prev = get_option(self::OPT, []);
        // keep the previous completed run as a compact map for diffing
        $prevmap = [];
        if (is_array($prev) && !empty($prev['results'])) {
            foreach ($prev['results'] as $r) $prevmap[$r['u']] = ['s' => $r['s'], 'i' => $r['i'] ?? []];
        }
        $urls = self::collect_urls();
        if (empty($urls)) {
            $cur = self::progress();
            return ['total' => (int) $cur['total'], 'note' => 'sitemap temporarily unavailable — kept existing run'];
        }
        $state = ['started_at' => current_time('mysql'), 'total' => count($urls), 'done' => 0, 'urls' => $urls, 'results' => [], 'running' => true, 'previous' => $prevmap];
        update_option(self::OPT, $state, false);
        // kick off server-side processing so it continues even if the tab closes
        wp_schedule_single_event(time() + 2, 'psc_crawl_tick');
        return ['total' => count($urls)];
    }

    /** One locked batch — safe to call from both the browser and cron without double-processing. */
    public static function tick($size = 5) {
        if (get_transient('psc_crawl_lock')) return ['busy' => true] + self::progress();
        set_transient('psc_crawl_lock', 1, 90);
        $res = self::step($size);
        delete_transient('psc_crawl_lock');
        // reschedule server-side until finished
        if (empty($res['complete'])) {
            if (!wp_next_scheduled('psc_crawl_tick')) wp_schedule_single_event(time() + 2, 'psc_crawl_tick');
        }
        return $res;
    }

    public static function progress() {
        $s = get_option(self::OPT, []);
        return ['done' => (int) ($s['done'] ?? 0), 'total' => (int) ($s['total'] ?? 0), 'complete' => !empty($s['total']) && ($s['done'] ?? 0) >= $s['total'], 'running' => !empty($s['running'])];
    }

    public static function step($size = 5) {
        $state = get_option(self::OPT, []);
        if (!is_array($state) || empty($state['urls'])) return ['error' => 'not_started'];
        $size = max(1, min(15, (int) $size));
        $from = (int) $state['done'];
        $slice = array_slice($state['urls'], $from, $size);
        foreach ($slice as $u) {
            $res = self::check_page($u);
            $state['results'][] = ['u' => $u, 's' => $res['score'], 'n' => $res['noindex'] ?? false, 'i' => $res['issues'] ?? [], 'w' => $res['words'] ?? null, 'lc' => $res['lc'] ?? 0, 'sig' => $res['sig'] ?? '', 'cs' => $res['cs'] ?? []];
            if (!isset($state['inbound'])) $state['inbound'] = [];
            foreach (($res['targets'] ?? []) as $t) { if (!isset($state['inbound'][$t])) $state['inbound'][$t] = 0; $state['inbound'][$t]++; }
            $state['done']++;
        }
        if ($state['done'] >= $state['total']) $state['running'] = false;
        update_option(self::OPT, $state, false);
        return ['done' => $state['done'], 'total' => $state['total'], 'complete' => $state['done'] >= $state['total']];
    }

    /** Classify a URL into its page-template type (cheap path rules + one slug→post_type map). */
    public static function template_of($url, $slugmap) {
        $path = strtolower(trim((string) wp_parse_url($url, PHP_URL_PATH), '/'));
        if ($path === '') return 'Homepage';
        if (strpos($path, 'product-category/') !== false) return 'Product category';
        if (strpos($path, 'product-tag/') !== false) return 'Product tag archive';
        if (preg_match('#(^|/)tag/#', $path)) return 'Tag archive';
        if (preg_match('#(^|/)category/#', $path)) return 'Category archive';
        if (strpos($path, 'art-print-collections/') !== false) return 'Collection page';
        if (strpos($path, 'product/') === 0) return 'Single product';
        $slug = basename($path);
        $t = $slugmap[$slug] ?? '';
        if ($t === 'product') return 'Single product';
        if ($t === 'post') return 'Blog post';
        if ($t === 'page') return 'Page';
        return 'Other';
    }

    public static function slugmap() {
        global $wpdb;
        $map = [];
        $rows = $wpdb->get_results("SELECT post_name, post_type FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('product','post','page') LIMIT 5000", ARRAY_A);
        foreach ((array) $rows as $r) $map[strtolower($r['post_name'])] = $r['post_type'];
        return $map;
    }

    // Structural issue codes that stem from the page TEMPLATE — grouped into one card when widespread.
    const TEMPLATE_CODES = ['heading_skip', 'multi_h1', 'no_h1', 'no_canonical', 'img_noalt', 'thin'];
    // Templates that are machine-generated (one fix clears all pages of the type).
    const TEMPLATED = ['Single product', 'Blog post', 'Product category', 'Product tag archive', 'Tag archive', 'Category archive', 'Collection page'];

    public static function report() {
        $state = get_option(self::OPT, []);
        if (!is_array($state) || empty($state['results'])) return ['status' => 'none'];
        $res = $state['results'];
        $scored = array_filter($res, function ($r) { return $r['s'] !== null; });
        $n = count($scored);
        $avg = $n ? round(array_sum(array_map(function ($r) { return $r['s']; }, $scored)) / $n) : 0;
        $bands = ['good' => 0, 'ok' => 0, 'poor' => 0];
        $noindex = []; $worst = [];
        foreach ($scored as $r) {
            if ($r['s'] >= 85) $bands['good']++; elseif ($r['s'] >= 65) $bands['ok']++; else $bands['poor']++;
            if (!empty($r['n'])) $noindex[] = $r['u'];
        }

        /* ---- template-level grouping: same structural issue across many pages of one template = ONE card ---- */
        $slugmap = self::slugmap();
        $tpl_pages = []; $tpl_issue = []; // template => page count; template|code => ['count'=>N,'sample'=>desc,'examples'=>[urls]]
        foreach ($scored as $r) {
            $tpl = self::template_of($r['u'], $slugmap);
            $tpl_pages[$tpl] = ($tpl_pages[$tpl] ?? 0) + 1;
            if (!in_array($tpl, self::TEMPLATED, true)) continue;
            foreach ((array) $r['i'] as $it) {
                if (!is_array($it) || !in_array($it['c'] ?? '', self::TEMPLATE_CODES, true)) continue;
                $k = $tpl . '|' . $it['c'];
                if (!isset($tpl_issue[$k])) $tpl_issue[$k] = ['template' => $tpl, 'code' => $it['c'], 'count' => 0, 'sample' => $it['d'], 'examples' => []];
                $tpl_issue[$k]['count']++;
                if (count($tpl_issue[$k]['examples']) < 3) $tpl_issue[$k]['examples'][] = preg_replace('#^https?://[^/]+#', '', $r['u']);
            }
        }
        $template_issues = []; $suppress = []; // template|code that made the cut
        foreach ($tpl_issue as $k => $g) {
            $share = $g['count'] / max(1, $tpl_pages[$g['template']]);
            if ($g['count'] >= 5 && $share >= 0.3) {   // widespread within the template = template-level
                $g['template_pages'] = $tpl_pages[$g['template']];
                $g['share'] = round($share * 100);
                $template_issues[] = $g;
                $suppress[$k] = 1;
            }
        }
        usort($template_issues, function ($a, $b) { return $b['count'] <=> $a['count']; });

        // diff vs previous completed crawl
        $codesOf = function ($list) { return array_map(function ($x) { return is_array($x) ? ($x['c'] ?? '') : (string) $x; }, is_array($list) ? $list : []); };
        $prev = is_array($state['previous'] ?? null) ? $state['previous'] : [];
        $fixed = []; $regressed = []; $new = [];
        if ($prev) {
            foreach ($scored as $r) {
                $u = $r['u'];
                if (!isset($prev[$u])) { $new[] = $u; continue; }
                $ps = (int) $prev[$u]['s'];
                $gone = array_values(array_diff($codesOf($prev[$u]['i'] ?? []), $codesOf($r['i'])));
                if ($r['s'] > $ps + 2 || $gone) $fixed[] = ['url' => $u, 'from' => $ps, 'to' => $r['s'], 'resolved' => $gone];
                elseif ($r['s'] < $ps - 2) $regressed[] = ['url' => $u, 'from' => $ps, 'to' => $r['s']];
            }
        }
        usort($res, function ($a, $b) { return ($a['s'] ?? 101) <=> ($b['s'] ?? 101); });
        foreach ($res as $r) {
            if (count($worst) >= 25) break;
            $tpl = self::template_of($r['u'], $slugmap);
            // hide issues already reported at template level; keep page-specific ones (incl. fixable title/meta)
            $issues = array_values(array_filter((array) $r['i'], function ($it) use ($tpl, $suppress) {
                $c = is_array($it) ? ($it['c'] ?? '') : '';
                return !isset($suppress[$tpl . '|' . $c]);
            }));
            if (!$issues && $r['s'] >= 85) continue; // page only had template-level issues — covered by the combined card
            $pid = function_exists('url_to_postid') ? url_to_postid($r['u']) : 0;
            if (!$pid && trim((string) wp_parse_url($r['u'], PHP_URL_PATH), '/') === '') $pid = (int) get_option('page_on_front');
            $worst[] = ['url' => $r['u'], 'score' => $r['s'], 'template' => $tpl, 'issues' => $issues, 'edit_url' => $pid ? admin_url('post.php?post=' . $pid . '&action=edit') : ''];
        }
        return [
            'status' => 'ok', 'started_at' => $state['started_at'], 'total' => $state['total'], 'crawled' => count($res),
            'running' => !empty($state['running']), 'avg_score' => $avg, 'bands' => $bands, 'noindex' => $noindex,
            'template_issues' => $template_issues, 'worst' => $worst,
            'diff' => ['had_previous' => !empty($prev), 'fixed' => array_slice($fixed, 0, 20), 'fixed_count' => count($fixed), 'regressed' => array_slice($regressed, 0, 10), 'regressed_count' => count($regressed), 'new_count' => count($new)],
        ];
    }

    /* ---------- one-click fixes (Yoast title/meta, written directly + logged) ---------- */

    public static function fixable() { return ['title_long', 'title_missing', 'meta_missing', 'meta_long']; }

    public static function fix($url, $code) {
        if (!in_array($code, self::fixable(), true)) return ['ok' => false, 'message' => 'This one needs a manual edit — open the page and adjust it.'];
        $pid = function_exists('url_to_postid') ? url_to_postid($url) : 0;
        if (!$pid && trim((string) wp_parse_url($url, PHP_URL_PATH), '/') === '') $pid = (int) get_option('page_on_front');
        if (!$pid) return ['ok' => false, 'message' => 'Could not resolve this URL to an editable page.'];
        if (!class_exists('PSC_Connectors') || !PSC_Connectors::has_anthropic()) return ['ok' => false, 'message' => 'Add your Anthropic key in Settings → Connectors to auto-generate.'];

        $r = wp_remote_get($url, ['timeout' => 10, 'headers' => ['User-Agent' => self::UA]]);
        $html = is_wp_error($r) ? '' : wp_remote_retrieve_body($r);
        $title = ''; if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $title = trim(wp_strip_all_tags($m[1]));
        $h1 = ''; if (preg_match('#<h1[^>]*>(.*?)</h1>#is', $html, $m)) $h1 = trim(wp_strip_all_tags($m[1]));
        $body = preg_replace('#<(script|style|noscript|nav|header|footer)\b[^>]*>.*?</\1>#is', ' ', $html);
        $text = mb_substr(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($body))), 0, 1500);

        $isTitle = in_array($code, ['title_long', 'title_missing'], true);
        if ($isTitle) {
            $sys = "You write concise, compelling SEO <title> tags. Return ONLY the title text, MAX 60 characters, no surrounding quotes, primary keyword included naturally, tone fit for a premium wall-art print shop.";
            $user = "Page H1: {$h1}\nCurrent title: {$title}\nPage text: {$text}\n\nWrite the best SEO title, <=60 chars.";
            $max = 1000;
        } else {
            $sys = "You write compelling SEO meta descriptions. Return ONLY the description, 150-160 characters, active voice, one concrete benefit + soft CTA, for a premium wall-art print shop (free shipping over \$69, 310gsm archival giclée).";
            $user = "Page H1: {$h1}\nTitle: {$title}\nPage text: {$text}\n\nWrite the meta description (150-160 chars).";
            $max = 1200;
        }
        $val = trim(self::llm($sys, $user, $max), " \t\n\"'");
        if ($val === '') return ['ok' => false, 'message' => 'Could not generate a value — try again.'];

        if ($isTitle) update_post_meta($pid, '_yoast_wpseo_title', $val);
        else update_post_meta($pid, '_yoast_wpseo_metadesc', $val);
        wp_update_post(['ID' => $pid]); // rebuild Yoast indexable
        global $kinsta_cache;
        if (!empty($kinsta_cache->kinsta_cache_purge) && method_exists($kinsta_cache->kinsta_cache_purge, 'purge_complete_caches')) $kinsta_cache->kinsta_cache_purge->purge_complete_caches();
        if (function_exists('wp_cache_flush')) wp_cache_flush();
        do_action('litespeed_purge_url', $url);

        if (class_exists('PSC_Changes')) PSC_Changes::add([
            'title' => ($isTitle ? 'Rewrote SEO title' : 'Added meta description') . ' — ' . wp_parse_url($url, PHP_URL_PATH),
            'url' => $url, 'kind' => ($isTitle ? 'title' : 'meta'),
            'note' => 'Auto-fixed via Console: ' . $val,
        ]);

        return ['ok' => true, 'field' => ($isTitle ? 'SEO title' : 'meta description'), 'value' => $val,
                'edit_url' => admin_url('post.php?post=' . $pid . '&action=edit'), 'message' => 'Fixed and logged to the Changes tracker.'];
    }

    private static function llm($system, $user, $max) {
        $resp = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'timeout' => 60,
            'headers' => ['x-api-key' => PSC_Connectors::anthropic(), 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json'],
            'body'    => wp_json_encode(['model' => 'claude-sonnet-5', 'max_tokens' => $max, 'system' => $system, 'messages' => [['role' => 'user', 'content' => $user]]]),
        ]);
        if (is_wp_error($resp)) return '';
        $b = json_decode(wp_remote_retrieve_body($resp), true);
        $t = ''; foreach (($b['content'] ?? []) as $blk) if (($blk['type'] ?? '') === 'text') $t .= $blk['text'];
        return trim($t);
    }
}
