<?php
if (!defined('ABSPATH')) exit;

/**
 * Whole-site crawl. Enumerates every URL from the XML sitemap (Yoast or WP core),
 * then runs a fast single-fetch on-page audit across all of them in client-driven
 * batches (so nothing times out), storing a per-page score + issues and a site
 * aggregate. This is what makes "audit every page" real, without 700 slow requests
 * in one shot.
 */
class PSC_Crawl {

    const OPT   = 'psc_crawl_state';
    const UA    = 'PS-SEO-Console/1.0 (+site-crawl)';
    const CAP   = 3000;

    /* ---------- URL enumeration ---------- */

    public static function collect_urls() {
        $roots = [home_url('/sitemap_index.xml'), home_url('/sitemap.xml'), home_url('/wp-sitemap.xml')];
        $seen = []; $urls = [];
        $host = wp_parse_url(home_url(), PHP_URL_HOST);

        $fetch = function ($u) {
            $r = wp_remote_get($u, ['timeout' => 20, 'headers' => ['User-Agent' => self::UA]]);
            if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) >= 400) return '';
            return wp_remote_retrieve_body($r);
        };

        $index_xml = '';
        foreach ($roots as $root) { $index_xml = $fetch($root); if ($index_xml !== '') break; }
        if ($index_xml === '') return [];

        // sub-sitemaps referenced by the index
        $subs = [];
        if (preg_match_all('#<sitemap>.*?<loc>(.*?)</loc>#is', $index_xml, $m)) $subs = $m[1];
        if (!$subs) $subs = [$root]; // was a flat sitemap already

        foreach (array_slice($subs, 0, 60) as $sub) {
            $xml = ($sub === $root) ? $index_xml : $fetch(html_entity_decode($sub));
            if ($xml === '') continue;
            if (preg_match_all('#<url>.*?<loc>(.*?)</loc>#is', $xml, $mm)) {
                foreach ($mm[1] as $loc) {
                    $loc = trim(html_entity_decode($loc));
                    if (wp_parse_url($loc, PHP_URL_HOST) !== $host) continue;
                    if (isset($seen[$loc])) continue;
                    $seen[$loc] = 1; $urls[] = $loc;
                    if (count($urls) >= self::CAP) break 2;
                }
            }
        }
        return $urls;
    }

    /* ---------- per-page fast audit (single fetch) ---------- */

    public static function check_page($url) {
        $r = wp_remote_get($url, ['timeout' => 20, 'headers' => ['User-Agent' => self::UA]]);
        if (is_wp_error($r)) return ['url' => $url, 'score' => null, 'error' => $r->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($r);
        $html = wp_remote_retrieve_body($r);
        $issues = []; $noindex = false; $score = 100;

        if ($code >= 400) return ['url' => $url, 'score' => 0, 'http' => $code, 'noindex' => false, 'issues' => ["HTTP {$code}"]];

        // robots meta
        if (preg_match('#<meta[^>]+name=["\']robots["\'][^>]+content=["\']([^"\']*)#i', $html, $m) && stripos($m[1], 'noindex') !== false) {
            $noindex = true; $issues[] = 'noindex'; $score -= 60;
        }
        // title
        $title = '';
        if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) $title = trim(wp_strip_all_tags($m[1]));
        if ($title === '') { $issues[] = 'missing <title>'; $score -= 25; }
        elseif (mb_strlen($title) > 65) { $issues[] = 'title >65 chars'; $score -= 4; }
        // meta description
        if (!preg_match('#<meta[^>]+name=["\']description["\'][^>]+content=["\'][^"\']{5,}#i', $html)) { $issues[] = 'missing meta description'; $score -= 10; }
        // canonical
        if (!preg_match('#<link[^>]+rel=["\']canonical["\']#i', $html)) { $issues[] = 'no canonical'; $score -= 5; }
        // H1
        $h1 = preg_match_all('#<h1[\s>]#i', $html, $x);
        if ($h1 === 0) { $issues[] = 'no H1'; $score -= 12; }
        elseif ($h1 > 1) { $issues[] = "{$h1} H1s"; $score -= 6; }
        // heading skip
        if (preg_match_all('#<h([1-6])[\s>]#i', $html, $hm)) {
            $lvls = array_map('intval', $hm[1]); $skip = false;
            for ($i = 1; $i < count($lvls); $i++) if ($lvls[$i] - $lvls[$i-1] > 1) { $skip = true; break; }
            if ($skip) { $issues[] = 'heading skip'; $score -= 6; }
        }
        // body text / thin
        $body = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $html);
        $words = str_word_count(wp_strip_all_tags($body));
        if ($words < 120) { $issues[] = "thin ({$words}w)"; $score -= 8; }
        // img alt
        $imgs = preg_match_all('#<img\b[^>]*>#i', $html, $im);
        $noalt = 0;
        if ($imgs) foreach ($im[0] as $tag) if (!preg_match('#\balt\s*=\s*["\'][^"\']*["\']#i', $tag)) $noalt++;
        if ($noalt > 0) { $issues[] = "{$noalt} img no-alt"; $score -= min(8, $noalt); }

        $score = max(0, min(100, $score));
        return ['url' => $url, 'score' => $score, 'http' => $code, 'noindex' => $noindex, 'words' => $words, 'issues' => $issues];
    }

    /* ---------- batch lifecycle ---------- */

    public static function start() {
        $urls = self::collect_urls();
        $state = ['started_at' => current_time('mysql'), 'total' => count($urls), 'done' => 0, 'urls' => $urls, 'results' => []];
        update_option(self::OPT, $state, false);
        return ['total' => count($urls)];
    }

    public static function step($size = 12) {
        $state = get_option(self::OPT, []);
        if (!is_array($state) || empty($state['urls'])) return ['error' => 'not_started'];
        $size = max(1, min(25, (int) $size));
        $from = (int) $state['done'];
        $slice = array_slice($state['urls'], $from, $size);
        foreach ($slice as $u) {
            $res = self::check_page($u);
            $state['results'][] = ['u' => $u, 's' => $res['score'], 'n' => $res['noindex'] ?? false, 'i' => $res['issues'] ?? [], 'w' => $res['words'] ?? null];
            $state['done']++;
        }
        update_option(self::OPT, $state, false);
        return ['done' => $state['done'], 'total' => $state['total'], 'complete' => $state['done'] >= $state['total']];
    }

    public static function report() {
        $state = get_option(self::OPT, []);
        if (!is_array($state) || empty($state['results'])) return ['status' => 'none'];
        $res = $state['results'];
        $scored = array_filter($res, function ($r) { return $r['s'] !== null; });
        $n = count($scored);
        $avg = $n ? round(array_sum(array_map(function ($r) { return $r['s']; }, $scored)) / $n) : 0;
        $bands = ['good' => 0, 'ok' => 0, 'poor' => 0];
        $noindex = []; $worst = [];
        foreach ($scored as $r) {
            if ($r['s'] >= 85) $bands['good']++; elseif ($r['s'] >= 65) $bands['ok']++; else $bands['poor']++;
            if (!empty($r['n'])) $noindex[] = $r['u'];
        }
        usort($res, function ($a, $b) { return ($a['s'] ?? 101) <=> ($b['s'] ?? 101); });
        foreach (array_slice($res, 0, 25) as $r) {
            $pid = function_exists('url_to_postid') ? url_to_postid($r['u']) : 0;
            if (!$pid && trim((string) wp_parse_url($r['u'], PHP_URL_PATH), '/') === '') $pid = (int) get_option('page_on_front');
            $worst[] = ['url' => $r['u'], 'score' => $r['s'], 'issues' => $r['i'], 'edit_url' => $pid ? admin_url('post.php?post=' . $pid . '&action=edit') : ''];
        }
        return [
            'status' => 'ok', 'started_at' => $state['started_at'], 'total' => $state['total'], 'crawled' => count($res),
            'avg_score' => $avg, 'bands' => $bands, 'noindex' => $noindex, 'worst' => $worst,
        ];
    }
}
