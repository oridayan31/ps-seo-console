=== PS SEO Console ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.12.0

Lightweight SEO command center for Print Studio. Admin-only; nothing loads on the storefront.

== Phase 2i (this build) ==
* Critical email alerts: emails when a live page goes noindex, a site-wide crawl block appears, a payment
  gateway starts failing, or search clicks drop sharply. Each issue sends once (+ a resolved note); hourly check.
  Recipient, on/off, and critical-vs-warning tier in Settings, with a Send-test-email button.

== Phase 2h ==
* Remote self-update: verified POST /update endpoint installs a new Console (or bridge) version via API instead
  of a manual upload. Hardened -- second secret (update token) beyond WP auth, allow-listed slug only, SHA-256
  verified, rejects any path outside the slug folder, backs up + rolls back on failure. Dormant until a token is set.

== Phase 2g ==
* Competitors tab: referring-domains & authority gap vs a competitor set (seeded with the wall-art field),
  with your count, competitor median, and the gap multiplier. Uses DataForSEO Backlinks (same login, metered);
  fetches only on demand, caches 24h. Add/remove competitors by root domain.

== Phase 2f ==
* Google Search status: pulls the incidents feed (Crawling/Indexing/Ranking/Serving); shows active + recent
  incidents on Overview, and annotates Watcher review cards when a Google update overlapped the measurement
  window (so a ranking move is not misattributed to one of our own changes).

== Phase 2e ==
* Conversion tab: ecommerce funnel (sessions → add-to-cart → checkout → purchase) with cart & checkout
  abandonment + conversion rate from GA4; payment-gateway health (orders, failure rate, revenue, idle/failing
  flags) from WooCommerce orders; and a checkout-configuration audit (checkout/cart pages, enabled gateways,
  guest checkout, HTTPS, terms page). 7/28/90-day windows.

== Phase 2d ==
* Page audit (SEO + AEO): fetches any URL and runs the full P0–P3 checklist ported from the seo-aeo-auditor
  (status/redirects, HTTPS, noindex, canonical, robots.txt + AI-bot access, title/meta, H1/heading order,
  viewport/lang, JSON-LD schema, image alt, internal links + anchors, Open Graph, hreflang, AEO questions),
  scores it, and lists the manual-review items the score does not claim. One P0 failure is the headline.

== Phase 2c ==
* Indexability audit: flags published pages set to noindex, plus site-level HTTPS / robots.txt / XML-sitemap checks. Closes the biggest ranking-blocker gap.

== Phase 2b ==
* Data connectors: DataForSEO (keyword data), PageSpeed Insights (Core Web Vitals), Anthropic (AI SEO)
  -- each with a live connectivity test; keys in DB or wp-config constants (PSC_DATAFORSEO_*, PSC_PAGESPEED_KEY, PSC_ANTHROPIC_KEY).
* "Import from other plugins" scanner: finds keys stored by SAI, imports them internally (never displays raw values).

== Phase 2a ==
* Google service-account connection (one key → Search Console + GA4 + Merchant Center). No interactive OAuth.
* Live KPI boxes: clicks, impressions, CTR, avg position (28d vs prior 28d) from Search Console.
* Dated keyword/page history storage (real trends, not snapshots).
* Merchant Center feed health: active / disapproved / expiring + disapproval reasons.
* GA4 organic revenue.
* Scheduler / Watchers: on a tracked change (new page, 301, meta rewrite, post) capture a baseline,
  wait N days, then drop a review card on the Board with the before->after delta. Rules configurable.
* Audit now pulls real GMC + GSC signals (CTR gaps, striking distance) when connected.

== Phase 1 (previous) ==
* Live Board (tasks), local Audit, Overview health score, REST API (ps-seo/v1).

== Security ==
Service-account JSON is stored in the DB. For extra security define PSC_GOOGLE_SA_JSON in wp-config;
it takes priority and keeps the key out of the database.

== Endpoints (ps-seo/v1) ==
health · dashboard · tasks (CRUD) · signals · scan · connect · connect/status · sync · kpis · watches

== Changelog ==
= 0.10.0 = Critical email alerts (noindex, crawl block, gateway failure, traffic cliff) with de-dup + resolved notes.
= 0.9.0 = Remote self-update (token-gated, checksum-verified, slug-restricted, backup+rollback).
= 0.8.0 = Competitor authority & backlink-gap analysis (DataForSEO Backlinks; referring domains, median, gap).
= 0.7.0 = Google Search Status Dashboard integration (active/recent incidents + Watcher overlap flag).
= 0.6.0 = Conversion analysis: GA4 funnel + abandonment, WooCommerce gateway health, checkout config audit.
= 0.5.0 = Per-URL SEO+AEO page auditor (P0-P3 scored) ported from the seo-aeo-auditor skill.
= 0.4.0 = Indexability + technical audit signals (noindex sweep, robots.txt, sitemap, HTTPS).
= 0.3.0 = Data connectors (DataForSEO, PageSpeed, Anthropic) + SAI key import scanner.
= 0.2.0 = Google connection, KPIs, Merchant feed health, GA4 revenue, Scheduler/Watchers.
= 0.1.0 = Initial Phase 1 build.
