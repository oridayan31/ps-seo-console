<?php
/**
 * Plugin Name: PS SEO Console
 * Description: SEO command center for Print Studio — live board, local + Google-powered audit, KPI metrics (Search Console / GA4 / Merchant), and an auto-scheduling follow-up engine. Admin-only, zero storefront load. Claude reads metrics and writes the board via REST.
 * Version: 0.23.12
 * Author: Print Studio
 * Requires PHP: 7.4
 * Text Domain: ps-seo-console
 */

if (!defined('ABSPATH')) exit;

define('PSC_VERSION', '0.23.12');
define('PSC_FILE', __FILE__);
define('PSC_DIR', plugin_dir_path(__FILE__));
define('PSC_URL', plugin_dir_url(__FILE__));
define('PSC_REST_NS', 'ps-seo/v1');
define('PSC_TASKS_TABLE', 'psc_tasks');

require_once PSC_DIR . 'includes/class-psc-db.php';
require_once PSC_DIR . 'includes/class-psc-google.php';
require_once PSC_DIR . 'includes/class-psc-oauth.php';
require_once PSC_DIR . 'includes/class-psc-gsc.php';
require_once PSC_DIR . 'includes/class-psc-ga4.php';
require_once PSC_DIR . 'includes/class-psc-gmc.php';
require_once PSC_DIR . 'includes/class-psc-connectors.php';
require_once PSC_DIR . 'includes/class-psc-pageaudit.php';
require_once PSC_DIR . 'includes/class-psc-conversion.php';
require_once PSC_DIR . 'includes/class-psc-googlestatus.php';
require_once PSC_DIR . 'includes/class-psc-competitors.php';
require_once PSC_DIR . 'includes/class-psc-insights.php';
require_once PSC_DIR . 'includes/class-psc-contentquality.php';
require_once PSC_DIR . 'includes/class-psc-brain.php';
require_once PSC_DIR . 'includes/class-psc-crawl.php';
require_once PSC_DIR . 'includes/class-psc-changes.php';
require_once PSC_DIR . 'includes/class-psc-sitehealth.php';
require_once PSC_DIR . 'includes/class-psc-fixer.php';
require_once PSC_DIR . 'includes/class-psc-verify.php';
require_once PSC_DIR . 'includes/class-psc-updater.php';
require_once PSC_DIR . 'includes/class-psc-alerts.php';
require_once PSC_DIR . 'includes/class-psc-watchers.php';
require_once PSC_DIR . 'includes/class-psc-audit.php';
require_once PSC_DIR . 'includes/class-psc-rest.php';
require_once PSC_DIR . 'includes/class-psc-admin.php';

/* ---- Activation ---- */
register_activation_hook(__FILE__, function () {
    PSC_DB::create_table();
    PSC_DB::seed_if_empty();
    PSC_GSC::ensure_tables();
    PSC_GA4::ensure_table();
    PSC_Watchers::ensure_table();
    if (!wp_next_scheduled('psc_daily_scan')) {
        wp_schedule_event(time() + 3600, 'daily', 'psc_daily_scan');
    }
    if (!wp_next_scheduled('psc_alert_check')) {
        wp_schedule_event(time() + 900, 'hourly', 'psc_alert_check');
    }
});

register_deactivation_hook(__FILE__, function () {
    foreach (['psc_daily_scan', 'psc_alert_check'] as $hook) {
        $ts = wp_next_scheduled($hook);
        if ($ts) wp_unschedule_event($ts, $hook);
    }
});

/* ---- Daily cron: pull Google data, refresh audit, fire due watchers ---- */
add_action('psc_daily_scan', 'psc_run_daily');
function psc_run_daily() {
    if (PSC_Google::is_connected()) {
        PSC_GSC::sync();
        PSC_GA4::sync();
        PSC_GMC::sync();
    }
    PSC_Audit::run_and_cache();
    if (class_exists('PSC_GoogleStatus')) PSC_GoogleStatus::incidents(true);
    if (class_exists('PSC_Conversion')) PSC_Conversion::report(28, true); // refresh gateway/funnel cache for alerts
    if (class_exists('PSC_Insights')) PSC_Insights::generate(true);
    if (class_exists('PSC_Changes')) PSC_Changes::snapshot_all();
    if (class_exists('PSC_Brain') && class_exists('PSC_Connectors') && PSC_Connectors::has_anthropic()) { PSC_Brain::refresh_analysis(); PSC_Brain::propose_research(); }
    PSC_Watchers::check_due();
    if (class_exists('PSC_Alerts')) PSC_Alerts::run();
    // Self-update from the configured source: install if auto is on, otherwise just record availability.
    if (class_exists('PSC_Updater') && PSC_Updater::has_source()) {
        $res = PSC_Updater::check_remote(PSC_Updater::auto_on());
        update_option('psc_update_last_check', ['at' => current_time('mysql')] + (array) $res);
    }
}

/* ---- Hourly cron: critical alert check (reads cached signals) ---- */
add_action('psc_alert_check', function () {
    if (class_exists('PSC_Alerts')) PSC_Alerts::run();
});

/* ---- Auto-create watches when a page/post is newly published ---- */
add_action('transition_post_status', ['PSC_Watchers', 'on_transition'], 10, 3);

/* ---- Bootstrap ---- */
add_action('init', function () {
    PSC_DB::maybe_upgrade();
});
add_action('rest_api_init', ['PSC_REST', 'register_routes']);
add_action('admin_post_psc_oauth_cb', ['PSC_OAuth', 'handle_callback']);
add_action('admin_post_psc_oauth_disconnect', ['PSC_OAuth', 'handle_disconnect']);
add_action('psc_crawl_tick', ['PSC_Crawl', 'tick']);

// Auto-log meaningful content edits as tracked changes (dedup per URL per day).
add_action('save_post', function ($post_id, $post) {
    if (!class_exists('PSC_Changes')) return;
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
    if ($post->post_status !== 'publish') return;
    if (!in_array($post->post_type, ['page', 'post', 'ps_collection', 'product'], true)) return;
    if ($post->post_type === 'product') return; // products edit in bulk — too noisy to track
    $url = get_permalink($post_id);
    if (!$url) return;
    $flag = 'psc_chg_' . md5($url . gmdate('Y-m-d'));
    if (get_transient($flag)) return; // one auto-log per URL per day
    set_transient($flag, 1, DAY_IN_SECONDS);
    $kind = $post->post_type === 'post' ? 'content' : ($post->post_type === 'ps_collection' ? 'new_collection' : 'content');
    PSC_Changes::add(['title' => 'Edited: ' . get_the_title($post_id), 'url' => $url, 'kind' => $kind, 'note' => 'Auto-logged on save.']);
}, 20, 2);
if (is_admin()) {
    PSC_Admin::init();
}
